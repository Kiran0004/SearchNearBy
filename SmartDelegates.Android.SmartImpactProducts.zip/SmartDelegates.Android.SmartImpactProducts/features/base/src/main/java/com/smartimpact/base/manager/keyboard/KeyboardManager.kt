package com.smartimpact.base.manager.keyboard

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager.LayoutParams
import android.view.inputmethod.InputMethodManager
import android.widget.PopupWindow
import com.smartimpact.base.R

class KeyboardManager(
        private val activity: Activity,
        private val inputMethodManager: InputMethodManager) : PopupWindow(activity) {

    private var listeners = mutableListOf<KeyboardShownListener>()
    private var keyboardLandscapeHeight: Int = 0
    private var keyboardPortraitHeight: Int = 0
    private val popupView: View
    private val parentView: View

    // Is keyboard shown
    var shown: Boolean = false
        private set

    // Is keyboard shown
    private var lastShownHeight: Int = 0

    private val screenOrientation: Int
        get() = activity.resources.configuration.orientation

    init {

        val inflater = activity.getSystemService(Activity.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        popupView = inflater.inflate(R.layout.popup_window, null, false)!!
        contentView = popupView

        softInputMode = LayoutParams.SOFT_INPUT_ADJUST_RESIZE or LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
        inputMethodMode = PopupWindow.INPUT_METHOD_NEEDED

        parentView = activity.findViewById(android.R.id.content)

        width = 0
        height = LayoutParams.MATCH_PARENT

        popupView.viewTreeObserver.addOnGlobalLayoutListener {
            handleOnGlobalLayout()
        }
    }

    fun start() {
        if (!isShowing && parentView.windowToken != null) {
            setBackgroundDrawable(ColorDrawable(0))
            showAtLocation(parentView, Gravity.NO_GRAVITY, 0, 0)
        }
    }

    fun close() {
        listeners.clear()
        dismiss()
    }

    fun addKeyboardShownListener(listener: KeyboardShownListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeKeyboardShownListener(listener: KeyboardShownListener) {
        listeners.remove(listener)
    }

    fun hideKeyboard(view: View) {
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun showKeyboard(view:View) {
        inputMethodManager.showSoftInput(view, 0)
    }

    private fun handleOnGlobalLayout() {

        val screenSize = Point()
        activity.windowManager.defaultDisplay.getSize(screenSize)

        val rect = Rect()
        popupView.getWindowVisibleDisplayFrame(rect)

        // REMIND, you may like to change this using the fullscreen size of the phone
        // and also using the status bar and navigation bar heights of the phone to calculate
        // the keyboard height. But this worked fine on a Nexus.
        val orientation = screenOrientation
        val keyboardHeight = screenSize.y - rect.bottom

        when {
            // Samsung can have negative value!!
            keyboardHeight <= 0 -> notifyKeyboardHeightChanged(false, 0)
            orientation == Configuration.ORIENTATION_PORTRAIT -> {
                this.keyboardPortraitHeight = keyboardHeight
                notifyKeyboardHeightChanged(true, keyboardHeight)
            }
            else -> {
                this.keyboardLandscapeHeight = keyboardHeight
                notifyKeyboardHeightChanged(true, keyboardHeight)
            }
        }
    }

    private fun notifyKeyboardHeightChanged(shown: Boolean, keyboardHeight: Int) {
        if (this.shown != shown || this.lastShownHeight != keyboardHeight) {
            this.shown = shown
            this.lastShownHeight = keyboardHeight
            listeners.forEach { it.onKeyboardShownChanged(shown, keyboardHeight) }
        }
    }

}
