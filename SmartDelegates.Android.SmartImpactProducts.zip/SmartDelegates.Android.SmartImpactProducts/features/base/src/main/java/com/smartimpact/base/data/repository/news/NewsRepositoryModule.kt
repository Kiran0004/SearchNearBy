package com.smartimpact.base.data.repository.news

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contact.mapper.ContactLocalMapper
import com.smartimpact.cache.news.NewsLocalSourceImpl
import com.smartimpact.cache.news.dao.NewsDao
import com.smartimpact.cache.news.mapper.NewsLocalMapper
import com.smartimpact.data.news.source.local.NewsLocalSource
import com.smartimpact.data.news.source.remote.NewsRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.news.NewsRemoteSourceImpl
import com.smartimpact.remote.news.mapper.NewsRemoteDataMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton


@Module
object NewsRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideNewsLocalMapper(contactLocalMapper: ContactLocalMapper): NewsLocalMapper {
        return NewsLocalMapper(contactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDao(cacheDatabase: CacheDatabase): NewsDao {
        return cacheDatabase.newsDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsLocalSource(inboxDao: NewsDao, localMapper: NewsLocalMapper): NewsLocalSource {
        return NewsLocalSourceImpl(inboxDao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsRemoteDataMapper(contactRemoteMapper: ContactRemoteMapper): NewsRemoteDataMapper {
        return NewsRemoteDataMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsRemoteSource(apiService: ApiService, remoteMapper: NewsRemoteDataMapper, profileManager: ProfileManager): NewsRemoteSource {
        return NewsRemoteSourceImpl(apiService, remoteMapper, profileManager)
    }

}