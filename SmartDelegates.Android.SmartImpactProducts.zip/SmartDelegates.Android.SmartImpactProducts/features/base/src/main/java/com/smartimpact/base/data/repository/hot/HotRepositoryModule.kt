package com.smartimpact.base.data.repository.hot

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contact.mapper.ContactLocalMapper
import com.smartimpact.cache.hot.HotLocalSourceImpl
import com.smartimpact.cache.hot.dao.HotDao
import com.smartimpact.cache.hot.mapper.HotLocalMapper
import com.smartimpact.data.hot.source.local.HotLocalSource
import com.smartimpact.data.hot.source.remote.HotRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.hot.HotRemoteSourceImpl
import com.smartimpact.remote.hot.mapper.HotRemoteDataMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton


@Module
object HotRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideHotLocalMapper(contactLocalMapper: ContactLocalMapper): HotLocalMapper {
        return HotLocalMapper(contactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideHotDao(cacheDatabase: CacheDatabase): HotDao {
        return cacheDatabase.hotDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideHotLocalSource(inboxDao: HotDao, localMapper: HotLocalMapper): HotLocalSource {
        return HotLocalSourceImpl(inboxDao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideHotRemoteDataMapper(contactRemoteMapper: ContactRemoteMapper): HotRemoteDataMapper {
        return HotRemoteDataMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideHotRemoteSource(apiService: ApiService, remoteMapper: HotRemoteDataMapper, profileManager: ProfileManager): HotRemoteSource {
        return HotRemoteSourceImpl(apiService, remoteMapper, profileManager)
    }

}