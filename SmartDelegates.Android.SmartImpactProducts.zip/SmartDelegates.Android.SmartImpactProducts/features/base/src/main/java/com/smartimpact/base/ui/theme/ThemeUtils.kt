package com.smartimpact.base.ui.theme

import android.content.Context
import android.util.TypedValue
import androidx.annotation.AttrRes
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

@ColorRes
fun Context.getThemeColorRes(@AttrRes colorAttribute: Int): Int {
    val typedValue = TypedValue()
    theme.resolveAttribute(colorAttribute, typedValue, true)
    return typedValue.resourceId
}

@ColorInt
fun Context.getThemeColor(@AttrRes colorAttribute: Int): Int {
    val colorRes = getThemeColorRes(colorAttribute)
    return ContextCompat.getColor(this, colorRes)
}
