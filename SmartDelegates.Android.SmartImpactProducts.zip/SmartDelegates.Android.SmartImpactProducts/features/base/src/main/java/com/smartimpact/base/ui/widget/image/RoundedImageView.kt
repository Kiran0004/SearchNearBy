package com.smartimpact.base.ui.widget.image

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView
import com.smartimpact.base.R

class RoundedImageView(context: Context, attrs: AttributeSet?) : AppCompatImageView(context, attrs) {

    private var cornerRadius = 0
    private var corners = CORNER_NONE

    private val cornerRect = RectF()
    private val clipPath = Path()

    init {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.RoundedImageView)
        cornerRadius = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_cornerRadius, 0)
        corners = typedArray.getInt(R.styleable.RoundedImageView_corners, 0)
        typedArray.recycle()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.clipPath(clipPath)
        super.onDraw(canvas)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recalculateClipPath()
    }

    private fun recalculateClipPath() {
        clipPath.rewind()
        if (cornerRadius <= 0) {
            clipPath.addRect(0F, 0F, width.toFloat(), height.toFloat(), Path.Direction.CW)
        } else {
            val cornerFloat = cornerRadius.toFloat()
            // Set the correct size and just move it around
            cornerRect.set(-cornerFloat, -cornerFloat, cornerFloat, cornerFloat)

            if (corners and CORNER_TOP == CORNER_TOP) {
                cornerRect.offsetTo(0F, 0F)
                clipPath.arcTo(cornerRect, 180F, 90F)
                cornerRect.offsetTo( width - 2 * cornerFloat, 0F)
                clipPath.arcTo(cornerRect, 270F, 90F)
            } else {
                clipPath.moveTo(0F, 0F)
                clipPath.lineTo(width.toFloat(), 0F)
            }

            if (corners and CORNER_BOTTOM == CORNER_BOTTOM) {
                cornerRect.offsetTo(width - 2 * cornerFloat, height - 2 * cornerFloat)
                clipPath.arcTo(cornerRect, 0F, 90F)
                cornerRect.offsetTo(0f, height - 2 * cornerFloat)
                clipPath.arcTo(cornerRect, 90F, 90F)
            } else {
                clipPath.lineTo(width.toFloat(), height.toFloat())
                clipPath.lineTo(0F, height.toFloat())
            }

            // Connect the bottom left corner and the bottom right corner
            clipPath.close()
        }
    }

    companion object {
        const val CORNER_NONE = 0
        const val CORNER_TOP = 1
        const val CORNER_BOTTOM = 2
    }
}
