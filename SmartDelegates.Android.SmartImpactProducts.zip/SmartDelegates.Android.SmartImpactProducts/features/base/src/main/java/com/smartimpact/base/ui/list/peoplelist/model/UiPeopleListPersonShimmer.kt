package com.smartimpact.base.ui.list.peoplelist.model

internal data class UiPeopleListPersonShimmer(
        val shimmerVariance: Int
): BaseUiPeopleListModel
