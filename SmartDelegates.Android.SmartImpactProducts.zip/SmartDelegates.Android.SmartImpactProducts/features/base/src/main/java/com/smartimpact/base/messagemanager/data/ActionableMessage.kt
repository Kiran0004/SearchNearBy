package com.smartimpact.base.messagemanager.data

import androidx.annotation.StringRes

data class ActionableMessage(
        val text: String?,
        @StringRes val textRes: Int?,
        val onAction: () -> Unit
) {

    constructor(text: String, onAction: () -> Unit) : this(text, null, onAction)

    constructor(@StringRes textRes: Int, onAction: () -> Unit) : this(null, textRes, onAction)

}
