package com.smartimpact.base.ui.widget

import android.content.Context
import android.net.Uri
import android.util.AttributeSet
import android.util.Log
import androidx.annotation.Px
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.smartimpact.base.R
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.widget_avatar_view.view.*
import java.io.File
import java.lang.Exception

class AvatarView(context: Context?, attrs: AttributeSet? = null) : ConstraintLayout(context, attrs) {

    private lateinit var imageLoader: ImageLoader

    var placeholderText: CharSequence?
        get() {
            return tvPlaceholder.text
        }
        set(value) {
            tvPlaceholder.isVisible = value != null

            if (value != null) {
                val shortenedText = shortenedPlaceholderText(value.toString())
                tvPlaceholder.text = shortenedText
            }
        }

    init {
        inflate(context, R.layout.widget_avatar_view, this)
    }

    override fun setOnClickListener(l: OnClickListener?) {
        viClickTarget.setOnClickListener(l)
    }

    fun inject(imageLoader: ImageLoader) {
        this.imageLoader = imageLoader
    }

    fun setData(placeholderText: String?, imageUrl: String?) {
        this.placeholderText = placeholderText

        val pref = context!!.getSharedPreferences("PROFILE_PIC", Context.MODE_PRIVATE)
        var imageUri = pref.getString("image",null)
        try{
            if(imageUri!=null){
                Log.d("File path:",":::"+imageUri)
                setData(Uri.fromFile(File(imageUri)))
            }else{
                setImageUrl(imageUrl)
            }
        }catch (ex:Exception){
            setImageUrl(imageUrl)
        }

    }

    fun setData(imageUri: Uri?) {
        ivAvatar.setImageURI(imageUri)
    }



    fun setImageUrl(imageUrl: String?) {
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .override(300, 300)
                .fitCenter()
                .placeholder(R.drawable.empty_image_placeholder)
                .into(ivAvatar)
      // imageLoader.load(imageUrl, ivAvatar)
    }

    fun setBorderWidth(@Px borderWidth: Int) {
        ivBackground.setBorderWidth(borderWidth)
        ivAvatar.setBorderWidth(borderWidth)
    }

    private fun shortenedPlaceholderText(text: String): String {
        val trimmedText = text.trim()

        if (trimmedText.length <= 2) {
            return trimmedText
        }

        val firstLetter = trimmedText[0].toString()

        val indexOfSpace = trimmedText.indexOf(" ")
        val secondLetter = if (indexOfSpace == -1) {
            trimmedText[1]
        } else {
            trimmedText[indexOfSpace + 1]
        }

        return firstLetter + secondLetter
    }

}
