package com.smartimpact.base.manager.pushnotification

import android.app.Activity
import android.content.res.Resources
import com.smartimpact.appcenter.pushes.PushNotificationActionHandler
import com.smartimpact.base.manager.notification.NotificationManager

class PushNotificationActionHandlerManager(
        private val notificationManager: NotificationManager,
        private val inAppPushNotificationManager: InAppPushNotificationManager,
        private val resources: Resources) : PushNotificationActionHandler {

    override fun onForegroundPushReceived(customData: MutableMap<String, String>) {
        handleNotification(null, customData)
    }

    override fun onBackgroundPushReceived(activity: Activity?, customData: MutableMap<String, String>) {
        handleNotification(activity, customData)
    }

    private fun handleNotification(activity: Activity?, customData: MutableMap<String, String>) {
        if (customData.containsKey(DATA_CHAT_ID)) {
            val chatId = customData[DATA_CHAT_ID]
            val title = customData[DATA_TITLE]
            val content = customData[DATA_MESSAGE_CONTENT]
            val senderName = customData[DATA_SENDER_NAME]

            if (!chatId.isNullOrBlank()) {
                if (activity != null) {
                    activity.intent.putExtra(DATA_CHAT_ID, chatId)
                } else {
                    // if app in foreground show this notification
                    if (title != null && content != null) {
                        notificationManager.showInboxNotification(chatId, title, content)
                    }
                    inAppPushNotificationManager.notifyPushReceived(chatId)
                }
            }
        }

    }

    companion object {
        private const val DATA_CHAT_ID = "chatId"
        private const val DATA_TITLE = "title"
        private const val DATA_SENDER_NAME = "senderName"
        private const val DATA_MESSAGE_CONTENT = "messageContent"
    }
}