package com.smartimpact.base.ui.widget

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import com.smartimpact.base.R
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.widget_list_tile.view.*

class ListTile(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {

    var titleText: CharSequence?
        get() {
            return tvText.text
        }
        set(value) {
            tvTitle.text = value
            tvTitle.isVisible = value != null

            updateLooks()
        }

    var text: CharSequence?
        get() {
            return tvText.text
        }
        set(value) {
            tvText.text = value
            tvText.isVisible = value != null

            updateLooks()
        }

    var detailsText: CharSequence?
        get() {
            return tvDetails.text
        }
        set(value) {
            tvDetails.text = value
            tvDetails.isVisible = value != null

            updateLooks()
        }

    var trailingText: CharSequence?
        get() {
            return tvTrailing.text
        }
        set(value) {
            tvTrailing.text = value
            tvTrailing.isVisible = value != null

            updateLooks()
        }

    init {
        inflate(context, R.layout.widget_list_tile, this)

        setBackgroundResource(R.drawable.bg_color_background_ripple_secondary)

        context.withStyledAttributes(attrs, R.styleable.ListTile) {
            setLeadingImageResource(getResourceId(R.styleable.ListTile_leadingImage, 0))
            titleText = getString(R.styleable.ListTile_titleText)
            text = getString(R.styleable.ListTile_android_text)
            detailsText = getString(R.styleable.ListTile_detailsText)
            trailingText = getString(R.styleable.ListTile_trailingText)
        }
    }

    fun inject(imageLoader: ImageLoader) {
        viAvatar.inject(imageLoader)
    }

    fun setLeadingImageResource(@DrawableRes resId: Int) {
        ivLeadingImage.setImageResource(resId)
    }

    fun setText(@StringRes resId: Int?) {
        tvText.isVisible = (resId != null && resId != 0)

        if (resId != null) {
            tvText.setText(resId)
        }

        updateLooks()
    }

    fun setAvatarViewData(placeholderText: String?, imageUrl: String?) {
        viAvatar.isVisible = placeholderText != null || imageUrl != null
        viAvatar.setData(placeholderText, imageUrl)

        updateLooks()
    }

    private fun updateLooks() {
        adjustCenterTextsConstraints()
        adjustCenterHeightMeasurer()

        post {
            adjustCenterBasedOnTrailingText()
        }
    }

    private fun adjustCenterTextsConstraints() {
        tvTitle.updateLayoutParams<LayoutParams> {
            bottomToTop = if (tvText.isVisible) {
                tvText.id
            } else {
                tvDetails.id
            }
        }

        tvDetails.updateLayoutParams<LayoutParams> {
            topToBottom = if (tvText.isVisible) {
                tvText.id
            } else {
                tvTitle.id
            }

        }
    }

    private fun adjustCenterHeightMeasurer() {
        centerHeightMeasurer.updateLayoutParams<LayoutParams> {
            topToTop = when {
                tvTitle.isVisible -> tvTitle.id
                tvText.isVisible -> tvText.id
                else -> tvDetails.id
            }

            bottomToBottom = when {
                tvDetails.isVisible -> tvDetails.id
                tvText.isVisible -> tvText.id
                tvTitle.isVisible -> tvTitle.id
                else -> tvDetails.id
            }
        }
    }

    private fun adjustCenterBasedOnTrailingText() {
        val centerHeight = centerHeightMeasurer.height
        val trailingHeight = tvTrailing.height

        tvTitle.updateLayoutParams<LayoutParams> {
            verticalBias = if ((centerHeight >= trailingHeight) || tvTrailing.isGone) {
                0.5f
            } else {
                0f
            }
        }
    }

}
