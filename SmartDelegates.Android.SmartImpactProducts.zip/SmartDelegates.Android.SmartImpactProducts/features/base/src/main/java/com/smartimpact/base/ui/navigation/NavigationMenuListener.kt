package com.smartimpact.base.ui.navigation

import com.smartimpact.base.ui.navigation.model.NavigationMenuItem


interface NavigationMenuListener {

    // For dynamic menu items
    fun onNavigationMenuItemClicked(menuItem: NavigationMenuItem, hasChanged: Boolean)

    // Static menu item
    fun onNavigationProfileClicked()
    fun onNavigationEditProfileClicked()

    fun onBackToAppChoiceClicked()

}
