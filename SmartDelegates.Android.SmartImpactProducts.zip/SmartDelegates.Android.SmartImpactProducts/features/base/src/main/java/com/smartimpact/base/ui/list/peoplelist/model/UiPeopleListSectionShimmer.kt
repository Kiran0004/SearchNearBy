package com.smartimpact.base.ui.list.peoplelist.model

internal class UiPeopleListSectionShimmer : BaseUiPeopleListModel
