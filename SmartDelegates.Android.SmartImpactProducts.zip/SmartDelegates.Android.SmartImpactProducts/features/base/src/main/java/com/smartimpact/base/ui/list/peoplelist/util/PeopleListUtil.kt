package com.smartimpact.base.ui.list.peoplelist.util

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.ui.list.peoplelist.PeopleListDiffUtilCallback
import com.smartimpact.base.ui.list.peoplelist.model.*

object PeopleListUtil {

    fun createShimmers(shouldIncludeGroupShimmer: Boolean, numOfPersonShimmerItems: Int = 10): List<BaseUiPeopleListModel> {
        val shimmerItems = mutableListOf<BaseUiPeopleListModel>()

        if (shouldIncludeGroupShimmer) {
            shimmerItems.add(UiPeopleListSectionShimmer())
        }

        val personShimmers = (0 until numOfPersonShimmerItems).map { shimmerVariance ->
            UiPeopleListPersonShimmer(shimmerVariance)
        }
        shimmerItems.addAll(personShimmers)

        return shimmerItems
    }

    fun sortAndGroup(list: List<BaseUiPeopleListPerson>): List<BaseUiPeopleListModel> {
        val result = mutableListOf<BaseUiPeopleListModel>()

        var currentSection = ""
        list.sortedBy { person ->
            person.nameText
        }.forEach { person ->
            val section = person.nameText?.getOrNull(0)?.toString() ?: ""
            if (currentSection != section) {
                currentSection = section
                result.add(UiPeopleListSection(section))
            }
            result.add(person)
        }

        return result
    }

    fun computeDiffResult(oldList: List<BaseUiPeopleListModel>, newList: List<BaseUiPeopleListModel>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(PeopleListDiffUtilCallback(oldList, newList))
    }

}
