package com.smartimpact.base.ui.widget.image

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView

open class CircleImageView(context: Context, attrs: AttributeSet?) : AppCompatImageView(context, attrs) {

    // Make sure that the sides are the same size for a good look.

    private val cornerRect = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        canvas.clipPath(clipPath)
        super.onDraw(canvas)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recalculateClipPath(w / 2)
    }

    private fun recalculateClipPath(cornerRadius: Int) {
        clipPath.rewind()
        val cornerFloat = cornerRadius.toFloat()
        // Set the correct size and just move it around
        cornerRect.set(-cornerFloat, -cornerFloat, cornerFloat, cornerFloat)
        cornerRect.offsetTo(0F, 0F)
        clipPath.arcTo(cornerRect, 180F, 90F)
        cornerRect.offsetTo(width - 2 * cornerFloat, 0F)
        clipPath.arcTo(cornerRect, 270F, 90F)
        cornerRect.offsetTo(width - 2 * cornerFloat, height - 2 * cornerFloat)
        clipPath.arcTo(cornerRect, 0F, 90F)
        cornerRect.offsetTo(0f, height - 2 * cornerFloat)
        clipPath.arcTo(cornerRect, 90F, 90F)
        // Connect the bottom left corner and the bottom right corner
        clipPath.close()
    }
}
