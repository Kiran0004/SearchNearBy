package com.smartimpact.base.data.repository.contactdetails

import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contactdetails.ContactDetailsLocalSourceImpl
import com.smartimpact.cache.contactdetails.dao.ContactDetailsDao
import com.smartimpact.cache.contactdetails.mapper.ContactDetailsLocalMapper
import com.smartimpact.data.contactdetails.source.local.ContactDetailsLocalSource
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object ContactDetailsRepositoryModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideContactDetailsLocalSource(
            contactDetailsDao: ContactDetailsDao,
            contactDetailsLocalMapper: ContactDetailsLocalMapper
    ): ContactDetailsLocalSource {
        return ContactDetailsLocalSourceImpl(
                contactDetailsDao,
                contactDetailsLocalMapper
        )
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideContactDetailsDao(cacheDatabase: CacheDatabase): ContactDetailsDao {
        return cacheDatabase.contactDetailsDao()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideContactDetailsLocalMapper(): ContactDetailsLocalMapper {
        return ContactDetailsLocalMapper()
    }

}
