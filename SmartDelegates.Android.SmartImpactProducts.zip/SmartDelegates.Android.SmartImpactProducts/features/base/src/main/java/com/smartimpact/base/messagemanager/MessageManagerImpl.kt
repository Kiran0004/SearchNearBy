package com.smartimpact.base.messagemanager

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.messagemanager.data.ActionableMessage
import com.smartimpact.base.messagemanager.data.DismissMessage
import com.smartimpact.base.messagemanager.data.PlainMessage
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject

class MessageManagerImpl(
        private val errorMessageManager: ErrorMessageManager
) : MessageManager {

    private var isShowingActionableMessage: Boolean = false

    private var lock: ActionableMessagesLock? = null

    // region output -------------------------------------------------------------------------------

    // showPlainMessage
    private val showPlainMessageSubject = PublishSubject.create<PlainMessage>()

    override val outShowPlainMessage: Observable<PlainMessage>
        get() = showPlainMessageSubject

    // showActionableMessage
    private val showActionableMessageSubject = PublishSubject.create<ActionableMessage>()

    override val outShowActionableMessage: Observable<ActionableMessage>
        get() = showActionableMessageSubject

    // dismissMessage
    private val dismissMessageSubject = PublishSubject.create<DismissMessage>()

    override val outDismissMessage: Observable<DismissMessage>
        get() = dismissMessageSubject

    // endregion -----------------------------------------------------------------------------------

    // region input --------------------------------------------------------------------------------

    override fun handlePlainMessage(textRes: Int) {
        if (isShowingActionableMessage) {
            return
        }

        val plainMessage = PlainMessage(textRes)
        showPlainMessageSubject.onNext(plainMessage)
    }

    override fun handlePlainMessage(text: String) {
        if (isShowingActionableMessage) {
            return
        }

        val plainMessage = PlainMessage(text)
        showPlainMessageSubject.onNext(plainMessage)
    }

    override fun handlePlainMessage(throwable: Throwable) {
        val text = errorMessageManager.getErrorMessage(throwable)
        handlePlainMessage(text)
    }

    override fun handleActionableMessage(textRes: Int) {
        val actionableMessage = ActionableMessage(textRes, onAction = ::onActionableMessageAction)

        isShowingActionableMessage = true
        showActionableMessageSubject.onNext(actionableMessage)
    }

    override fun handleActionableMessage(text: String) {
        val actionableMessage = ActionableMessage(text, onAction = ::onActionableMessageAction)

        isShowingActionableMessage = true
        showActionableMessageSubject.onNext(actionableMessage)
    }

    override fun handleActionableMessage(throwable: Throwable) {
        val text = errorMessageManager.getErrorMessage(throwable)
        handleActionableMessage(text)
    }

    override fun setActionableMessagesLock(lock: ActionableMessagesLock) {
        this.lock = lock
    }

    override fun releaseActionableMessagesLock() {
        this.lock = null

        if (isShowingActionableMessage) {
            isShowingActionableMessage = false
            dismissMessageSubject.onNext(DismissMessage)
        }
    }

    // endregion -----------------------------------------------------------------------------------

    private fun onActionableMessageAction() {
        isShowingActionableMessage = false
        lock?.onAction?.invoke()
    }

}
