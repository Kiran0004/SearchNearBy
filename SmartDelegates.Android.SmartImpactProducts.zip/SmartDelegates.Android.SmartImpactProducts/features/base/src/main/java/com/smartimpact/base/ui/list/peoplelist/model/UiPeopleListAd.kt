package com.smartimpact.base.ui.list.peoplelist.model

import com.smartimpact.data.ads.entity.AdEntity

data class UiPeopleListAd(
        val variants: List<AdEntity>
) : BaseUiPeopleListModel
