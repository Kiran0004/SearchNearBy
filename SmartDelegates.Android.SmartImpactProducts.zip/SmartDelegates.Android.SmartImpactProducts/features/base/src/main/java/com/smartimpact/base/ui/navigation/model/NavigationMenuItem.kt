package com.smartimpact.base.ui.navigation.model

interface NavigationMenuItem {
    val itemId: Int
    val iconResId: Int
    val titleResId: Int
}
