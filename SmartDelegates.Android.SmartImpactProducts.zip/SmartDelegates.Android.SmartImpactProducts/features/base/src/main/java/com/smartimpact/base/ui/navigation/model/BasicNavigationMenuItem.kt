package com.smartimpact.base.ui.navigation.model

data class BasicNavigationMenuItem(
        override val itemId: Int,
        override val iconResId: Int,
        override val titleResId: Int
) : NavigationMenuItem
