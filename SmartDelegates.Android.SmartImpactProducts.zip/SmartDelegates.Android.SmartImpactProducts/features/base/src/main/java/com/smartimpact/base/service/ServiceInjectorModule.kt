package com.smartimpact.base.service.auth

import com.smartimpact.base.ui.ActivityScope
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
interface ServiceInjectorModule {

    @ActivityScope
    @ContributesAndroidInjector
    fun contributeMainActivityInjector(): AuthService

}

