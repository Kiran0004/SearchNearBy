package com.smartimpact.base.ui.image

import androidx.fragment.app.Fragment
import com.smartimpact.image.ImageLoader
import com.smartimpact.image.glide.GlideImageLoader
import dagger.Module
import dagger.Provides
import dagger.Reusable

@Module
object GlideFragmentModule {

    @JvmStatic
    @Provides @Reusable fun provideImageLoader(fragment: Fragment): ImageLoader {
        return GlideImageLoader(fragment.requireContext())
    }
    
}