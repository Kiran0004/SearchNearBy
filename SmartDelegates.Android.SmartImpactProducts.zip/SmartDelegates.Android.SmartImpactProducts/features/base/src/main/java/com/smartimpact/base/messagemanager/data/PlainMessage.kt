package com.smartimpact.base.messagemanager.data

import androidx.annotation.StringRes

data class PlainMessage(
        val text: String?,
        @StringRes val textRes: Int?
) {

    constructor(text: String) : this(text, null)

    constructor(@StringRes textRes: Int) : this(null, textRes)

}
