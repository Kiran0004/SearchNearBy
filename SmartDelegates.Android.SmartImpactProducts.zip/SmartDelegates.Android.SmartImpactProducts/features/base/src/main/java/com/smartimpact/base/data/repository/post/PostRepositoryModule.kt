package com.smartimpact.base.data.repository.post

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.post.PostLocalSourceImpl
import com.smartimpact.cache.post.dao.PostDao
import com.smartimpact.cache.post.mapper.PostLocalMapper
import com.smartimpact.data.post.source.local.PostLocalSource
import com.smartimpact.data.post.source.remote.PostRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.post.PostRemoteSourceImpl
import com.smartimpact.remote.post.mapper.PostRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object PostRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun providePostLocalMapper(): PostLocalMapper {
        return PostLocalMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun providePostDao(cacheDatabase: CacheDatabase): PostDao {
        return cacheDatabase.postDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun providePostLocalSource(dao: PostDao, localMapper: PostLocalMapper): PostLocalSource {
        return PostLocalSourceImpl(dao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun providePostRemoteMapper(contactRemoteMapper: ContactRemoteMapper): PostRemoteMapper {
        return PostRemoteMapper(contactRemoteMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun providePostRemoteSource(apiService: ApiService, remoteMapper: PostRemoteMapper, profileManager: ProfileManager): PostRemoteSource {
        return PostRemoteSourceImpl(apiService, remoteMapper, profileManager)
    }

}