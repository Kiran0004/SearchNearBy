package com.smartimpact.base.ui.list.peoplelist.model

internal class UiPeopleListSection(
        val text: String
) : BaseUiPeopleListModel
