package com.smartimpact.base.ui.list.peoplelist

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

interface PeopleListAdapterListener {

    fun onAdClicked(adUrl: String)
    fun onPersonClicked(person: BaseUiPeopleListPerson)

}
