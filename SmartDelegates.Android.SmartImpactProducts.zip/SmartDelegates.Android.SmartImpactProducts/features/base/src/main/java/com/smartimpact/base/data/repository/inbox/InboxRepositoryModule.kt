package com.smartimpact.base.data.repository.inbox

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contact.mapper.ContactLocalMapper
import com.smartimpact.cache.inbox.InboxLocalSourceImpl
import com.smartimpact.cache.inbox.dao.InboxDao
import com.smartimpact.cache.inbox.mapper.InboxLocalMapper
import com.smartimpact.data.inbox.source.local.InboxLocalSource
import com.smartimpact.data.inbox.source.remote.InboxRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.inbox.InboxRemoteSourceImpl
import com.smartimpact.remote.inbox.mapper.InboxRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object InboxRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideInboxLocalMapper(contactLocalMapper: ContactLocalMapper): InboxLocalMapper {
        return InboxLocalMapper(contactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideInboxDao(cacheDatabase: CacheDatabase): InboxDao {
        return cacheDatabase.inboxDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideInboxLocalSource(inboxDao: InboxDao, localMapper: InboxLocalMapper): InboxLocalSource {
        return InboxLocalSourceImpl(inboxDao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideInboxRemoteMapper(contactRemoteMapper: ContactRemoteMapper): InboxRemoteMapper {
        return InboxRemoteMapper(contactRemoteMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideInboxRemoteSource(apiService: ApiService, remoteMapper: InboxRemoteMapper, profileManager: ProfileManager): InboxRemoteSource {
        return InboxRemoteSourceImpl(apiService, remoteMapper, profileManager)
    }

}