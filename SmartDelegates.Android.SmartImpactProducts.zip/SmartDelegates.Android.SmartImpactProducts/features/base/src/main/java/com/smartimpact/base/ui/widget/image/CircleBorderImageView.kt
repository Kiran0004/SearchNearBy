package com.smartimpact.base.ui.widget.image

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import androidx.annotation.Px

class CircleBorderImageView(context: Context, attrs: AttributeSet? = null) : CircleImageView(context, attrs) {

    private var borderWidth = 0
    private val borderPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    fun setBorderWidth(@Px borderWidth: Int) {
        this.borderWidth = borderWidth
        borderPaint.strokeWidth = borderWidth.toFloat()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (borderWidth > 0) {
            drawBorder(canvas)
        }
    }

    private fun drawBorder(canvas: Canvas) {
        val centerX = (width / 2).toFloat()
        val centerY = (height / 2).toFloat()
        val radius = (width / 2 - borderWidth / 2).toFloat()
        canvas.drawCircle(centerX, centerY, radius, borderPaint)
    }
}
