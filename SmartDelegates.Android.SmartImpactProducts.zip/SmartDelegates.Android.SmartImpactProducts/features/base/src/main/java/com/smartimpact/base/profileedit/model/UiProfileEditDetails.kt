package com.smartimpact.base.ui.profileedit.model

import android.net.Uri

data class UiProfileEditDetails(
        val name: String?,
        val occupation: String?,
        val biography: String?,
        val twitter: String?,
        val facebook: String?,
        val linkedIn: String?,
        val imageUrl: String?,
        val crmId:String,
        val imageUri: Uri?
)
