package com.smartimpact.base.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.base.R

class ContainerButton(context: Context, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    init {
        setBackgroundResource(R.drawable.bg_color_transparent_ripple_primary_rounded_corners_8)
    }

}
