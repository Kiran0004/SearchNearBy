package com.smartimpact.base.ui.widget.motion

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.constraintlayout.motion.widget.MotionLayout

class SelectiveMotionLayout(context: Context, attrs: AttributeSet?) : MotionLayout(context, attrs) {

    private val selection = mutableListOf<View>()
    private val boundsRect = Rect()

    fun setViewSelection(views: List<View>) {
        selection.clear()
        selection.addAll(views)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val inSelection = selection.any { view ->
            boundsRect.set(view.left, view.top, view.right, view.bottom)
            val historySize = event.historySize
            val x = if (historySize > 0) event.getHistoricalX(0) else event.x
            val y = if (historySize > 0) event.getHistoricalY(0) else event.y
            boundsRect.contains(x.toInt(), y.toInt())
        }
        return if (inSelection) {
            super.onTouchEvent(event)
        } else {
            if (event.action == MotionEvent.ACTION_UP) {
                performClick()
            } else {
                false
            }
        }
    }

    override fun onStartNestedScroll(child: View, target: View, axes: Int, type: Int): Boolean {
        return if (child in selection) {
            super.onStartNestedScroll(child, target, axes, type)
        } else {
            false
        }
    }
}
