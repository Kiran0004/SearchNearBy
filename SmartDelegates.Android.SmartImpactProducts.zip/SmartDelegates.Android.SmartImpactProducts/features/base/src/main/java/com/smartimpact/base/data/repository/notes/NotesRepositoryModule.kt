package com.smartimpact.base.data.repository.notes

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.notes.NotesLocalSourceImpl
import com.smartimpact.cache.notes.dao.NotesDao
import com.smartimpact.cache.notes.mapper.NotesLocalMapper
import com.smartimpact.data.notes.source.local.NotesLocalSource
import com.smartimpact.data.notes.source.remote.NotesRemoteSource
import com.smartimpact.remote.notes.NotesRemoteSourceImpl
import com.smartimpact.remote.notes.mapper.NotesRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object NotesRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideNotesLocalMapper(): NotesLocalMapper {
        return NotesLocalMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNotesDao(cacheDatabase: CacheDatabase): NotesDao {
        return cacheDatabase.notesDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNotesLocalSource(notesDao: NotesDao, notesLocalMapper: NotesLocalMapper): NotesLocalSource {
        return NotesLocalSourceImpl(notesDao, notesLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNotesRemoteMapper(): NotesRemoteMapper {
        return NotesRemoteMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNotesRemoteSource(apiService: ApiService, notesRemoteMapper: NotesRemoteMapper, profileManager: ProfileManager): NotesRemoteSource {
        return NotesRemoteSourceImpl(apiService, notesRemoteMapper, profileManager)
    }

}