package com.smartimpact.base.ui.navigation

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.StyleRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.children
import androidx.core.view.isVisible
import androidx.core.view.setMargins
import androidx.core.widget.TextViewCompat
import com.smartimpact.base.R
import com.smartimpact.base.ui.navigation.model.AdvancedNavigationMenuItem
import com.smartimpact.base.ui.navigation.model.BasicNavigationMenuItem
import com.smartimpact.base.ui.navigation.model.NavigationMenuItem
import kotlinx.android.synthetic.main.navigation_menu_item.view.*
import kotlin.math.roundToInt

class NavigationMenuLayout(context: Context, attrs: AttributeSet?) : LinearLayout(context, attrs) {

    private val margin = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, MENU_ITEM_MARGIN_DP.toFloat(), context.resources.displayMetrics).roundToInt()
    private var selected: Int = 0

    fun setMenuItems(items: List<NavigationMenuItem>, menuListener: NavigationMenuListener) {
        removeAllViews()
        items.forEachIndexed { index, item ->
            val view = getViewFromMenuItem(item)
            val params = ConstraintLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            params.setMargins(margin)
            addView(view, params)
            view.setOnClickListener {
                val hasChanged = (index != selected)
                setIndexOfSelected(index)
                menuListener.onNavigationMenuItemClicked(item, hasChanged)
            }
        }
    }

    fun setIndexOfSelected(selected: Int) {
        children.forEachIndexed { index, view ->
            val activated = index == selected
            view.isActivated = activated
            TextViewCompat.setTextAppearance(view.navItemText, getTextAppearance(activated))
        }
        this.selected = selected
    }

    fun getSelectedIndex(): Int {
        return selected
    }

    private fun getViewFromMenuItem(menuItem: NavigationMenuItem): View {
        val view = View.inflate(context, R.layout.navigation_menu_item, null)
        view.navItemIcon.setImageResource(menuItem.iconResId)
        view.navItemText.text = context.getText(menuItem.titleResId)
        return when (menuItem) {
            is BasicNavigationMenuItem -> handleBasicView(view, menuItem)
            is AdvancedNavigationMenuItem -> handleAdvancedView(view, menuItem)
            else -> throw IllegalArgumentException("Unexpected $menuItem")
        }
    }

    private fun handleBasicView(view: View, menuItem: BasicNavigationMenuItem): View {
        view.navItemBubble.isVisible = false
        return view
    }

    private fun handleAdvancedView(view: View, menuItem: AdvancedNavigationMenuItem): View {
        view.navItemBubble.text = context.getText(menuItem.messageResId)
        view.navItemBubble.isVisible = menuItem.showMessage
        return view
    }

    @StyleRes
    private fun getTextAppearance(activated: Boolean): Int {
        return if (activated) {
            R.style.TextAppearance_SmartImpact_Heading3_Secondary
        } else {
            R.style.TextAppearance_SmartImpact_Body1
        }
    }

    companion object {
        private const val MENU_ITEM_MARGIN_DP = 8
    }
}
