package com.smartimpact.base.data.repository.session

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.session.SessionLocalSourceImpl
import com.smartimpact.cache.session.dao.SessionDao
import com.smartimpact.cache.session.mapper.SessionLocalMapper
import com.smartimpact.data.session.source.local.SessionLocalSource
import com.smartimpact.data.session.source.remote.SessionRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.session.SessionRemoteSourceImpl
import com.smartimpact.remote.session.mapper.SessionRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object SessionRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideSessionLocalMapper(): SessionLocalMapper {
        return SessionLocalMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideSessionDao(cacheDatabase: CacheDatabase): SessionDao {
        return cacheDatabase.sessionDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideSessionLocalSource(sessionDao: SessionDao, sessionLocalMapper: SessionLocalMapper): SessionLocalSource {
        return SessionLocalSourceImpl(sessionDao, sessionLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideSessionRemoteMapper(contactRemoteMapper: ContactRemoteMapper): SessionRemoteMapper {
        return SessionRemoteMapper(contactRemoteMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideSessionRemoteSource(apiService: ApiService, sessionRemoteMapper: SessionRemoteMapper, profileManager: ProfileManager): SessionRemoteSource {
        return SessionRemoteSourceImpl(apiService, sessionRemoteMapper, profileManager)
    }

}