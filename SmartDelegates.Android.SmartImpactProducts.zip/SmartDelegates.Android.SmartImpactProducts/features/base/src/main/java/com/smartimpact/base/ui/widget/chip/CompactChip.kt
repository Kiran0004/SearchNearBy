package com.smartimpact.base.ui.widget.chip

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.DimenRes
import com.google.android.material.chip.Chip
import com.smartimpact.base.R

class CompactChip(context: Context, attrs: AttributeSet? = null) : Chip(context, attrs) {

    private var maxChipHeight = 0

    fun setMaxChipHeight(@DimenRes heightRes: Int) {
        this.maxChipHeight = context.resources.getDimensionPixelSize(heightRes)
        invalidate()
    }

    init {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.CompactChip)
        maxChipHeight = typedArray.getDimensionPixelSize(R.styleable.CompactChip_maxChipHeight, 0)
        typedArray.recycle()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val heightMeasureSpec2 = if (maxChipHeight > 0) {
            MeasureSpec.makeMeasureSpec(maxChipHeight, MeasureSpec.AT_MOST)
        } else {
            heightMeasureSpec
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec2)
    }
}
