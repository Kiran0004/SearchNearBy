package com.smartimpact.base.data.repository.app

import com.smartimpact.cache.appinfo.CacheDataInfoLocalSourceImpl
import com.smartimpact.cache.appinfo.dao.CacheDataInfoDao
import com.smartimpact.cache.appinfo.mapper.CacheDataInfoLocalMapper
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.data.app.source.local.CacheDataInfoLocalSource
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object AppDataRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideCacheDataInfoLocalMapper(): CacheDataInfoLocalMapper {
        return CacheDataInfoLocalMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideCacheDataInfoDao(cacheDatabase: CacheDatabase): CacheDataInfoDao {
        return cacheDatabase.cacheDataInfoDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideCacheDataInfoLocalSource(dao: CacheDataInfoDao, localMapper: CacheDataInfoLocalMapper): CacheDataInfoLocalSource {
        return CacheDataInfoLocalSourceImpl(dao, localMapper)
    }

}