package com.smartimpact.base.data.repository.ads

import com.smartimpact.api.ApiService
import com.smartimpact.cache.ads.AdsLocalSourceImpl
import com.smartimpact.cache.ads.dao.AdsDao
import com.smartimpact.cache.ads.mapper.AdsLocalMapper
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.data.ads.source.local.AdsLocalSource
import com.smartimpact.data.ads.source.remote.AdsRemoteSource
import com.smartimpact.remote.ads.AdsRemoteSourceImpl
import com.smartimpact.remote.ads.mapper.AdsRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object AdsRepositoryModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideAdsLocalSource(
            adsDao: AdsDao,
            adsLocalMapper: AdsLocalMapper
    ): AdsLocalSource {
        return AdsLocalSourceImpl(
                adsDao,
                adsLocalMapper
        )
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideAdsDao(
            cacheDatabase: CacheDatabase
    ): AdsDao {
        return cacheDatabase.adsDao()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideAdsLocalMapper(): AdsLocalMapper {
        return AdsLocalMapper()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideAdsRemoteSource(
            apiService: ApiService,
            adsRemoteMapper: AdsRemoteMapper,
            profileManager: ProfileManager
    ): AdsRemoteSource {
        return AdsRemoteSourceImpl(
                apiService,
                adsRemoteMapper,
                profileManager
        )
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideAdsRemoteMapper(): AdsRemoteMapper {
        return AdsRemoteMapper()
    }

}
