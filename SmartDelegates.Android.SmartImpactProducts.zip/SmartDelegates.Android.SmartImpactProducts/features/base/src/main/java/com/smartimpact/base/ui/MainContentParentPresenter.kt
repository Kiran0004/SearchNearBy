package com.smartimpact.base.ui

interface MainContentParentPresenter {

    fun updateStatusBar(mode: StatusBarMode)
    fun openOnboardingView()
    fun openAppChoiceView()

}
