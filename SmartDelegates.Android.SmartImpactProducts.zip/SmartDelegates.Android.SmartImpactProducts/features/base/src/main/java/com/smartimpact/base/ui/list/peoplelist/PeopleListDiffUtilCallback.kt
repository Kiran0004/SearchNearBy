package com.smartimpact.base.ui.list.peoplelist

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.ui.list.peoplelist.model.*

internal class PeopleListDiffUtilCallback(
        private val oldList: List<BaseUiPeopleListModel>,
        private val newList: List<BaseUiPeopleListModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is BaseUiPeopleListPerson && newItem is BaseUiPeopleListPerson ->
                oldItem.id == newItem.id
            oldItem is UiPeopleListAd && newItem is UiPeopleListAd ->
                oldItem == newItem
            oldItem is UiPeopleListPersonShimmer && newItem is UiPeopleListPersonShimmer ->
                true
            oldItem is UiPeopleListSection && newItem is UiPeopleListSection ->
                oldItem.text == newItem.text
            oldItem is UiPeopleListSectionShimmer && newItem is UiPeopleListSectionShimmer ->
                true
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is BaseUiPeopleListPerson && newItem is BaseUiPeopleListPerson ->
                oldItem == newItem
            oldItem is UiPeopleListAd && newItem is UiPeopleListAd ->
                oldItem == newItem
            oldItem is UiPeopleListPersonShimmer && newItem is UiPeopleListPersonShimmer ->
                true
            oldItem is UiPeopleListSection && newItem is UiPeopleListSection ->
                oldItem == newItem
            oldItem is UiPeopleListSectionShimmer && newItem is UiPeopleListSectionShimmer ->
                true
            else -> false
        }
    }

}
