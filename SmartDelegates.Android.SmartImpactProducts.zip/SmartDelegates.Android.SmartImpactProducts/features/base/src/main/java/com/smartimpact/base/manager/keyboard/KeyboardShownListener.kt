package com.smartimpact.base.manager.keyboard

interface KeyboardShownListener {

    fun onKeyboardShownChanged(shown: Boolean, keyboardHeight: Int)

}
