package com.smartimpact.base.messagemanager

import androidx.annotation.StringRes
import com.smartimpact.base.messagemanager.data.ActionableMessage
import com.smartimpact.base.messagemanager.data.DismissMessage
import com.smartimpact.base.messagemanager.data.PlainMessage
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import io.reactivex.Observable

interface MessageManager {

    val outShowPlainMessage: Observable<PlainMessage>
    val outShowActionableMessage: Observable<ActionableMessage>
    val outDismissMessage: Observable<DismissMessage>

    fun handlePlainMessage(@StringRes textRes: Int)
    fun handlePlainMessage(text: String)
    fun handlePlainMessage(throwable: Throwable)

    fun handleActionableMessage(@StringRes textRes: Int)
    fun handleActionableMessage(text: String)
    fun handleActionableMessage(throwable: Throwable)

    fun setActionableMessagesLock(lock: ActionableMessagesLock)
    fun releaseActionableMessagesLock()

}
