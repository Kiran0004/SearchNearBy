package com.smartimpact.base.data

import com.smartimpact.base.data.api.ApiModule
import com.smartimpact.base.data.repository.RepositoryModule
import com.smartimpact.cache.CacheDatabaseModule
import dagger.Module

@Module(includes = [ApiModule::class, CacheDatabaseModule::class, RepositoryModule::class])
object DataModule