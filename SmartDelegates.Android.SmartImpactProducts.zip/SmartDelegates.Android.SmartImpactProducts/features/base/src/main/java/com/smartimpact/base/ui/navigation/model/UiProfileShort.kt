package com.smartimpact.base.ui.navigation.model

data class UiProfileShort(val name: String, val imageUrl: String?)
