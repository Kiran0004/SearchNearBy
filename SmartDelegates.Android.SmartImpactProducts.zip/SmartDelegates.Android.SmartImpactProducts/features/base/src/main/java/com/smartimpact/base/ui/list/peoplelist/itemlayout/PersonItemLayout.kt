package com.smartimpact.base.ui.list.peoplelist.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.base.R
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.base.ui.widget.chip.CompactChip
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_people_list_person.view.*

internal class PersonItemLayout(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var listener: Listener

    private lateinit var data: BaseUiPeopleListPerson

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onPersonClicked(data)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener

        viAvatar.inject(imageLoader)
    }

    fun bind(data: BaseUiPeopleListPerson) {
        this.data = data

        viAvatar.setData(data.nameText, data.imageUrl)
        tvName.text = data.nameText
        tvBio.text = data.bioText
        updateLabels()
    }

    private fun updateLabels() {
        data.isSponsor?.let{
            if (it) {
                viChips.removeAllViews()

                val chip = CompactChip(context).apply {
                    setMaxChipHeight(R.dimen.is_sponsor_label_height)
                    text = context.getText(R.string.is_sponsor_label_text)
                }
                viChips.addView(chip)
            }
        }

    }

    interface Listener {
        fun onPersonClicked(person: BaseUiPeopleListPerson)
    }

}
