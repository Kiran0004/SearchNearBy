package com.smartimpact.base.data.repository.bookmarks

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.bookmarks.BookmarksLocalSourceImpl
import com.smartimpact.cache.bookmarks.dao.BookmarksDao
import com.smartimpact.cache.bookmarks.mapper.BookmarksLocalMapper
import com.smartimpact.data.bookmarks.source.local.BookmarksLocalSource
import com.smartimpact.data.bookmarks.source.remote.BookmarksRemoteSource
import com.smartimpact.remote.bookmarks.BookmarksRemoteSourceImpl
import com.smartimpact.remote.bookmarks.mapper.BookmarksRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object BookmarksRepositoryModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideBookmarksLocalSource(
            bookmarksDao: BookmarksDao,
            bookmarksLocalMapper: BookmarksLocalMapper
    ): BookmarksLocalSource {
        return BookmarksLocalSourceImpl(
                bookmarksDao,
                bookmarksLocalMapper
        )
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideBookmarksDao(cacheDatabase: CacheDatabase): BookmarksDao {
        return cacheDatabase.bookmarksDao()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideBookmarksLocalMapper(): BookmarksLocalMapper {
        return BookmarksLocalMapper()
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideBookmarksRemoteSource(
            apiService: ApiService,
            remoteMapper: BookmarksRemoteMapper,
            profileManager: ProfileManager
    ): BookmarksRemoteSource {
        return BookmarksRemoteSourceImpl(
                apiService,
                remoteMapper,
                profileManager
        )
    }

    @JvmStatic
    @Provides
    @Singleton
    fun provideBookmarksRemoteMapper(): BookmarksRemoteMapper {
        return BookmarksRemoteMapper()
    }

}
