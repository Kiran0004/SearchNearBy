package com.smartimpact.base.manager.logout

import android.os.HandlerThread
import android.os.Process
import com.smartimpact.appcenter.AppCenterManager
import com.smartimpact.auth.AccountManager
import com.smartimpact.cache.CacheDatabaseManager
import io.reactivex.Completable
import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers

class LogoutManager(
        private val accountManager: AccountManager,
        private val appCenterManager: AppCenterManager,
        private val cacheDatabaseManager: CacheDatabaseManager) {

    private var logoutScheduler: Scheduler? = null

    fun logout(): Completable {
        initLogoutScheduler()
        // TODO unregister pushes, clear chaches ...
        return Completable.fromCallable { accountManager.removeUser() }
                .andThen(appCenterManager.logout())
                .andThen(cacheDatabaseManager.clearDatabase())
                .subscribeOn(logoutScheduler)
    }

    private fun initLogoutScheduler() {
        if (logoutScheduler == null) {
            // TODO shutdown thread?
            val logoutThread = HandlerThread("accountLogout", Process.THREAD_PRIORITY_BACKGROUND)
            logoutThread.start()
            logoutScheduler = AndroidSchedulers.from(logoutThread.looper)
        }
    }
}