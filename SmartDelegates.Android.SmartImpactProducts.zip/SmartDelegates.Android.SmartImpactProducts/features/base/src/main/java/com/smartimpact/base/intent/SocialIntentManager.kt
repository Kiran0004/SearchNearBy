package com.smartimpact.base.intent

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.smartimpact.base.R

class SocialIntentManager(private val context: Context) {

    fun getEmailIntent(email: String): Intent? {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = getEmailUri(email)
        }
        return if (canHandle(intent)) {
            Intent.createChooser(intent, context.getString(R.string.profile_send_email))
        } else {
            null
        }
    }

    fun getWebsiteIntent(url: String): Intent? {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        return if (canHandle(intent)) {
            intent
        } else {
            null
        }
    }

    fun getTwitterIntent(twitter: String): Intent? {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = getTwitterUri(twitter)
        }
        return if (canHandle(intent)) {
            intent
        } else {
            null
        }
    }

    fun getTweetUrlIntent(tweetUrl: String?): Intent? {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(tweetUrl)
        }
        return if (canHandle(intent)) {
            intent
        } else {
            null
        }
    }

    private fun canHandle(intent: Intent): Boolean {
        return intent.resolveActivity(context.packageManager) != null
    }

    private fun getEmailUri(email: String): Uri {
        return Uri.parse("mailto:$email")
    }

    private fun getTwitterUri(twitter: String): Uri {
        val profile = twitter.removePrefix("@")
        return Uri.parse("https://twitter.com/$profile")
    }

}
