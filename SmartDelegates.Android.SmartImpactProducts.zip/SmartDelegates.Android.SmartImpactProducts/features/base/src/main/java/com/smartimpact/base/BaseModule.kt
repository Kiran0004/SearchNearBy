package com.smartimpact.base

import com.smartimpact.base.data.DataModule
import com.smartimpact.base.manager.ManagerModule
import com.smartimpact.base.service.auth.ServiceInjectorModule
import dagger.Module

@Module(includes = [
    AndroidModule::class,
    ManagerModule::class,
    DataModule::class,
    ServiceInjectorModule::class
])
object BaseModule