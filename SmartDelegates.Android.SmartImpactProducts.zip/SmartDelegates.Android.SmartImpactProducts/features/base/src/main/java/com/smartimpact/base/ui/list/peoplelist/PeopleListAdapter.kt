package com.smartimpact.base.ui.list.peoplelist

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.R
import com.smartimpact.base.ui.list.peoplelist.itemlayout.PeopleListAdItemLayout
import com.smartimpact.base.ui.list.peoplelist.itemlayout.PeopleListSectionItemLayout
import com.smartimpact.base.ui.list.peoplelist.itemlayout.PersonItemLayout
import com.smartimpact.base.ui.list.peoplelist.model.*
import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

class PeopleListAdapter(
        context: Context,
        private val listener: PeopleListAdapterListener,
        private val imageLoader: ImageLoader,
        private val analyticsManager: AnalyticsManager
) : BaseItemsAdapter<BaseUiPeopleListModel, PeopleListAdapter.BaseVH>(context) {

    private val peopleListAdItemLayoutListener = object : AdView.Listener {
        override fun onAdClicked(adUrl: String) {
            listener.onAdClicked(adUrl)
        }
    }

    private val personItemLayoutListener = object : PersonItemLayout.Listener {
        override fun onPersonClicked(person: BaseUiPeopleListPerson) {
            listener.onPersonClicked(person)
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_AD -> {
                val layout = view as PeopleListAdItemLayout
                layout.inject(peopleListAdItemLayoutListener, imageLoader, analyticsManager)
                AdVH(layout)
            }
            TYPE_PERSON -> {
                val layout = view as PersonItemLayout
                layout.inject(personItemLayoutListener, imageLoader)
                PersonVH(layout)
            }
            TYPE_SECTION -> {
                val layout = view as PeopleListSectionItemLayout
                SectionVH(layout)
            }
            TYPE_PERSON_SHIMMER_0, TYPE_PERSON_SHIMMER_1, TYPE_SECTION_SHIMMER -> {
                NonBindingVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_AD -> R.layout.item_people_list_ad
            TYPE_PERSON -> R.layout.item_people_list_person
            TYPE_PERSON_SHIMMER_0 -> R.layout.item_people_list_person_shimmer_0
            TYPE_PERSON_SHIMMER_1 -> R.layout.item_people_list_person_shimmer_1
            TYPE_SECTION -> R.layout.item_people_list_section
            TYPE_SECTION_SHIMMER -> R.layout.item_people_list_section_shimmer
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiPeopleListModel, position: Int) {
        holder.bind(item)
    }

    override fun getItemViewType(position: Int): Int {
        return when (val item = getItem(position)) {
            is BaseUiPeopleListPerson -> TYPE_PERSON
            is UiPeopleListAd -> TYPE_AD
            is UiPeopleListPersonShimmer -> determinePersonShimmerType(item)
            is UiPeopleListSection -> TYPE_SECTION
            is UiPeopleListSectionShimmer -> TYPE_SECTION_SHIMMER
            else -> throw IllegalStateException()
        }
    }

    private fun determinePersonShimmerType(personShimmer: UiPeopleListPersonShimmer): Int {
        return when (personShimmer.shimmerVariance % 2) {
            0 -> TYPE_PERSON_SHIMMER_0
            1 -> TYPE_PERSON_SHIMMER_1
            else -> throw IllegalStateException()
        }
    }

    fun setData(data: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(data)
    }

    abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiPeopleListModel)
    }

    private class AdVH(
            override val containerView: PeopleListAdItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiPeopleListModel) {
            containerView.bind(item as UiPeopleListAd)
        }
    }

    private class NonBindingVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiPeopleListModel) {}
    }

    private class PersonVH(
            override val containerView: PersonItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiPeopleListModel) {
            containerView.bind(item as BaseUiPeopleListPerson)
        }
    }

    private class SectionVH(
            override val containerView: PeopleListSectionItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiPeopleListModel) {
            containerView.bind(item as UiPeopleListSection)
        }
    }

    companion object {
        private const val TYPE_AD = 0
        private const val TYPE_PERSON = 1
        private const val TYPE_PERSON_SHIMMER_0 = 2
        private const val TYPE_PERSON_SHIMMER_1 = 3
        private const val TYPE_SECTION = 4
        private const val TYPE_SECTION_SHIMMER = 5
    }

}
