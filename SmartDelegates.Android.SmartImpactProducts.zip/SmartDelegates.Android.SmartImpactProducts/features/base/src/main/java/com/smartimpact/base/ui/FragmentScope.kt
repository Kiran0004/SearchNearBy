package com.smartimpact.base.ui

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class FragmentScope(val value: Int = CONTAINER) {

    companion object {
        const val CONTAINER = 1
        const val FRAGMENT = 2
        const val SUB_FRAGMENT = 3
    }
}
