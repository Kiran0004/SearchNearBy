package com.smartimpact.base.ui.list.peoplelist.model

abstract class BaseUiPeopleListPerson : BaseUiPeopleListModel {
    abstract val id: String
    abstract val imageUrl: String?
    abstract val nameText: String?
    abstract val bioText: String?
    abstract val isSponsor: Boolean?
}
