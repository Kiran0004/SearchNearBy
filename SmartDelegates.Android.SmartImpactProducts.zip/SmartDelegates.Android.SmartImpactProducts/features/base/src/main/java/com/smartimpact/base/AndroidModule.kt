package com.smartimpact.base

import android.accounts.AccountManager
import android.app.DownloadManager
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import android.preference.PreferenceManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object AndroidModule {

    @JvmStatic
    @Provides @Singleton fun provideAccountManager(context: Context): AccountManager {
        return AccountManager.get(context)
    }

    @JvmStatic
    @Provides @Singleton fun provideAndroidSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    @JvmStatic
    @Provides @Singleton fun provideResources(context: Context): Resources {
        return context.resources
    }

    @JvmStatic
    @Provides @Singleton fun provideProcessLifecycleOwner(): LifecycleOwner {
        return ProcessLifecycleOwner.get()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAndroidNotificationManager(context: Context): NotificationManager {
        return context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    @JvmStatic
    @Provides @Singleton fun provideAndroidDownloadManager(context: Context): DownloadManager {
        return ContextCompat.getSystemService(context, DownloadManager::class.java)!!
    }
}