package com.smartimpact.base.service.auth

import android.content.Intent
import android.os.IBinder
import com.smartimpact.auth.AccountAuthenticator
import dagger.android.DaggerService
import javax.inject.Inject

class AuthService : DaggerService() {

    @Inject lateinit var authenticator: AccountAuthenticator

    override fun onBind(intent: Intent): IBinder? {
        return authenticator.iBinder
    }
}
