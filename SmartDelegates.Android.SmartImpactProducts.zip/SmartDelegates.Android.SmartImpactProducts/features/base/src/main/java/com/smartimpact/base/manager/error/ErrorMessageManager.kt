package com.smartimpact.base.manager.error

import android.content.Context
import androidx.annotation.StringRes
import com.smartimpact.appcenter.exception.AppCenterException
import com.smartimpact.appcenter.exception.AppCenterException.Companion.ERROR_CODE_NO_EMAIL
import com.smartimpact.appcenter.exception.AppCenterException.Companion.ERROR_CODE_PARSE

import com.smartimpact.appcenter.exception.AppCenterException.Companion.ERROR_FORGOT_PASSWORD
import com.smartimpact.base.R
import com.smartimpact.calladapter.ApiException
import com.smartimpact.connectivity.ConnectivityStatusManager
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ErrorMessageManager(private val context: Context, private val connectivityStatusManager: ConnectivityStatusManager) {

    fun getErrorMessage(t: Throwable, @StringRes defaultMessage: Int = R.string.error_general_message): String {
        // todo add exceptions
        val cause = when { // some exceptions might be wrapped in a RuntimeException
            t is RuntimeException && t.cause != null -> t.cause
            else -> t
        }

        return when (cause) {
            is UnknownHostException, is SocketTimeoutException -> {
                if (connectivityStatusManager.hasNetwork()) {
                    context.getString(R.string.error_timeout)
                } else {
                    getNoInternetConnectionMessage()
                }
            }
            is AppCenterException -> {
//                if(cause.code.equals(ERROR_FORGOT_PASSWORD)){
//
//                }else{
                    when (cause.code) {
                        ERROR_CODE_NO_EMAIL -> context.getString(R.string.error_app_center_no_email)
                        ERROR_CODE_PARSE -> context.getString(R.string.error_app_center_parse)
                        ERROR_FORGOT_PASSWORD -> "Problem.."
                        else -> context.getString(R.string.error_app_center_general)
                    }
               // }

            }
            is ApiException -> {
                // todo make user friendly
                val errorCode = cause.response.code()
                context.getString(R.string.error_server, errorCode)
            }
            else -> context.getString(defaultMessage)
        }
    }

    private fun getApiMessage(@StringRes defaultMessage: Int): String {
        // TODO add api messages
        return context.getString(defaultMessage)
    }

    private fun getNoInternetConnectionMessage(): String {
        return context.getString(R.string.error_no_internet_connection)
    }
}
