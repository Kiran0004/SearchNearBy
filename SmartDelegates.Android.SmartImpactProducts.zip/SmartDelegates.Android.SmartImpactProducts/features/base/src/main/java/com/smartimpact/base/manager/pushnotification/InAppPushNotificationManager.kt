package com.smartimpact.base.manager.pushnotification

class InAppPushNotificationManager {

    private val listeners: MutableSet<InAppPushNotificationListener> = HashSet()

    fun registerInAppPushNotificationListener(listener: InAppPushNotificationListener) {
        listeners.add(listener)
    }

    fun unregisterInAppPushNotificationListener(listener: InAppPushNotificationListener) {
        listeners.remove(listener)
    }

    fun notifyPushReceived(chatId: String) {
        listeners.forEach {
            it.onPushReceived(chatId)
        }
    }

    interface InAppPushNotificationListener {
        fun onPushReceived(chatId: String)
    }

}