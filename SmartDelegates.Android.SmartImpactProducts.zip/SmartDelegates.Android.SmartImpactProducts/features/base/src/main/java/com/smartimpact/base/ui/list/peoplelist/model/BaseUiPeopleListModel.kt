package com.smartimpact.base.ui.list.peoplelist.model

interface BaseUiPeopleListModel
