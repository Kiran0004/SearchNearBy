package com.smartimpact.base.manager.download

import android.app.DownloadManager
import android.net.Uri
import android.os.Build
import android.os.Environment

class FileDownloadManager(private val androidDownloadManager: DownloadManager) {

    fun download(fileUri: Uri, fileName: String) {
        val request = DownloadManager.Request(fileUri).apply {
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE or DownloadManager.Request.NETWORK_WIFI)
            // From Q on, the file automatically gets scanned
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                allowScanningByMediaScanner()
            }
        }
        androidDownloadManager.enqueue(request)
    }
}
