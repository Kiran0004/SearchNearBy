package com.smartimpact.base.manager.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.TaskStackBuilder
import com.smartimpact.auth.LoginIntentProvider
import com.smartimpact.base.R

class NotificationManager(
        private val context: Context,
        private val androidNotificationManager: NotificationManager,
        private val loginIntentProvider: LoginIntentProvider) {

    fun showInboxNotification(chatId: String, title: String, content: String) {

        val builder = getNotificationBuilder(INBOX_CHANNEL_ID)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            androidNotificationManager.createNotificationChannel(NotificationChannel(INBOX_CHANNEL_ID, context.getString(R.string.notification_inbox_channel_name), NotificationManager.IMPORTANCE_DEFAULT))
        }

        val style = NotificationCompat.InboxStyle()
                .setBigContentTitle(title)
                .addLine(content)

        val notification = builder
                .setStyle(style)
                .setAutoCancel(true)
                .setContentIntent(getPendingIntent(chatId))
                .build()

        showNotification(NEW_MESSAGE_ID, notification)
    }

    private fun getNotificationBuilder(channelId: String): NotificationCompat.Builder {
        return NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
    }

    private fun showNotification(id: Int, notification: Notification) {
        androidNotificationManager.notify(id, notification)
    }

    private fun getPendingIntent(chatId: String): PendingIntent {

        val resultPendingIntent: PendingIntent? = TaskStackBuilder.create(context).run {
            addNextIntent(loginIntentProvider.getLoginIntent(context, chatId))
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
        }

        return resultPendingIntent!!
    }

    companion object {

        const val NEW_MESSAGE_ID = 1
        private const val INBOX_CHANNEL_ID = "com.smartimpact.base.manager.notification.NotificationManager.inbox"
    }
}