package com.smartimpact.base.ui

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.ads.AdsRepositoryImpl
import com.smartimpact.data.news.NewsRepositoryImpl
import com.smartimpact.data.ads.source.local.AdsLocalSource
import com.smartimpact.data.news.source.local.NewsLocalSource
import com.smartimpact.data.ads.source.remote.AdsRemoteSource
import com.smartimpact.data.app.AppDataRepository
import com.smartimpact.data.app.AppDataRepositoryImpl
import com.smartimpact.data.app.source.local.CacheDataInfoLocalSource
import com.smartimpact.data.blog.BlogRepository
import com.smartimpact.data.blog.BlogRepositoryImpl
import com.smartimpact.data.blog.source.local.BlogLocalSource
import com.smartimpact.data.blog.source.remote.BlogRemoteSource
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.bookmarks.BookmarksRepositoryImpl
import com.smartimpact.data.bookmarks.source.local.BookmarksLocalSource
import com.smartimpact.data.bookmarks.source.remote.BookmarksRemoteSource
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.contactdetails.ContactDetailsRepositoryImpl
import com.smartimpact.data.contactdetails.source.local.ContactDetailsLocalSource
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.ContactRepositoryImpl
import com.smartimpact.data.contacts.source.local.ContactLocalSource
import com.smartimpact.data.contacts.source.remote.ContactRemoteSource
import com.smartimpact.data.details.NewsDetailsRepository
import com.smartimpact.data.details.NewsDetailsRepositoryImpl
import com.smartimpact.data.details.source.local.NewsDetailsLocalSource
import com.smartimpact.data.details.source.remote.NewsDetailsRemoteSource
import com.smartimpact.data.hot.HotRepository
import com.smartimpact.data.hot.HotRepositoryImpl
import com.smartimpact.data.hot.source.local.HotLocalSource
import com.smartimpact.data.hot.source.remote.HotRemoteSource
import com.smartimpact.data.inbox.InboxRepository
import com.smartimpact.data.inbox.InboxRepositoryImpl
import com.smartimpact.data.inbox.source.local.InboxLocalSource
import com.smartimpact.data.inbox.source.remote.InboxRemoteSource
import com.smartimpact.data.news.NewsRepository
import com.smartimpact.data.news.source.remote.NewsRemoteSource
import com.smartimpact.data.notes.NotesRepository
import com.smartimpact.data.notes.NotesRepositoryImpl
import com.smartimpact.data.notes.source.local.NotesLocalSource
import com.smartimpact.data.notes.source.remote.NotesRemoteSource
import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.post.PostRepositoryImpl
import com.smartimpact.data.post.source.local.PostLocalSource
import com.smartimpact.data.post.source.remote.PostRemoteSource
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.data.session.SessionRepositoryImpl
import com.smartimpact.data.session.source.local.SessionLocalSource
import com.smartimpact.data.session.source.remote.SessionRemoteSource
import com.smartimpact.remote.bookmarks.mapper.BookmarksRemoteMapper
import dagger.Module
import dagger.Provides

@Module
object MainContentRepositoryModule {

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideAppDataRepository(localSource: CacheDataInfoLocalSource): AppDataRepository {
        return AppDataRepositoryImpl(localSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideAdsRepository(localSource: AdsLocalSource, remoteSource: AdsRemoteSource): AdsRepository {
        return AdsRepositoryImpl(localSource, remoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideSessionRepository(localSource: SessionLocalSource, remoteSource: SessionRemoteSource, appDataRepository: AppDataRepository): SessionRepository {
        return SessionRepositoryImpl(localSource, remoteSource, appDataRepository)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideBookmarksRemoteMapper(): BookmarksRemoteMapper {
        return BookmarksRemoteMapper()
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideNotesRepository(localSource: NotesLocalSource, remoteSource: NotesRemoteSource): NotesRepository {
        return NotesRepositoryImpl(localSource, remoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideContactRepository(localSource: ContactLocalSource, remoteSource: ContactRemoteSource, appDataRepository: AppDataRepository): ContactRepository {
        return ContactRepositoryImpl(localSource, remoteSource, appDataRepository)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideContactDetailsRepository(localSource: ContactDetailsLocalSource, contactRemoteSource: ContactRemoteSource): ContactDetailsRepository {
        return ContactDetailsRepositoryImpl(localSource, contactRemoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideInboxRepository(localSource: InboxLocalSource, remoteSource: InboxRemoteSource, appDataRepository: AppDataRepository): InboxRepository {
        return InboxRepositoryImpl(localSource, remoteSource, appDataRepository)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideNewsRepository(localSource: NewsLocalSource, remoteSource: NewsRemoteSource, appDataRepository: AppDataRepository): NewsRepository {
        return NewsRepositoryImpl(localSource, remoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideHotRepository(localSource: HotLocalSource, remoteSource: HotRemoteSource, appDataRepository: AppDataRepository): HotRepository {
        return HotRepositoryImpl(localSource, remoteSource)
    }



    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideNewsDetailsRepository(localSource: NewsDetailsLocalSource, remoteSource: NewsDetailsRemoteSource, appDataRepository: AppDataRepository): NewsDetailsRepository {
        return NewsDetailsRepositoryImpl(localSource, remoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideBlogRepository(localSource: BlogLocalSource, remoteSource: BlogRemoteSource, appDataRepository: AppDataRepository): BlogRepository {
        return BlogRepositoryImpl(localSource, remoteSource)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun providePostRepository(localSource: PostLocalSource, remoteSource: PostRemoteSource, appDataRepository: AppDataRepository): PostRepository {
        return PostRepositoryImpl(localSource, remoteSource, appDataRepository)
    }

    @JvmStatic
    @Provides @FragmentScope(FragmentScope.CONTAINER)
    fun provideBookmarksRepository(localSource: BookmarksLocalSource, remoteSource: BookmarksRemoteSource, appDataRepository: AppDataRepository): BookmarksRepository {
        return BookmarksRepositoryImpl(localSource, remoteSource, appDataRepository)
    }

}
