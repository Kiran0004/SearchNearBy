package com.smartimpact.base.messagemanager.lock

data class ActionableMessagesLock(
        val onAction: () -> Unit
)
