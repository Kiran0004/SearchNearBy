package com.smartimpact.base.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import com.smartimpact.base.R
import com.smartimpact.image.ImageLoader

class OverlapAvatarView(context: Context, attrs: AttributeSet?) : FrameLayout(context, attrs) {

    private lateinit var imageLoader: ImageLoader
    private var imageSize = 0
    private var imageMargin = 0
    private var imageBorder = 0

    init {
        val array = context.obtainStyledAttributes(attrs, R.styleable.OverlapAvatarView)
        imageSize = array.getDimensionPixelSize(R.styleable.OverlapAvatarView_imageSize, 0)
        imageMargin = array.getDimensionPixelSize(R.styleable.OverlapAvatarView_imageMargin, 0)
        imageBorder = array.getDimensionPixelSize(R.styleable.OverlapAvatarView_imageBorder, 0)
        array.recycle()
    }

    fun inject(imageLoader: ImageLoader) {
        this.imageLoader = imageLoader
    }

    fun setAvatars(avatars: List<Avatar>) {
        removeAllViews()
        invalidate()

        avatars.forEachIndexed { index, avatar ->
            val avatarView = createAvatarView(avatar)
            addView(avatarView, getAvatarViewLayoutParams(index))
        }
    }

    private fun createAvatarView(avatar: Avatar): AvatarView {
        return AvatarView(context).apply {
            inject(imageLoader)
            setBorderWidth(imageBorder)
            setData(avatar.placeholderText, avatar.imageUrl)
        }
    }

    private fun getAvatarViewLayoutParams(index: Int) = MarginLayoutParams(imageSize + imageBorder, imageSize + imageBorder).apply {
        width = imageSize
        height = imageSize
        marginStart = index * imageMargin
    }

    data class Avatar(
            val placeholderText: String?,
            val imageUrl: String?
    )

}
