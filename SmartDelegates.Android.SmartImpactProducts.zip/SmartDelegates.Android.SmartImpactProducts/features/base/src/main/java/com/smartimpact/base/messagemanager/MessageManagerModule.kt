package com.smartimpact.base.messagemanager

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.FragmentScope
import dagger.Module
import dagger.Provides

@Module
class MessageManagerModule {

    @Provides
    @FragmentScope(FragmentScope.CONTAINER)
    fun provideMessageManager(
            errorMessageManager: ErrorMessageManager
    ): MessageManager {
        return MessageManagerImpl(errorMessageManager)
    }

}
