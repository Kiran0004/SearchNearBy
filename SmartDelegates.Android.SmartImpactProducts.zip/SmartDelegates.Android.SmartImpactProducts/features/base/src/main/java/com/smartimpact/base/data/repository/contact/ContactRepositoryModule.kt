package com.smartimpact.base.data.repository.contact

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contact.ContactLocalSourceImpl
import com.smartimpact.cache.contact.dao.ContactDao
import com.smartimpact.cache.contact.mapper.ContactLocalMapper
import com.smartimpact.data.contacts.source.local.ContactLocalSource
import com.smartimpact.data.contacts.source.remote.ContactRemoteSource
import com.smartimpact.remote.contact.ContactRemoteSourceImpl
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object ContactRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideContactLocalMapper(): ContactLocalMapper {
        return ContactLocalMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideContactDao(cacheDatabase: CacheDatabase): ContactDao {
        return cacheDatabase.contactsDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideContactLocalSource(ContactDao: ContactDao, ContactLocalMapper: ContactLocalMapper): ContactLocalSource {
        return ContactLocalSourceImpl(ContactDao, ContactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideContactRemoteMapper(): ContactRemoteMapper {
        return ContactRemoteMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideContactRemoteSource(apiService: ApiService, ContactRemoteMapper: ContactRemoteMapper, profileManager: ProfileManager): ContactRemoteSource {
        return ContactRemoteSourceImpl(apiService, ContactRemoteMapper, profileManager)
    }

}