package com.smartimpact.base.ui.navigation

import android.content.Context
import android.net.Uri
import android.util.AttributeSet
import android.widget.LinearLayout
import androidx.annotation.StyleRes
import androidx.core.widget.TextViewCompat
import com.smartimpact.base.R
import com.smartimpact.base.ui.navigation.model.NavigationMenuItem
import com.smartimpact.base.ui.navigation.model.UiProfileShort
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.navigation_panel.view.*

class NavigationPanelLayout(context: Context, attrs: AttributeSet?) : LinearLayout(context, attrs) {

    fun setProfile(profile: UiProfileShort, imageLoader: ImageLoader, listener: NavigationMenuListener) {
        navHeaderName.text = profile.name
        viAvatar.setOnClickListener {
            listener.onNavigationProfileClicked()
        }
        navHeaderName.setOnClickListener {
            listener.onNavigationProfileClicked()
        }
        btnEditProfile.setOnClickListener {
            listener.onNavigationEditProfileClicked()
        }

        viAvatar.inject(imageLoader)
        viAvatar.setData(profile.name, profile.imageUrl)
    }

    fun setProfile(profile: UiProfileShort, uri: Uri, listener: NavigationMenuListener) {
        navHeaderName.text = profile.name
        viAvatar.setOnClickListener {
            listener.onNavigationProfileClicked()
        }
        navHeaderName.setOnClickListener {
            listener.onNavigationProfileClicked()
        }
        btnEditProfile.setOnClickListener {
            listener.onNavigationEditProfileClicked()
        }

        viAvatar.setData(uri)
    }


    fun setMenuItems(items: List<NavigationMenuItem>, currentMenuItemId: Int, listener: NavigationMenuListener) {
        navMenuLayout.setMenuItems(items, listener)
        navMenuLayout.setIndexOfSelected(getIndexForMenuItemId(items, currentMenuItemId))
        navBackToAsclHome.setOnClickListener {
            listener.onBackToAppChoiceClicked()
        }
    }

    fun getCurrentMenuItem(): Int? {
        return navMenuLayout.getSelectedIndex()
    }

    private fun getIndexForMenuItemId(items: List<NavigationMenuItem>, menuItemId: Int): Int {
        val selected = items.indexOfFirst {
            it.itemId == menuItemId
        }
        check(selected != -1) {
            "No matching menu item found. Current item: $menuItemId, items: $items"
        }
        return selected
    }

}
