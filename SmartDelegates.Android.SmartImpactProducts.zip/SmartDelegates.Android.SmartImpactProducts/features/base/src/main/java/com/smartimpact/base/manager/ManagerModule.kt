package com.smartimpact.base.manager

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import android.view.inputmethod.InputMethodManager
import androidx.lifecycle.LifecycleOwner
import com.google.gson.Gson
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.appcenter.AppCenterManager
import com.smartimpact.appcenter.pushes.PushNotificationActionHandler
import com.smartimpact.auth.AccountAuthenticator
import com.smartimpact.auth.AccountManager
import com.smartimpact.auth.LoginIntentProvider
import com.smartimpact.background.BackgroundManager
import com.smartimpact.base.manager.download.FileDownloadManager
import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.manager.keyboard.KeyboardManager
import com.smartimpact.base.manager.logout.LogoutManager
import com.smartimpact.base.manager.notification.NotificationManager
import com.smartimpact.base.manager.pushnotification.InAppPushNotificationManager
import com.smartimpact.base.manager.pushnotification.PushNotificationActionHandlerManager
import com.smartimpact.cache.CacheDatabaseManager
import com.smartimpact.connectivity.ConnectivityStatusManager
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.update.UpdateManager
import com.smartimpact.userprofile.manager.ProfileManager
import com.smartimpact.version.VersionChecker
import dagger.Module
import dagger.Provides
import dagger.Reusable
import si.kamino.preferences.shared.SharedPreferenceManager
import javax.inject.Singleton

@Module
object ManagerModule {

    @JvmStatic
    @Provides @Singleton
    fun provideConnectivityStatusManager(context: Context): ConnectivityStatusManager {
        return ConnectivityStatusManager(context)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideErrorMessageManager(context: Context, connectivityStatusManager: ConnectivityStatusManager): ErrorMessageManager {
        return ErrorMessageManager(context, connectivityStatusManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideBackgroundManager(processLifecycleOwner: LifecycleOwner): BackgroundManager {
        return BackgroundManager(processLifecycleOwner)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAccountManager(systemAccountManager: android.accounts.AccountManager,
            gson: Gson, preferenceManager: SharedPreferenceManager, resources: Resources): AccountManager {
        return AccountManager(systemAccountManager, gson, preferenceManager, resources)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideSharedPreferencesManager(sharedPreferences: SharedPreferences, gson: Gson): SharedPreferenceManager {
        return SharedPreferenceManager(sharedPreferences, gson)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAccountAuthenticator(context: Context, accountManager: AccountManager,
            intentProvider: LoginIntentProvider, appCenterManager: AppCenterManager): AccountAuthenticator {
        return AccountAuthenticator(context, accountManager, intentProvider, appCenterManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAppCenterManager(connectivityStatusManager: ConnectivityStatusManager, pushNotificationActionHandler: PushNotificationActionHandler): AppCenterManager {
        return AppCenterManager(connectivityStatusManager, pushNotificationActionHandler)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideLogoutManager(accountManager: AccountManager, appCenterManager: AppCenterManager, cacheDatabaseManager: CacheDatabaseManager): LogoutManager {
        return LogoutManager(accountManager, appCenterManager, cacheDatabaseManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideProfileManager(accountManager: AccountManager): ProfileManager {
        return ProfileManager(accountManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideDateTimeFormatUtil(context: Context): DateTimeFormatHelper {
        return DateTimeFormatHelper(context)
    }

    @JvmStatic
    @Provides @Singleton fun provideInputMethodManager(context: Context): InputMethodManager {
        return context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    }

    @JvmStatic
    @Provides @Reusable
    fun provideKeyboardManager(activity: Activity, inputMethodManager: InputMethodManager): KeyboardManager {
        return KeyboardManager(activity, inputMethodManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNotificationManager(context: Context, androidNotificationManager: android.app.NotificationManager, loginIntentProvider: LoginIntentProvider): NotificationManager {
        return NotificationManager(context, androidNotificationManager, loginIntentProvider)
    }

    @JvmStatic
    @Provides @Singleton
    fun providePushNotificationActionHandler(notificationManager: NotificationManager, inAppPushNotificationManager: InAppPushNotificationManager, resources: Resources): PushNotificationActionHandler {
        return PushNotificationActionHandlerManager(notificationManager, inAppPushNotificationManager, resources)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideInAppPushNotificationManager(): InAppPushNotificationManager {
        return InAppPushNotificationManager()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideVersionChecker(context: Context, preferenceManager: SharedPreferenceManager): VersionChecker {
        return VersionChecker(context, preferenceManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideUpdateManager(versionChecker: VersionChecker, accountManager: AccountManager, appCenterManager: AppCenterManager, cacheDatabaseManager: CacheDatabaseManager): UpdateManager {
        return UpdateManager(versionChecker, accountManager, appCenterManager, cacheDatabaseManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideFileDownloadManager(androidDownloadManager: DownloadManager): FileDownloadManager {
        return FileDownloadManager(androidDownloadManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAnalyticsManager(appCenterManager: AppCenterManager): AnalyticsManager {
        return AnalyticsManager(appCenterManager)
    }

}