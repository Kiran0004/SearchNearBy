package com.smartimpact.base.data.api

import dagger.Module
import dagger.multibindings.Multibinds
import okhttp3.Interceptor

@Module
interface ApiBindModule {

    @Multibinds fun multibindInterceptors(): Set<Interceptor>

}
