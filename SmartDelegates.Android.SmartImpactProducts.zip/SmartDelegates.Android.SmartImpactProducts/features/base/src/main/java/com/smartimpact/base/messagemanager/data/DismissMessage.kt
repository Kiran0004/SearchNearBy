package com.smartimpact.base.messagemanager.data

object DismissMessage
