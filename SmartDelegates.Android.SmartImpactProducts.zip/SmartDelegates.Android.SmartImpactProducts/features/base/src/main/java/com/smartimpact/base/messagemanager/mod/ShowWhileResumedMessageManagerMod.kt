package com.smartimpact.base.messagemanager.mod

import androidx.annotation.StringRes
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock

class ShowWhileResumedMessageManagerMod(
        private val messageManager: MessageManager,
        private val onAction: () -> Unit
) {
    private val lock = ActionableMessagesLock(
            onAction = ::onMessageManagerAction
    )

    private var isResumed: Boolean = false

    private val latestPlainMessageStorage = LatestMessageStorage()
    private val latestActionableMessageStorage = LatestMessageStorage()

    fun handlePlainMessage(@StringRes textRes: Int) {
        latestPlainMessageStorage.setLatestMessage(textRes)
        onHandleMessage()
    }

    fun handlePlainMessage(text: String) {
        latestPlainMessageStorage.setLatestMessage(text)
        onHandleMessage()
    }

    fun handlePlainMessage(error: Throwable) {
        latestPlainMessageStorage.setLatestMessage(error)
        onHandleMessage()
    }

    fun handleActionableMessage(@StringRes textRes: Int) {
        latestActionableMessageStorage.setLatestMessage(textRes)
        onHandleMessage()
    }

    fun handleActionableMessage(text: String) {
        latestActionableMessageStorage.setLatestMessage(text)
        onHandleMessage()
    }

    fun handleActionableMessage(error: Throwable) {
        latestActionableMessageStorage.setLatestMessage(error)
        onHandleMessage()
    }

    fun onResume() {
        isResumed = true

        messageManager.setActionableMessagesLock(lock)
        giveMessages()
    }

    fun onPause() {
        isResumed = false

        messageManager.releaseActionableMessagesLock()
    }

    private fun onHandleMessage() {
        if (isResumed) {
            giveMessages()
        }
    }

    private fun giveMessages() {
        if (latestActionableMessageStorage.hasLatestMessage()) {
            latestActionableMessageStorage.apply {
                latestMessageRes?.let { messageManager.handleActionableMessage(it) }
                latestMessageString?.let { messageManager.handleActionableMessage(it) }
                latestMessageThrowable?.let { messageManager.handleActionableMessage(it) }
                clearLatestMessage()
            }
        }

        if (latestPlainMessageStorage.hasLatestMessage()) {
            latestPlainMessageStorage.apply {
                latestMessageRes?.let { messageManager.handlePlainMessage(it) }
                latestMessageString?.let { messageManager.handlePlainMessage(it) }
                latestMessageThrowable?.let { messageManager.handlePlainMessage(it) }
                clearLatestMessage()
            }
        }
    }

    private fun onMessageManagerAction() {
        latestPlainMessageStorage.clearLatestMessage()
        latestActionableMessageStorage.clearLatestMessage()
        onAction()
    }

    private class LatestMessageStorage {

        var latestMessageRes: Int? = null
            private set
        var latestMessageString: String? = null
            private set
        var latestMessageThrowable: Throwable? = null
            private set

        fun setLatestMessage(messageRes: Int) {
            clearLatestMessage()
            latestMessageRes = messageRes
        }

        fun setLatestMessage(messageString: String) {
            clearLatestMessage()
            latestMessageString = messageString
        }

        fun setLatestMessage(throwable: Throwable) {
            clearLatestMessage()
            latestMessageThrowable = throwable
        }

        fun clearLatestMessage() {
            latestMessageRes = null
            latestMessageString = null
            latestMessageThrowable = null
        }

        fun hasLatestMessage(): Boolean {
            return latestMessageRes != null ||
                    latestMessageString != null ||
                    latestMessageThrowable != null
        }

    }

}
