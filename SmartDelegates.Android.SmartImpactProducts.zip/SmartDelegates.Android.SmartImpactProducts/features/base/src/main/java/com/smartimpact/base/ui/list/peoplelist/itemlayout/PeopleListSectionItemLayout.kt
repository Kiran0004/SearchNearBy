package com.smartimpact.base.ui.list.peoplelist.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.smartimpact.base.ui.list.peoplelist.model.UiPeopleListSection

internal class PeopleListSectionItemLayout(context: Context?, attrs: AttributeSet?) : AppCompatTextView(context, attrs) {

    fun bind(data: UiPeopleListSection) {
        text = data.text
    }

}
