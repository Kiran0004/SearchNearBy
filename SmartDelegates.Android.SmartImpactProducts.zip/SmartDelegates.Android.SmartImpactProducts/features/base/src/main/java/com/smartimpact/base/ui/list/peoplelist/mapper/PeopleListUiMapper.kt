package com.smartimpact.base.ui.list.peoplelist.mapper

import com.smartimpact.base.ui.list.peoplelist.model.UiPeopleListAd
import com.smartimpact.data.ads.entity.AdEntity

object PeopleListUiMapper {

    fun mapToUi(adEntities: List<AdEntity>): UiPeopleListAd {
        return UiPeopleListAd(adEntities)
    }

}
