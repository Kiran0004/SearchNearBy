package com.smartimpact.base.data.api.interceptor

import android.util.Log
import com.smartimpact.auth.AccountManager
import okhttp3.Interceptor
import okhttp3.Response

class TokenInterceptor(private val accountManager: AccountManager): Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()

        if (accountManager.isLoggedIn()) {
            val token = accountManager.getToken()

            if (token != null) {
                request = request.newBuilder()
                        .header(HEADER_NAME_TOKEN, "$HEADER_TOKEN_PREFIX$token")
                        .build()
                Log.v("Log1::",request.url.toString())
            }
        }

        return chain.proceed(request)
    }

    companion object {
        const val HEADER_NAME_TOKEN = "Authorization"
        const val HEADER_TOKEN_PREFIX = "Bearer "
    }
}
