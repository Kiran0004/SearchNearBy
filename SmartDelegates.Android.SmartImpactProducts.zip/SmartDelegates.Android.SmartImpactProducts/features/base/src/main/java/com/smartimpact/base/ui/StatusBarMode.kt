package com.smartimpact.base.ui

enum class StatusBarMode {
    PRIMARY, SECONDARY
}
