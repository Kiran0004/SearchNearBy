package com.smartimpact.base.data.repository

import com.smartimpact.base.data.repository.ads.AdsRepositoryModule
import com.smartimpact.base.data.repository.app.AppDataRepositoryModule
import com.smartimpact.base.data.repository.bookmarks.BookmarksRepositoryModule
import com.smartimpact.base.data.repository.contact.ContactRepositoryModule
import com.smartimpact.base.data.repository.contactdetails.ContactDetailsRepositoryModule
import com.smartimpact.base.data.repository.inbox.InboxRepositoryModule
import com.smartimpact.base.data.repository.news.NewsRepositoryModule
import com.smartimpact.base.data.repository.blog.BlogRepositoryModule
import com.smartimpact.base.data.repository.hot.HotRepositoryModule
import com.smartimpact.base.data.repository.details.NewsDetailsRepositoryModule
import com.smartimpact.base.data.repository.notes.NotesRepositoryModule
import com.smartimpact.base.data.repository.post.PostRepositoryModule
import com.smartimpact.base.data.repository.session.SessionRepositoryModule
import dagger.Module

@Module(includes = [
    AdsRepositoryModule::class,
    BookmarksRepositoryModule::class,
    NotesRepositoryModule::class,
    SessionRepositoryModule::class,
    ContactRepositoryModule::class,
    ContactDetailsRepositoryModule::class,
    InboxRepositoryModule::class,
    PostRepositoryModule::class,
    AppDataRepositoryModule::class,
    NewsRepositoryModule::class,
    BlogRepositoryModule::class,
    HotRepositoryModule::class,
    NewsDetailsRepositoryModule::class
])
object RepositoryModule
