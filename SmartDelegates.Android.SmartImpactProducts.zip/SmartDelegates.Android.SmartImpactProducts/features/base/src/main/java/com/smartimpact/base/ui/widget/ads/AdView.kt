package com.smartimpact.base.ui.widget.ads

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.util.Log
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.R
import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.image.ImageLoader
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class AdView(context: Context, attrs: AttributeSet?) : AppCompatImageView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var imageLoader: ImageLoader
    private lateinit var adVariantManager: AdVariantManager
    private lateinit var data: List<AdEntity>
    private lateinit var analyticsManager: AnalyticsManager

    private var disposable: Disposable? = null

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            foreground = ContextCompat.getDrawable(context, R.drawable.bg_color_transparent_ripple_primary)
        }
    }

    override fun onDetachedFromWindow() {
        disposable?.dispose()
        super.onDetachedFromWindow()
    }

    fun inject(imageLoader: ImageLoader, listener: Listener, analyticsManager: AnalyticsManager) {
        this.imageLoader = imageLoader
        this.listener = listener
        this.analyticsManager = analyticsManager

//        setOnClickListener {
//            val adEntity = data.get(adVariantManager.variantIndex)
//            Log.d("Checking the index","==="+adVariantManager.variantIndex)
//            analyticsManager.trackAdClickEvent(adEntity.adUrl!!)
//            listener.onAdClicked(adEntity.adUrl!!)
//        }
    }

    fun bind(ads: List<AdEntity>) {
        data = ads

        adVariantManager = AdVariantManager(data.count())

        adVariantManager.nextRandom()

        disposable = Observable
                .interval(0, 5, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    Log.d("Checking subscribe",":::"+adVariantManager.variantIndex)
                    val adVariant = data[adVariantManager.variantIndex]

                    imageLoader.load(adVariant.imageUrl, this, R.drawable.empty_image_placeholder)
                    if (adVariant.adUrl.isNullOrBlank()) {
                        isClickable = false
                        isFocusable = false
                    } else {
                        isClickable = true
                        isFocusable = true
                        setOnClickListener {
                            analyticsManager.trackAdClickEvent(adVariant!!.adUrl!!)
                            listener.onAdClicked(adVariant.adUrl!!)
                        }
                    }

                    adVariantManager.next()
                }
    }

    private class AdVariantManager(
            private val count: Int
    ) {
        var variantIndex: Int = -1
            private set

        fun nextRandom() {
            variantIndex = Random.nextInt(0, count)
        }

        fun next() {
            variantIndex++
            if (variantIndex >= count) {
                variantIndex = 0
            }
        }
    }

    interface Listener {
        fun onAdClicked(adUrl: String)
    }

}