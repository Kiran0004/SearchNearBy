package com.smartimpact.base.data.api

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.smartimpact.api.ApiService
import com.smartimpact.auth.AccountManager
import com.smartimpact.auth.LoginIntentProvider
import com.smartimpact.background.BackgroundManager
import com.smartimpact.base.data.api.interceptor.TokenInterceptor
import com.smartimpact.base.data.api.typeadapter.ZonedDateTimeTypeAdapter
import com.smartimpact.calladapter.auth.AuthCallAdapterFactory
import com.smartimpact.calladapter.auth.RefreshTokenProvider
import com.smartimpact.constants.BaseConstants
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet
import io.reactivex.schedulers.Schedulers
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import org.threeten.bp.ZonedDateTime
import retrofit2.CallAdapter
import retrofit2.Converter
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import javax.inject.Singleton

@Module(includes = [ApiBindModule::class])
object ApiModule {

    @JvmStatic
    @Provides @Singleton
    fun provideApiBaseUrl(): HttpUrl {
        return BaseConstants.API_BASE_URL.toHttpUrlOrNull()
                ?: throw IllegalStateException("cannot parse url")
    }

    @JvmStatic
    @Provides @Singleton fun provideGson(): Gson {
        return GsonBuilder()
                .registerTypeAdapter(ZonedDateTime::class.java, ZonedDateTimeTypeAdapter())
                .create()
    }

    @JvmStatic
    @Provides @Singleton fun provideGsonConverterFactory(gson: Gson): Converter.Factory {
        return GsonConverterFactory.create(gson)
    }

    @JvmStatic
    @Provides @Singleton @IntoSet
    fun provideTokenInterceptor(accountManager: AccountManager): Interceptor {
        return TokenInterceptor(accountManager)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideTokenProvider(accountManager: AccountManager, intentProvider: LoginIntentProvider,
            context: Context, backgroundManager: BackgroundManager): RefreshTokenProvider {
        return RefreshTokenProvider(accountManager, intentProvider, context, backgroundManager)
    }

    @JvmStatic
    @Provides @Singleton fun provideCallAdapterFactory(
            refreshTokenProvider: RefreshTokenProvider,
            converterFactory: Converter.Factory): CallAdapter.Factory {
        // TODO make network scheduler
        return AuthCallAdapterFactory.createWithScheduler(refreshTokenProvider, Schedulers.io(), converterFactory)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideAuthHttpClient(interceptors: Set<@JvmSuppressWildcards Interceptor>): OkHttpClient {
        val builder = OkHttpClient.Builder()
        interceptors.forEach { builder.addInterceptor(it) }
        return builder.build()
    }
    @JvmStatic
    @Provides @Singleton
    fun provideRetrofit(baseUrl: HttpUrl, client: OkHttpClient, converterFactory: Converter.Factory,
            callAdapterFactory: CallAdapter.Factory): Retrofit {
        return Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(converterFactory)
                .addCallAdapterFactory(callAdapterFactory)
                .build()
    }

    @JvmStatic
    @Provides @Singleton fun provideApiService(retrofit: Retrofit): ApiService {
        return retrofit.create(ApiService::class.java)
    }

}
