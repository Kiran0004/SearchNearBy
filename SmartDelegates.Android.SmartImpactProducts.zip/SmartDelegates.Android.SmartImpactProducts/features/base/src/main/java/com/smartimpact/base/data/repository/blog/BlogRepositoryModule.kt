package com.smartimpact.base.data.repository.blog

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.blog.BlogLocalSourceImpl
import com.smartimpact.cache.blog.dao.BlogDao
import com.smartimpact.cache.blog.mapper.BlogLocalMapper
import com.smartimpact.cache.contact.mapper.ContactLocalMapper

import com.smartimpact.data.blog.source.local.BlogLocalSource
import com.smartimpact.data.blog.source.remote.BlogRemoteSource
import com.smartimpact.remote.blog.BlogRemoteSourceImpl
import com.smartimpact.remote.blog.mapper.BlogRemoteDataMapper
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton


@Module
object BlogRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideBlogLocalMapper(contactLocalMapper: ContactLocalMapper): BlogLocalMapper {
        return BlogLocalMapper(contactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideBlogDao(cacheDatabase: CacheDatabase): BlogDao {
        return cacheDatabase.blogDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideBlogLocalSource(blogDao: BlogDao, localMapper: BlogLocalMapper): BlogLocalSource {
        return BlogLocalSourceImpl(blogDao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideBlogRemoteDataMapper(contactRemoteMapper: ContactRemoteMapper): BlogRemoteDataMapper {
        return BlogRemoteDataMapper(contactRemoteMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideBlogRemoteSource(apiService: ApiService, remoteMapper: BlogRemoteDataMapper, profileManager: ProfileManager): BlogRemoteSource {
        return BlogRemoteSourceImpl(apiService, remoteMapper, profileManager)
    }

}