package com.smartimpact.base.ui.list.peoplelist.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.ui.list.peoplelist.model.UiPeopleListAd
import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_people_list_ad.view.*

internal class PeopleListAdItemLayout(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var data: UiPeopleListAd

    fun inject(listener: AdView.Listener, imageLoader: ImageLoader, analyticsManager: AnalyticsManager) {
        ivAd.inject(imageLoader, listener, analyticsManager)
    }

    fun bind(peopleListAd: UiPeopleListAd) {
        ivAd.bind(peopleListAd.variants)
    }
}
