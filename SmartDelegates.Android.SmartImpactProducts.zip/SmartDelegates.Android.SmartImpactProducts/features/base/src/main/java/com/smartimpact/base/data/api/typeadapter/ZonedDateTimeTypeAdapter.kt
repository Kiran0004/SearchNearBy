package com.smartimpact.base.data.api.typeadapter

import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter
import com.smartimpact.datetime.api.ApiDateTimeUtil
import org.threeten.bp.ZonedDateTime

class ZonedDateTimeTypeAdapter : TypeAdapter<ZonedDateTime>() {

    override fun write(out: JsonWriter, value: ZonedDateTime?) {
        if (value == null) {
            out.nullValue()
        } else {
            out.value(ApiDateTimeUtil.createZonedDateTimeString(value))
        }
    }

    override fun read(inReader: JsonReader?): ZonedDateTime? {
        return if (inReader?.peek() === JsonToken.NULL) {
            inReader.nextNull()
            null
        } else {
            val date = inReader?.nextString()
            ApiDateTimeUtil.parseZonedDateTimeString(date)
        }
    }
}
