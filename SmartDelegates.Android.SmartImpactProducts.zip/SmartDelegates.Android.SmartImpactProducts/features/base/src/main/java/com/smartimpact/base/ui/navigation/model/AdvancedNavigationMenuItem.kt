package com.smartimpact.base.ui.navigation.model

class AdvancedNavigationMenuItem(
        override val itemId: Int,
        override val iconResId: Int,
        override val titleResId: Int,
        val messageResId: Int,
        val showMessage: Boolean
) : NavigationMenuItem
