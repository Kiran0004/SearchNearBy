package com.smartimpact.base.data.repository.details

import com.smartimpact.api.ApiService
import com.smartimpact.cache.base.CacheDatabase
import com.smartimpact.cache.contact.mapper.ContactLocalMapper
import com.smartimpact.cache.details.NewsDetailsLocalSourceImpl
import com.smartimpact.cache.details.dao.NewsDetailsDao
import com.smartimpact.cache.details.mapper.NewsDetailsLocalMapper

import com.smartimpact.data.details.source.local.NewsDetailsLocalSource
import com.smartimpact.data.details.source.remote.NewsDetailsRemoteSource
import com.smartimpact.remote.contact.mapper.ContactRemoteMapper
import com.smartimpact.remote.details.NewsDetailsRemoteSourceImpl
import com.smartimpact.remote.details.mapper.NewsDetailsRemoteDataMapper
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.Module
import dagger.Provides
import javax.inject.Singleton


@Module
object NewsDetailsRepositoryModule {

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDetailsLocalMapper(contactLocalMapper: ContactLocalMapper): NewsDetailsLocalMapper {
        return NewsDetailsLocalMapper(contactLocalMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDetailsDao(cacheDatabase: CacheDatabase): NewsDetailsDao {
        return cacheDatabase.newsDetailsDao()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDetailsLocalSource(inboxDao: NewsDetailsDao, localMapper: NewsDetailsLocalMapper): NewsDetailsLocalSource {
        return NewsDetailsLocalSourceImpl(inboxDao, localMapper)
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDetailsRemoteDataMapper(contactRemoteMapper: ContactRemoteMapper): NewsDetailsRemoteDataMapper {
        return NewsDetailsRemoteDataMapper()
    }

    @JvmStatic
    @Provides @Singleton
    fun provideNewsDetailsRemoteSource(apiService: ApiService, remoteMapper: NewsDetailsRemoteDataMapper, profileManager: ProfileManager): NewsDetailsRemoteSource {
        return NewsDetailsRemoteSourceImpl(apiService, remoteMapper)
    }

}