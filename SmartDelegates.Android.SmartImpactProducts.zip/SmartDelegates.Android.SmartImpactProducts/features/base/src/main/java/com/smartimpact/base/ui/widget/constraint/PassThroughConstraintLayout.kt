package com.smartimpact.base.ui.widget.constraint

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout

/**
 *  This constraint layout passes motion events to the parent view of any type,
 *  but it is primarily meant to be used as a child of MotionLayout.
 *  Motion event coordinates are properly translated for motion layout to correctly
 *  interpret the motion event.
 */

class PassThroughConstraintLayout(context: Context, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private val transformationMatrix = Matrix()

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        event.transform(transformationMatrix)
        return (parent as View).onTouchEvent(event)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        transformationMatrix.setTranslate(left.toFloat(), top.toFloat())
    }
}
