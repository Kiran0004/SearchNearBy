package com.smartimpact.base.ui.snackbar

import android.content.Context
import android.view.View
import androidx.annotation.StringRes
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import com.smartimpact.base.R
import com.smartimpact.base.ui.theme.getThemeColor

object SnackbarUtils {

    fun createSnackbar(view: View, @StringRes messageRes: Int): Snackbar {
        return Snackbar.make(view, messageRes, Snackbar.LENGTH_SHORT)
    }

    fun createSnackbar(view: View, message: String): Snackbar {
        return Snackbar.make(view, message, Snackbar.LENGTH_SHORT)
    }

    fun createErrorRetrySnackbar(context: Context, view: View, message: String, onRetryClicked: () -> Unit): Snackbar {
        return Snackbar.make(view, message, Snackbar.LENGTH_INDEFINITE)
                .setAction(R.string.snackbar_retry) {
                    onRetryClicked()
                }
                .setBehavior(object : BaseTransientBottomBar.Behavior() {
                    override fun canSwipeDismissView(child: View): Boolean {
                        return false
                    }
                })
                .setActionTextColor(context.getThemeColor(android.R.attr.textColorPrimaryInverse))
    }

}
