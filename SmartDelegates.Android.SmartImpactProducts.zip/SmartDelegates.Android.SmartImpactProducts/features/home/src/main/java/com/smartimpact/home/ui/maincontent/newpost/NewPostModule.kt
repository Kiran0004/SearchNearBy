package com.smartimpact.home.ui.maincontent.newpost

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.base.ui.FragmentScope.Companion.FRAGMENT
import com.smartimpact.photo.PhotoPickerManager
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module(includes = [NewPostBindModule::class])
internal object NewPostModule {

    @JvmStatic
    @Provides
    @FragmentScope(FRAGMENT)
    fun providePhotoPickerManager(fragment: NewPostFragment): PhotoPickerManager {
        return PhotoPickerManager(fragment.requireContext(), "")
    }
}

@Module
internal interface NewPostBindModule {

    @Binds
    fun bindView(fragment: NewPostFragment): NewPostView

    @Binds
    fun bindPresenter(presenterImpl: NewPostPresenterImpl): NewPostPresenter

}
