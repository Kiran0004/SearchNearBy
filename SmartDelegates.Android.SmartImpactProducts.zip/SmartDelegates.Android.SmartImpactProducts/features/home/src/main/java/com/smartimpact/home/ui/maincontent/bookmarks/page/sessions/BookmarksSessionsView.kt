package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.BaseUiBookmarksSessionsModel

internal interface BookmarksSessionsView {

    fun showBookmarkedSessions(bookmarkedSessions: List<BaseUiBookmarksSessionsModel>)
    fun showBookmarkedSessions(bookmarkedSessions: List<BaseUiBookmarksSessionsModel>, diffResult: DiffUtil.DiffResult)
    fun showNoContent(show: Boolean)

}
