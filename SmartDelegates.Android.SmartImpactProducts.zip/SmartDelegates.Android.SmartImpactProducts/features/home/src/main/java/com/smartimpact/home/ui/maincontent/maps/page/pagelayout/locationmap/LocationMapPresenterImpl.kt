package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap

import com.google.android.gms.maps.model.LatLng
import com.smartimpact.api.ApiService
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.mod.ShowWhileResumedMessageManagerMod
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class LocationMapPresenterImpl @Inject constructor(
        private val view: LocationMapView,
        private val apiService: ApiService,
        private val messageManager: MessageManager,
        private val profileManager: ProfileManager
) : LocationMapPresenter {

    private var disposable: Disposable? = null

    private lateinit var messageManagerMod: ShowWhileResumedMessageManagerMod

    override fun onViewCreated() {
        messageManagerMod = ShowWhileResumedMessageManagerMod(
                messageManager = messageManager,
                onAction = {
                    loadData()
                }
        )
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun onResume() {
        messageManagerMod.onResume()
    }

    override fun onPause() {
        messageManagerMod.onPause()
    }

    override fun onMapReady() {
        loadData()
    }

    private fun loadData() {
        disposable?.dispose()
        disposable = apiService.getEvent(profileManager.getEventProfileData().eventId)
                .map { LatLng(it.latitude.toDouble(), it.longitude.toDouble()) }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            view.showMarker(it)
                        },
                        onError = {
                            messageManagerMod.handleActionableMessage(it)
                        }
                )
    }
}
