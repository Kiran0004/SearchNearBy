package com.smartimpact.home.ui.maincontent.inbox.newconversation

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import com.ferfalk.simplesearchview.SimpleSearchView
import com.ferfalk.simplesearchview.SimpleSearchViewListener
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapter
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapterListener
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.R
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_new_conversation.*
import javax.inject.Inject

internal class NewConversationFragment : BaseToolbarFragment(), NewConversationView, PeopleListAdapterListener, Toolbar.OnMenuItemClickListener {

    @Inject
    internal lateinit var presenter: NewConversationPresenter

    @Inject
    internal lateinit var socialIntentManager: SocialIntentManager

    @Inject
    internal lateinit var imageLoader: ImageLoader

    @Inject
    internal lateinit var analyticsManager: AnalyticsManager

    private lateinit var peopleListAdapter: PeopleListAdapter

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        peopleListAdapter = PeopleListAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        newConversationRecycler.adapter = peopleListAdapter

        initialzeMenu()

        searchView.setMenuItem(newConversationToolbar.menu.findItem(R.id.menu_item_contact_search))
        searchView.setOnQueryTextListener(object : SimpleSearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                presenter.onSearchChanged(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                presenter.onSearchChanged(newText)
                return false
            }

            override fun onQueryTextCleared(): Boolean {
                presenter.onSearchChanged(null)
                return false
            }
        })

        searchView.setOnSearchViewListener(object : SimpleSearchViewListener() {
            override fun onSearchViewShown() {
                presenter.onSearchViewShown()
            }

            override fun onSearchViewClosed() {
                presenter.onSearchViewClosed()
            }
        })

        presenter.onViewCreated()
    }

    private fun initialzeMenu() {
        R.menu.menu_new_conversation?.let{
            newConversationToolbar.inflateMenu(it)
            newConversationToolbar.setOnMenuItemClickListener(this)
        }
    }


    override fun onAdClicked(adUrl: String) {
        startActivity(socialIntentManager.getWebsiteIntent(adUrl))
    }

    override fun searchFor(query: String?) {
        presenter.searchFor(query)
    }

    override fun reloadPage() {
        presenter.reloadPage()
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>) {
        peopleListAdapter.setData(list)
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult) {
        peopleListAdapter.setData(list, diffResult)
    }

    override fun showContent(show: Boolean) {
        newConversationRecycler.isVisible = show
        tvNoContent.isVisible = !show
    }

    override fun toolbar(): MaterialToolbar {
        return newConversationToolbar
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return R.string.inbox_new_conversation
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_new_conversation
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        presenter.openChatViewForContact(person.id)
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return false
    }

    companion object {
        fun newInstance(): NewConversationFragment {
            return NewConversationFragment()
        }
    }

}
