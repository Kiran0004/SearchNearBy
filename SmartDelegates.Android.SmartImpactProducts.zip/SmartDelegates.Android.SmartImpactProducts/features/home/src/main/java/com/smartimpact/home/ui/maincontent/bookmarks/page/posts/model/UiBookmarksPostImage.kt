package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model

import com.smartimpact.home.post.model.UiPostImage

internal data class UiBookmarksPostImage(
        val postImage: UiPostImage
) : BaseUiBookmarksPostModel
