package com.smartimpact.home.ui.maincontent.sessiondetails.list.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.sessiondetails.list.SessionDetailsItemListener
import com.smartimpact.home.ui.maincontent.sessiondetails.model.UiSessionDetailsResponse
import kotlinx.android.synthetic.main.item_session_details_response.view.*

internal class SessionDetailsResponseItemLayout(context: Context, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var listener: SessionDetailsItemListener
    private lateinit var data: UiSessionDetailsResponse

    private val responseHandler = SessionResponseHandler()

    override fun onFinishInflate() {
        super.onFinishInflate()
        btnSessionYes.setOnClickListener {
            listener.onSessionResponseClicked(UiSessionDetailsResponse.RESPONSE_GOING)
        }

        btnSessionNo.setOnClickListener {
            listener.onSessionResponseClicked(UiSessionDetailsResponse.RESPONSE_NOT_GOING)
        }
    }

    fun inject(listener: SessionDetailsItemListener) {
        this.listener = listener
    }

    fun bind(data: UiSessionDetailsResponse) {
        responseHandler.setResponse(data.response, data.sessionPassed)
    }

    inner class SessionResponseHandler {

        fun setResponse(status: Int, sessionPassed: Boolean) {
            when (status) {
                UiSessionDetailsResponse.RESPONSE_NONE -> setStatusUnknown()
                UiSessionDetailsResponse.RESPONSE_GOING -> setStatusGoing()
                UiSessionDetailsResponse.RESPONSE_NOT_GOING -> setStatusNotGoing()
            }

            if (sessionPassed) {
                tvSessionResponse.alpha = SESSION_PASSED_ALPHA
                btnSessionYes.alpha = SESSION_PASSED_ALPHA
                btnSessionNo.alpha = SESSION_PASSED_ALPHA

                btnSessionYes.isEnabled = false
                btnSessionNo.isEnabled = false
            }
        }

        private fun setStatusUnknown() {
            tvSessionResponse.text = context.getString(R.string.session_response_none)
            btnSessionYes.setImageResource(R.drawable.ic_session_response_going)
            btnSessionNo.setImageResource(R.drawable.ic_session_response_not_going)
        }

        private fun setStatusGoing() {
            tvSessionResponse.text = context.getString(R.string.session_response_going)
            btnSessionYes.setImageResource(R.drawable.ic_session_response_going_confirmed)
            btnSessionNo.setImageResource(R.drawable.ic_session_response_not_going)
        }

        private fun setStatusNotGoing() {
            tvSessionResponse.text = context.getString(R.string.session_response_not_going)
            btnSessionYes.setImageResource(R.drawable.ic_session_response_going)
            btnSessionNo.setImageResource(R.drawable.ic_session_response_not_going_confirmed)
        }

    }

    companion object {
        private const val SESSION_PASSED_ALPHA = 0.4f
    }

}
