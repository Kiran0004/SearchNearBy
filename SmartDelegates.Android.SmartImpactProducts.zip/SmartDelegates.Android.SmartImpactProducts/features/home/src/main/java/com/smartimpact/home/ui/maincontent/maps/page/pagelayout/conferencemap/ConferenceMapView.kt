package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap

internal interface ConferenceMapView {

    fun showMap(eventMapUrls: ArrayList<String>)

}
