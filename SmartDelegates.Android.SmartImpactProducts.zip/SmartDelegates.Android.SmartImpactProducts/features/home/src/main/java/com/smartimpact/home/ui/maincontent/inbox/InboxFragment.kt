package com.smartimpact.home.ui.maincontent.inbox

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.DividerItemDecoration
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.inbox.list.ConversationsAdapter
import com.smartimpact.home.ui.maincontent.inbox.list.ConversationsAdapterListener
import com.smartimpact.home.ui.maincontent.inbox.model.BaseUiConversationModel
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_inbox.*
import javax.inject.Inject

internal class InboxFragment : BaseDrawerFragment(), InboxView, ConversationsAdapterListener {

    private lateinit var conversationsAdapter: ConversationsAdapter

    @Inject
    internal lateinit var presenter: InboxPresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        conversationsAdapter = ConversationsAdapter(requireContext(), this, imageLoader)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        conversationsRecycler.adapter = conversationsAdapter

        conversationsRecycler.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))

        swipeRefresh.setOnRefreshListener {
            presenter.onRefresh()
        }

        val chatId = arguments?.getString(ARG_CHAT_ID)
        arguments?.clear()

        presenter.onViewCreated(chatId)
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_inbox
    }

    override fun toolbar(): MaterialToolbar {
        return inboxToolbar
    }

    override fun menuRes(): Int? {
        return R.menu.menu_inbox
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_inbox
    }

    override fun showConversations(conversations: List<BaseUiConversationModel>) {
        conversationsAdapter.setData(conversations)
    }

    override fun showConversations(conversations: List<BaseUiConversationModel>, diffResult: DiffUtil.DiffResult) {
        conversationsAdapter.setData(conversations, diffResult)
    }

    override fun onConversationClicked(conversation: UiConversation) {
        presenter.onConversationClicked(conversation)
    }

    override fun showContent(show: Boolean) {
        conversationsRecycler.isVisible = show
        tvNoContent.isVisible = !show
    }

    override fun hideRefresh() {
        swipeRefresh.isRefreshing = false
    }

    override fun enableSwipeRefresh() {
        swipeRefresh.isEnabled = true
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_new_conversation -> {
                presenter.onOpenNewConversation()
                true
            }
            else -> false
        }
    }


    companion object {
        private const val ARG_CHAT_ID = "com.smartimpact.home.ui.maincontent.inbox.InboxFragment.chatId"

        fun newInstance(drawerLayout: DrawerLayout, chatId: String?): InboxFragment {
            return InboxFragment().apply {
                setDrawer(drawerLayout)
                arguments = bundleOf(ARG_CHAT_ID to chatId)
            }
        }
    }

}
