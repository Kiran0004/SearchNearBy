package com.smartimpact.home.ui.maincontent.postdetails.model

import com.smartimpact.home.post.model.UiPostAuthor

internal data class UiPostDetails(
        val postId: String,
        val postBody: String?,
        val postTime: String,
        val author: UiPostAuthor,
        val postImageUrl: String?
)
