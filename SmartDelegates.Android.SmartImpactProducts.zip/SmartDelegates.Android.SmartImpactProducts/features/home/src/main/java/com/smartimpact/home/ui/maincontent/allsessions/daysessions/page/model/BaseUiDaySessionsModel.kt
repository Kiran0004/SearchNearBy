package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model

internal interface BaseUiDaySessionsModel
