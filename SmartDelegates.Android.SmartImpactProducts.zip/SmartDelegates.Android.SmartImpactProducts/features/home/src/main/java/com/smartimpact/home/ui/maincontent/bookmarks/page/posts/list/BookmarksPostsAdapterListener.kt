package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list

import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout

internal interface BookmarksPostsAdapterListener :
        PostImageItemLayout.Listener,
        PostTextItemLayout.Listener
