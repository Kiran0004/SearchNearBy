package com.smartimpact.home.ui.maincontent.inbox.list.listitem

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import com.smartimpact.base.ui.theme.getThemeColor
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_inbox_conversation.view.*

internal class ConversationItemLayout(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiConversation

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onConversationClicked(data)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener

        viAvatar.inject(imageLoader)
    }

    fun bind(data: UiConversation) {
        this.data = data

        val nameTextColorAttribute = if (data.areAllMessagesRead) {
            android.R.attr.textColorPrimary
        } else {
            android.R.attr.textColorSecondary
        }
        tvName.setTextColor(context.getThemeColor(nameTextColorAttribute))

        viAvatar.setData(data.conversationPartnerNameText, data.conversationPartnerImageUrl)
        tvName.text = data.conversationPartnerNameText
        ivReadStatus.isVisible = !data.areAllMessagesRead
        tvTime.text = data.lastMessageTimeText
        tvPreview.text = data.lastMessagePreviewText
    }

    interface Listener {
        fun onConversationClicked(conversation: UiConversation)
    }

}
