package com.smartimpact.home.ui.maincontent.inbox.model

internal data class UiConversationShimmer(
        val shimmerVariance: Int
) : BaseUiConversationModel
