package com.smartimpact.home.ui.maincontent.bookmarks.page.people

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapter
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapterListener
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.R
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_bookmarks_people.*
import javax.inject.Inject

internal class BookmarksPeopleFragment : DaggerFragment(), BookmarksPeopleView, PeopleListAdapterListener {

    private lateinit var adapter: PeopleListAdapter

    @Inject
    internal lateinit var presenter: BookmarksPeoplePresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    @Inject
    internal lateinit var analyticsManager: AnalyticsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_bookmarks_people, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapter = PeopleListAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.adapter = adapter

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onResume() {
        presenter.onResume()
        super.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>) {
        adapter.setData(list)
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult) {
        adapter.setData(list, diffResult)
    }

    override fun showNoContent(show: Boolean) {
        tvNoContent.isVisible = show
    }

    override fun onAdClicked(adUrl: String) {
        // not showing ads in BookmarksPeople
    }

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        presenter.onPersonClicked(person)
    }

    companion object {
        fun newInstance(): BookmarksPeopleFragment {
            return BookmarksPeopleFragment()
        }
    }

}
