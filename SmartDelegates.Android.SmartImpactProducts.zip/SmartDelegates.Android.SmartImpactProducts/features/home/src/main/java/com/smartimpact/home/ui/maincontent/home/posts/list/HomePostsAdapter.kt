package com.smartimpact.home.ui.maincontent.home.posts.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.post.itemlayout.PostAdItemLayout
import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout
import com.smartimpact.home.ui.maincontent.home.posts.model.*
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class HomePostsAdapter(
        context: Context,
        private val listener: HomePostsAdapterListener,
        private val imageLoader: ImageLoader,
        private val analyticsManager: AnalyticsManager
) : BaseItemsAdapter<BaseUiHomePostModel, HomePostsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiHomePostAd -> TYPE_POST_AD
            is UiHomePostImage -> TYPE_POST_IMAGE
            is UiHomePostShimmer -> TYPE_POST_SHIMMER
            is UiHomePostText -> TYPE_POST_TEXT
            is UiHomePostEmpty -> TYPE_POST_EMPTY
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_POST_AD -> R.layout.item_post_ad
            TYPE_POST_IMAGE -> R.layout.item_post_image
            TYPE_POST_SHIMMER -> R.layout.item_post_shimmer
            TYPE_POST_TEXT -> R.layout.item_post_text
            TYPE_POST_EMPTY -> R.layout.item_post_empty
            else -> throw IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_POST_AD -> {
                val layout = view as PostAdItemLayout
                layout.inject(listener, imageLoader, analyticsManager)
                PostAdVH(layout)
            }
            TYPE_POST_IMAGE -> {
                val layout = view as PostImageItemLayout
                layout.inject(listener, imageLoader)
                PostImageVH(layout)
            }
            TYPE_POST_SHIMMER -> {
                PostShimmerVH(view)
            }
            TYPE_POST_TEXT -> {
                val layout = view as PostTextItemLayout
                layout.inject(listener, imageLoader)
                PostTextVH(layout)
            }
            TYPE_POST_EMPTY -> {
                PostEmptyVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiHomePostModel, position: Int) {
        holder.bind(item)
    }

    fun setData(data: List<BaseUiHomePostModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(data)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiHomePostModel)
    }

    private class PostAdVH(
            override val containerView: PostAdItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomePostModel) {
            containerView.setData(
                    (item as UiHomePostAd).postAd
            )
        }
    }

    private class PostImageVH(
            override val containerView: PostImageItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomePostModel) {
            containerView.setData(
                    (item as UiHomePostImage).postImage
            )
        }
    }

    private class PostShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomePostModel) {}
    }

    private class PostEmptyVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomePostModel) {}
    }

    private class PostTextVH(
            override val containerView: PostTextItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomePostModel) {
            containerView.setData(
                    (item as UiHomePostText).postText
            )
        }
    }

    companion object {
        private const val TYPE_POST_AD = 0
        private const val TYPE_POST_IMAGE = 1
        private const val TYPE_POST_SHIMMER = 2
        private const val TYPE_POST_TEXT = 3
        private const val TYPE_POST_EMPTY = 4
    }
}
