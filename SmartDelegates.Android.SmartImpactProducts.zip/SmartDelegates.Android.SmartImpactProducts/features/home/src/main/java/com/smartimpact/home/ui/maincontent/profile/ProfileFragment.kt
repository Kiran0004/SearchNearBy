package com.smartimpact.home.ui.maincontent.profile

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DividerItemDecoration
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.base.ui.widget.chip.CompactChip
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.profile.list.ProfileAdapter
import com.smartimpact.home.ui.maincontent.profile.list.ProfileAdapterListener
import com.smartimpact.home.ui.maincontent.profile.model.BaseUiProfileTile
import com.smartimpact.home.ui.maincontent.profile.model.UiProfileHeader
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_profile.*
import javax.inject.Inject

internal class ProfileFragment : BaseToolbarFragment(), ProfileView, ProfileAdapterListener {

    @Inject
    internal lateinit var presenter: ProfilePresenter
    @Inject
    internal lateinit var imageLoader: ImageLoader

    private lateinit var adapter: ProfileAdapter

    private var bookmarkMenuItem: MenuItem? = null

    override fun layoutRes(): Int {
        return R.layout.fragment_profile
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun menuRes(): Int? {
        // The presenter takes care of requesting the correct menu to be shown!
        // (based on contact type: person, sponsor, personal account)
        return null
    }

    override fun toolbar(): MaterialToolbar {
        return profileToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = ProfileAdapter(requireContext(), this)

        val profileId = requireArguments().getString(ARG_PROFILE_ID)
                ?: throw IllegalStateException("Profile ID cannot be null!")
        val isSponsor = requireArguments().getBoolean(ARG_IS_SPONSOR)
                ?: throw IllegalStateException("isSponsor flag should always have value!")
        presenter.onCreate(profileId, isSponsor)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viAvatar.inject(imageLoader)

        profileRecycler.adapter = adapter
        profileRecycler.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun showBookmarkStatus(isBookmarked: Boolean) {
        bookmarkMenuItem?.isChecked = isBookmarked
        bookmarkMenuItem?.setIcon(
                when (isBookmarked) {
                    true -> R.drawable.ic_bookmark_filled
                    false -> R.drawable.ic_bookmark
                }
        )
    }

    override fun showProfileHeader(header: UiProfileHeader) {
        viAvatar.setData(header.name, header.photoUrl)
        tvProfileName.text = header.name
        tvProfileOccupation.text = header.occupation
    }

    override fun updateLabels(isSponsor: Boolean) {
        viChips.apply {
            if (isSponsor) {
                removeAllViews()
                val chip = CompactChip(requireContext()).apply {
                    setMaxChipHeight(R.dimen.profile_label_max_chip_height)
                    text = context.getText(R.string.is_sponsor_label_text)
                }
                addView(chip)
                visibility = View.VISIBLE
            } else {
                visibility = View.GONE
            }
        }
    }

    override fun showProfileDetails(details: List<BaseUiProfileTile>) {
        adapter.setData(details)
    }

    override fun showLoading(show: Boolean) {
        profileShimmer.isVisible = show
    }

    override fun showDivider(show: Boolean) {
        val visibility = if (show) View.VISIBLE else View.INVISIBLE
        motionLayout.getConstraintSet(R.id.scene_profile_expanded).setVisibility(R.id.recyclerDivider, visibility)
    }

    override fun showPersonMenu() {
        setToolbarMenuRes(R.menu.menu_profile_person)
        bookmarkMenuItem = toolbar().menu.findItem(R.id.menu_item_profile_bookmark)
    }

    override fun showSponsorMenu() {
        setToolbarMenuRes(R.menu.menu_profile_sponsor)
        bookmarkMenuItem = toolbar().menu.findItem(R.id.menu_item_profile_bookmark)
    }

    override fun showSelfMenu() {
        setToolbarMenuRes(R.menu.menu_profile_self)
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_profile_bookmark -> {
                presenter.onToggleBookmarkClicked()
                true
            }
            R.id.menu_item_profile_chat -> {
                presenter.onChatProfileClicked()
                true
            }
            R.id.menu_item_profile_edit -> {
                presenter.onEditProfileClicked()
                true
            }
            else -> return super.onMenuItemClick(item)
        }
    }

    override fun onEmailClicked(email: String) {
       // presenter.onEmailClicked(email)
    }

    override fun onWebsiteClicked(website: String) {
        presenter.onWebsiteClicked(website)
    }

    override fun onTwitterClicked(twitter: String) {
        presenter.onTwitterClicked(twitter)
    }

    override fun onLinkedInClicked(linkedIn: String) {
        presenter.onLinkedInClicked(linkedIn)
    }

    override fun onFacebookClicked(facebook: String) {
        presenter.onFacebookClicked(facebook)
    }

    override fun handleIntent(intent: Intent) {
        startActivity(intent)
    }

    companion object {
        fun newInstance(profileId: String, isSponsor: Boolean = false): ProfileFragment {
            return ProfileFragment().apply {
                arguments = bundleOf(ARG_PROFILE_ID to profileId, ARG_IS_SPONSOR to isSponsor)
            }
        }

        private const val ARG_PROFILE_ID = "com.smartimpact.home.ui.maincontent.profile.ProfileFragment.argProfileId"
        private const val ARG_IS_SPONSOR = "com.smartimpact.home.ui.maincontent.profile.ProfileFragment.argIsSponsor"
    }

}
