package com.smartimpact.home.post.itemlayout

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.core.view.isEmpty
import com.google.android.material.card.MaterialCardView
import com.smartimpact.base.ui.widget.chip.CompactChip
import com.smartimpact.home.R
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_post_text.view.*

internal class PostTextItemLayout(context: Context, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiPostText

    override fun onFinishInflate() {
        super.onFinishInflate()

        btnAuthor.setOnClickListener {
            if(data.tweetUrl.isNullOrBlank()) listener.onPostAuthorClicked(data.author)
        }
        setOnClickListener {
            listener.onPostClicked(data)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener

        viAvatar.inject(imageLoader)
    }

    fun setData(data: UiPostText) {
        this.data = data

        viAvatar.setData(data.author.authorName, data.author.authorImageUrl)
        postAuthorName.text = data.author.authorName
        postTime.text = data.postTime
        postText.text = data.postText

        updateTweetTags()
        updatePostTextLines()
    }

    private fun updateTweetTags() {
        hashtags.removeAllViews()
        data.tweetTags?.forEach { tag ->
            val chip = CompactChip(context).apply {
                setMaxChipHeight(R.dimen.tweet_tag_max_chip_height)
                text = tag
            }
            hashtags.addView(chip)
        }

        hashtags.visibility = if(hashtags.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updatePostTextLines() {
        postText.setLines(if(hashtags.isEmpty()) 3 else 2)
    }

    interface Listener {
        fun onPostClicked(post: UiPostText)
        fun onPostAuthorClicked(postAuthor: UiPostAuthor)
    }

}
