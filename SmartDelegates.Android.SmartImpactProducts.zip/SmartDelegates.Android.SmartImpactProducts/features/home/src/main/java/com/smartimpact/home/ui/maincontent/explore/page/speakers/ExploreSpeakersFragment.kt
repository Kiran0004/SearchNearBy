package com.smartimpact.home.ui.maincontent.explore.page.speakers

import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapterListener
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageFragment
import javax.inject.Inject

internal class ExploreSpeakersFragment : BaseExplorePageFragment(), ExploreSpeakersView, PeopleListAdapterListener {

    @Inject
    internal lateinit var presenter: ExploreSpeakersPresenter

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        presenter.onPersonClicked(person)
    }

    companion object {
        fun newInstance(): ExploreSpeakersFragment {
            return ExploreSpeakersFragment()
        }
    }

}
