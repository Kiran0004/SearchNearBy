package com.smartimpact.home.ui.maincontent.bookmarks.page.posts

import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText

internal interface BookmarksPostsPresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onDestroy()
    fun onResume()
    fun onPause()
    fun onPostClicked(post: UiPostImage)
    fun onPostClicked(post: UiPostText)
    fun onPostAuthorClicked(author: UiPostAuthor)

}
