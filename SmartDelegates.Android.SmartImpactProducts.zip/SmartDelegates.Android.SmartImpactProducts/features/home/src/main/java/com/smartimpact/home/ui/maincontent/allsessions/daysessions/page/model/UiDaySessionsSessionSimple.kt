package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model

import com.smartimpact.home.session.model.UiSessionSimple

internal data class UiDaySessionsSessionSimple(
        val sessionSimple: UiSessionSimple
) : BaseUiDaySessionsModel
