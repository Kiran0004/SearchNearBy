package com.smartimpact.home.ui.maincontent.home.posts.model

import com.smartimpact.home.post.model.UiPostText

internal data class UiHomePostText(
        val postText: UiPostText
) : BaseUiHomePostModel
