package com.smartimpact.home.ui.maincontent.sessiondetails.model

internal interface BaseUiSessionDetails
