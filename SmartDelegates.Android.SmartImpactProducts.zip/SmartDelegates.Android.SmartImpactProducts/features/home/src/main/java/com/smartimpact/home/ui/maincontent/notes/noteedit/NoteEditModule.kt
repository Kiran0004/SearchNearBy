package com.smartimpact.home.ui.maincontent.notes.noteedit

import dagger.Binds
import dagger.Module

@Module
internal interface NoteEditModule {

    @Binds fun bindView(fragment: NoteEditFragment): NoteEditView

    @Binds fun bindPreseenter(presenterImpl: NoteEditPresenterImpl): NoteEditPresenter

}