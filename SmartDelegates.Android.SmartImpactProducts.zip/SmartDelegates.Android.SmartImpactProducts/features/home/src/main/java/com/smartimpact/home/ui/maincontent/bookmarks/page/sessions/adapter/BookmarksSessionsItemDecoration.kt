package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter

import android.graphics.Rect
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class BookmarksSessionsItemDecoration : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        val resources = parent.context.resources

        outRect.top = resources.getDimensionPixelSize(
                when (itemPosition) {
                    0 -> R.dimen.bookmarks_sessions_session_first_margin_top
                    else -> R.dimen.bookmarks_sessions_session_margin_top
                }
        )
        outRect.bottom = resources.getDimensionPixelSize(
                when (itemPosition) {
                    parent.adapter!!.itemCount - 1 -> R.dimen.bookmarks_sessions_session_last_margin_bottom
                    else -> R.dimen.bookmarks_sessions_session_margin_bottom
                }
        )
        outRect.left = resources.getDimensionPixelSize(R.dimen.bookmarks_sessions_session_margin_start)
        outRect.right = resources.getDimensionPixelSize(R.dimen.bookmarks_sessions_session_margin_end)
    }

}
