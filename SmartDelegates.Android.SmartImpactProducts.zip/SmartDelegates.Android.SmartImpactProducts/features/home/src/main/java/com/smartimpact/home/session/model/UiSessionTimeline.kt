package com.smartimpact.home.session.model

class UiSessionTimeline : BaseUiSessionModel