package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model

internal class UiBookmarksSessionShimmer : BaseUiBookmarksSessionsModel
