package com.smartimpact.home.ui.maincontent.profile

import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.contacts.entity.ContactDetailsEntity
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.home.ui.maincontent.profile.model.*
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.flatMapIterable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class ProfilePresenterImpl @Inject constructor(
        private val view: ProfileView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val contactDetailsRepository: ContactDetailsRepository,
        private val bookmarksRepository: BookmarksRepository,
        private val profileManager: ProfileManager,
        private val intentManager: SocialIntentManager
) : ProfilePresenter {

    private lateinit var profileId: String
    private var isSponsor: Boolean = false

    private val compositeDisposable = CompositeDisposable()

    override fun onCreate(profileId: String, isSponsor: Boolean) {
        this.profileId = profileId
        this.isSponsor = isSponsor
    }

    override fun onViewCreated() {
        view.showLoading(true)
        view.showDivider(false)


        val isMyProfile = profileManager.getEventProfileData().eventProfileId == profileId

        // TODO somehow figure out if showing sponsor profile -> view.showSponsorMenu()
        if (isMyProfile) {
            view.showSelfMenu()
        } else {
            view.showPersonMenu()
            connectToBookmarksRepository()
        }

        contactDetailsRepository
                .outObtainOfContactError
                .filter {
                    val contactId = it.first
                    contactId == profileId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val error = it.second

                    messageManager.handlePlainMessage(error)
                    view.close()
                }
                .addTo(compositeDisposable)

        contactDetailsRepository
                .outRefreshOfContactError
                .filter {
                    val contactId = it.first
                    contactId == profileId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val error = it.second
                    messageManager.handlePlainMessage(error)
                }
                .addTo(compositeDisposable)

        contactDetailsRepository
                .outContactDetails
                .flatMapIterable()
                .filter { contactDetails ->
                    contactDetails.id == profileId
                }
                .map { mapToUiModel(it) }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    view.showLoading(false)
                    view.showProfileHeader(it.first)
                    view.updateLabels(isSponsor)
                    view.showDivider(true)
                    view.showProfileDetails(it.second)
                }
                .addTo(compositeDisposable)

        contactDetailsRepository.obtainOfContact(profileId)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onToggleBookmarkClicked() {
        bookmarksRepository.toggleContactBookmark(profileId)
    }

    override fun onChatProfileClicked() {
        parentPresenter.openChatViewForContact(profileId)
    }

    override fun onEditProfileClicked() {
        parentPresenter.openProfileEditView()
    }

    override fun onEmailClicked(email: String) {
        val intent = intentManager.getEmailIntent(email)
        if (intent == null) {
            // TODO
        } else {
            view.handleIntent(intent)
        }
    }

    override fun onWebsiteClicked(website: String) {
        val intent = intentManager.getWebsiteIntent(website)
        if (intent == null) {
            // TODO
        } else {
            view.handleIntent(intent)
        }
    }

    override fun onTwitterClicked(twitter: String) {
        val intent = intentManager.getTwitterIntent(twitter)
        if (intent == null) {
            // TODO
        } else {
            view.handleIntent(intent)
        }
    }

    override fun onLinkedInClicked(linkedIn: String) {
        // TODO
    }

    override fun onFacebookClicked(facebook: String) {
        // TODO
    }

    private fun connectToBookmarksRepository() {
        bookmarksRepository
                .outInitializationError
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                    view.close()
                }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outBookmarkedContactIds
                .map { bookmarkedContactIds ->
                    bookmarkedContactIds.contains(profileId)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { isBookmarked ->
                    view.showBookmarkStatus(isBookmarked)
                }
                .addTo(compositeDisposable)
    }

    private fun mapToUiModel(contactDetails: ContactDetailsEntity): Pair<UiProfileHeader, List<BaseUiProfileTile>> {
        val header = UiProfileHeader(contactDetails.name, contactDetails.jobTitle, contactDetails.imageUrl)
        val details = mutableListOf<BaseUiProfileTile>()
        contactDetails.biography?.let {
            details.add(UiProfileBiography(it))
        }
        contactDetails.email?.let {
            details.add(UiProfileSocialEmail(it))
        }
        contactDetails.website?.let {
            details.add(UiProfileSocialWebsite(it))
        }
        contactDetails.twitter?.let {
            details.add(UiProfileSocialTwitter(it))
        }
        contactDetails.linkedIn?.let {
            details.add(UiProfileSocialLinkedIn(it))
        }
        contactDetails.facebook?.let {
            details.add(UiProfileSocialFacebook(it))
        }

        return Pair(header, details)
    }
}
