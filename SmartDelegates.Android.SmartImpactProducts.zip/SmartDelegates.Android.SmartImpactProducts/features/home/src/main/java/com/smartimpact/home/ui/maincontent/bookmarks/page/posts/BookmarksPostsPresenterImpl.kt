package com.smartimpact.home.ui.maincontent.bookmarks.page.posts

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.post.entity.PostEntity
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.mod.ShowWhileResumedMessageManagerMod
import com.smartimpact.home.post.mapper.PostUiMapper
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.ui.maincontent.bookmarks.BookmarksPresenter
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list.BookmarksPostsDiffUtilCallback
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.BaseUiBookmarksPostModel
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostImage
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostShimmer
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostText
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class BookmarksPostsPresenterImpl @Inject constructor(
        private val view: BookmarksPostsView,
        private val parentPresenter: BookmarksPresenter,
        private val messageManager: MessageManager,
        private val bookmarksRepository: BookmarksRepository,
        private val postRepository: PostRepository,
        private val postUiMapper: PostUiMapper
) : BookmarksPostsPresenter {

    private var hasData: Boolean = false
    private var data: List<BaseUiBookmarksPostModel> = emptyList()

    private lateinit var messageManagerMod: ShowWhileResumedMessageManagerMod

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManagerMod = ShowWhileResumedMessageManagerMod(
                messageManager = messageManager,
                onAction = {
                    bookmarksRepository.initialize()
                    postRepository.initialize()
                }
        )

        if (!hasData) {
            data = createShimmerItems()
            view.showBookmarkedPosts(data)
        }

        bookmarksRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        Observable
                .combineLatest(
                        bookmarksRepository.outBookmarkedPostIds,
                        postRepository.outTopAndAllPosts,
                        BiFunction { bookmarkedPostIds: Set<String>, posts: List<PostEntity> ->
                            Pair(bookmarkedPostIds, posts)
                        }
                )
                .map {
                    val bookmarkedPostIds = it.first
                    val posts = it.second

                    posts.filter { post ->
                        bookmarkedPostIds.contains(post.id)
                    }
                }
                .map { mapToUi(it) }
                .map { newData ->
                    val diffResult = DiffUtil.calculateDiff(BookmarksPostsDiffUtilCallback(data, newData))
                    Pair(newData, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val newData = it.first
                    val diffResult = it.second

                    hasData = true
                    data = newData
                    view.showNoContent(data.isEmpty())
                    view.showBookmarkedPosts(data, diffResult)
                }
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onResume() {
        messageManagerMod.onResume()
    }

    override fun onPause() {
        messageManagerMod.onPause()
    }

    override fun onPostClicked(post: UiPostImage) {
        parentPresenter.openPostDetailsView(post.postId)
    }

    override fun onPostClicked(post: UiPostText) {
        parentPresenter.openPostDetailsView(post.postId)
    }

    override fun onPostAuthorClicked(author: UiPostAuthor) {
        parentPresenter.openProfileDialog(author.authorId)
    }

    private fun createShimmerItems(): List<UiBookmarksPostShimmer> {
        return (0 until 10).map {
            UiBookmarksPostShimmer()
        }
    }

    private fun mapToUi(entities: List<PostEntity>): List<BaseUiBookmarksPostModel> {
        return entities.map { entity ->
            when (val uiPostModel = postUiMapper.mapToUi(entity)) {
                is UiPostImage -> UiBookmarksPostImage(uiPostModel)
                is UiPostText -> UiBookmarksPostText(uiPostModel)
                else -> throw IllegalStateException()
            }
        }
    }

}
