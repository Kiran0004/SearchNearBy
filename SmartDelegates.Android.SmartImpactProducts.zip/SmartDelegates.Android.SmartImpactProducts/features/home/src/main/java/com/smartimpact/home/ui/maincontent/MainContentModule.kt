package com.smartimpact.home.ui.maincontent

import com.smartimpact.home.eventmanager.EventManagerModule
import com.smartimpact.base.messagemanager.MessageManagerModule
import com.smartimpact.home.post.PostModule
import com.smartimpact.home.session.SessionModule
import com.smartimpact.base.ui.MainContentRepositoryModule
import com.smartimpact.home.ui.maincontent.root.MainContentBindModule
import dagger.Module

@Module(includes = [
    MainContentBindModule::class,
    EventManagerModule::class,
    MessageManagerModule::class,
    PostModule::class,
    SessionModule::class,
    MainContentRepositoryModule::class
])
object MainContentModule
