package com.smartimpact.home.post.model

internal data class UiPostText(
        val postId: String,
        val author: UiPostAuthor,
        val postTime: String,
        val postText: String?,
        val tweetUrl: String?,
        val tweetTags: List<String>?
) : BaseUiPostModel
