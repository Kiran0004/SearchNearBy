package com.smartimpact.home.ui.maincontent.bookmarks.page.posts

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.R
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list.BookmarksPostsAdapter
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list.BookmarksPostsAdapterListener
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list.BookmarksPostsItemDecoration
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.BaseUiBookmarksPostModel
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_bookmarks_people.*
import javax.inject.Inject

internal class BookmarksPostsFragment : DaggerFragment(), BookmarksPostsView, BookmarksPostsAdapterListener {

    private lateinit var adapter: BookmarksPostsAdapter

    @Inject
    internal lateinit var presenter: BookmarksPostsPresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_bookmarks_posts, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapter = BookmarksPostsAdapter(requireContext(), this, imageLoader)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.adapter = adapter
        recycler.addItemDecoration(BookmarksPostsItemDecoration())

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun showBookmarkedPosts(bookmarkedPosts: List<BaseUiBookmarksPostModel>) {
        adapter.setData(bookmarkedPosts)
    }

    override fun showBookmarkedPosts(bookmarkedPosts: List<BaseUiBookmarksPostModel>, diffResult: DiffUtil.DiffResult) {
        adapter.setData(bookmarkedPosts, diffResult)
    }

    override fun showNoContent(show: Boolean) {
        tvNoContent.isVisible = show
    }

    override fun onPostClicked(post: UiPostImage) {
        presenter.onPostClicked(post)
    }

    override fun onPostClicked(post: UiPostText) {
        presenter.onPostClicked(post)
    }

    override fun onPostAuthorClicked(postAuthor: UiPostAuthor) {
        presenter.onPostAuthorClicked(postAuthor)
    }

    companion object {
        fun newInstance(): BookmarksPostsFragment {
            return BookmarksPostsFragment()
        }
    }

}
