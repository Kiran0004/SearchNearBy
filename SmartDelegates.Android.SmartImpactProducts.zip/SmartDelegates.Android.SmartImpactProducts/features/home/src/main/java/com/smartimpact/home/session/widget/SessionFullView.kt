package com.smartimpact.home.session.widget

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.os.LocaleListCompat
import androidx.core.view.isVisible
import com.smartimpact.base.ui.widget.OverlapAvatarView
import com.smartimpact.base.ui.widget.chip.CompactChip
import com.smartimpact.home.R
import com.smartimpact.home.session.itemlayout.SessionBase
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.widget_session_full_view.view.*

internal class SessionFullView(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiSessionFull


    init {
        inflate(context, R.layout.widget_session_full_view, this)
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        btnAuthor.setOnClickListener {
            listener.onSessionSpeakersClicked(data.sessionId, data.sessionSpeakers!!)
        }
    }

    fun inject(imageLoader: ImageLoader) {
        viSpeakersAvatars.inject(imageLoader)
    }

    fun setListener(listener: Listener) {
        this.listener = listener
    }

    fun setData(session: UiSessionFull) {
        this.data = session

        updateChips()
        updateSpeakers()

        tvTitle.text = data.sessionTitle
        tvDescription.text = if (data.sessionLocation.isNullOrBlank()) {
            data.sessionTime
        } else {
            context.getString(R.string.session_time_and_location,
                    data.sessionTime,
                    data.sessionLocation
            )
        }

        if (session.sessionPassed) {
            alpha = SessionBase.PASSED_SESSION_ALPHA
        }
    }

    private fun updateChips() {
        viChips.removeAllViews()
        data.sessionTags.forEach { tag ->
            val chip = CompactChip(context).apply {
                setMaxChipHeight(R.dimen.session_max_chip_height)
                text = tag.toUpperCase(LocaleListCompat.getDefault().get(0))
            }
            viChips.addView(chip)
        }
    }

    private fun updateSpeakers() {
        val speakers = data.sessionSpeakers
        if (speakers.isNullOrEmpty()) {
            groupSpeakers.isVisible = false
            return
        }
        groupSpeakers.isVisible = true

        val avatars = speakers.map { speaker ->
            OverlapAvatarView.Avatar(speaker.speakerName, speaker.speakerPhotoUrl)
        }
        viSpeakersAvatars.setAvatars(avatars)


        tvSpeakersTitle.text = speakers.first().speakerName

        tvSpeakersDescription.text = if (speakers.size == 1) {
            speakers.first().speakerDescription
        } else {
            context.getString(R.string.session_plus_other, speakers.size - 1)
        }
    }

    interface Listener {
        fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>)
    }

}
