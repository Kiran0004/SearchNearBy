package com.smartimpact.home.ui.maincontent.notes.model

internal class UiNoteShimmer : BaseUiNote