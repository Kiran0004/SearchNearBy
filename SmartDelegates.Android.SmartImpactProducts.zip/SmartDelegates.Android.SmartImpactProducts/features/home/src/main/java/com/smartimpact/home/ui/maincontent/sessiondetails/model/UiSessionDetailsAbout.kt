package com.smartimpact.home.ui.maincontent.sessiondetails.model

import com.smartimpact.home.R

internal data class UiSessionDetailsAbout(
        override val text: String
) : BaseUiSessionDetailsTile() {

    override fun getLeadingImageResource(): Int {
        return R.drawable.ic_info
    }

}
