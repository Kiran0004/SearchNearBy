package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.BaseUiBookmarksPostModel
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostImage
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostShimmer
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostText

internal class BookmarksPostsDiffUtilCallback(
        private val oldList: List<BaseUiBookmarksPostModel>,
        private val newList: List<BaseUiBookmarksPostModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiBookmarksPostImage && newItem is UiBookmarksPostImage ->
                oldItem.postImage.postId == newItem.postImage.postId
            oldItem is UiBookmarksPostShimmer && newItem is UiBookmarksPostShimmer ->
                true
            oldItem is UiBookmarksPostText && newItem is UiBookmarksPostText ->
                oldItem.postText.postId == newItem.postText.postId
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiBookmarksPostImage && newItem is UiBookmarksPostImage ->
                oldItem == newItem
            oldItem is UiBookmarksPostShimmer && newItem is UiBookmarksPostShimmer ->
                true
            oldItem is UiBookmarksPostText && newItem is UiBookmarksPostText ->
                oldItem == newItem
            else -> false
        }
    }

}

