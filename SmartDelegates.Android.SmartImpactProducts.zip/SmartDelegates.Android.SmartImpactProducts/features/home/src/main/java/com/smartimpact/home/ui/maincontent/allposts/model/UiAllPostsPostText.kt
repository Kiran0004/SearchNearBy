package com.smartimpact.home.ui.maincontent.allposts.model

import com.smartimpact.home.post.model.UiPostText

internal data class UiAllPostsPostText(
        val postText: UiPostText
) : BaseUiAllPostsModel
