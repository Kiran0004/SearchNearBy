package com.smartimpact.home.ui.maincontent.home.sessions.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.home.sessions.model.*

internal class HomeSessionsDiffUtilCallback(
        private val oldList: List<BaseUiHomeSessionModel>,
        private val newList: List<BaseUiHomeSessionModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiHomeSessionAd && newItem is UiHomeSessionAd ->
                oldItem == newItem
            oldItem is UiHomeSessionSimple && newItem is UiHomeSessionSimple ->
                oldItem.sessionSimple.sessionId == newItem.sessionSimple.sessionId
            oldItem is UiHomeSessionFull && newItem is UiHomeSessionFull ->
                oldItem.sessionFull.sessionId == newItem.sessionFull.sessionId
            oldItem is UiHomeSessionDay && newItem is UiHomeSessionDay -> oldItem.id == newItem.id
            oldItem is UiHomeSessionTimeline && newItem is UiHomeSessionTimeline -> oldItem == newItem
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiHomeSessionAd && newItem is UiHomeSessionAd ->
                oldItem == newItem
            oldItem is UiHomeSessionSimple && newItem is UiHomeSessionSimple ->
                oldItem == newItem
            oldItem is UiHomeSessionFull && newItem is UiHomeSessionFull ->
                oldItem == newItem
            oldItem is UiHomeSessionDay && newItem is UiHomeSessionDay ->
                oldItem == newItem
            oldItem is UiHomeSessionTimeline && newItem is UiHomeSessionTimeline -> oldItem == newItem
            else -> false
        }
    }

}
