package com.smartimpact.home.ui.maincontent.bookmarks

internal interface BookmarksView {

}
