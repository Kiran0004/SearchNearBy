package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list

import android.graphics.Rect
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class BookmarksPostsItemDecoration : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        val resources = parent.context.resources

        outRect.top = resources.getDimensionPixelSize(
                when (itemPosition) {
                    0 -> R.dimen.bookmarks_posts_first_item_margin_top
                    else -> R.dimen.bookmarks_posts_item_margin_bottom
                }
        )
        outRect.bottom = resources.getDimensionPixelSize(
                when (itemPosition) {
                    parent.adapter!!.itemCount - 1 -> R.dimen.bookmarks_posts_last_item_margin_bottom
                    else -> R.dimen.bookmarks_posts_item_margin_bottom
                }
        )
        outRect.left = resources.getDimensionPixelSize(R.dimen.bookmarks_posts_item_margin_start)
        outRect.right = resources.getDimensionPixelSize(R.dimen.bookmarks_posts_item_margin_end)
    }

}
