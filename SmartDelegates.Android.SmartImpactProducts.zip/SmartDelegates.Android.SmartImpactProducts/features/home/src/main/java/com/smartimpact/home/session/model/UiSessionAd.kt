package com.smartimpact.home.session.model

import com.smartimpact.data.ads.entity.AdEntity

internal data class UiSessionAd(
        val variants: List<AdEntity>
) : BaseUiSessionModel 
