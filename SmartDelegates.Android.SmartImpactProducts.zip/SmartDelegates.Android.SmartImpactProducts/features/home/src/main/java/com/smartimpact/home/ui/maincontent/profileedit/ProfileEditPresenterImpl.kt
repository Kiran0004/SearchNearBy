package com.smartimpact.home.ui.maincontent.profileedit

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.contacts.entity.ContactDetailsEntity
import com.smartimpact.home.R
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.ui.profileedit.model.UiProfileEditDetails
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.photo.PhotoPickerManager
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.flatMapIterable
import io.reactivex.rxkotlin.subscribeBy
import java.io.File
import javax.inject.Inject

class ProfileEditPresenterImpl @Inject constructor(
        private val view: ProfileEditView,
        private val messageManager: MessageManager,
        private val contactDetailsRepository: ContactDetailsRepository,
        private val profileManager: ProfileManager,
        private val photoPickerManager: PhotoPickerManager,
        private val parentPresenter: MainContentPresenter
) : ProfileEditPresenter {

    private val eventProfileId = profileManager.getEventProfileData().eventProfileId
    private val profileEmail = profileManager.getProfileData().email

    private lateinit var initialData: UiProfileEditDetails
    private lateinit var changedData: UiProfileEditDetails

    private val compositeDisposable = CompositeDisposable()
    private var updateDisposable: Disposable? = null
    private var pickedImageUri: Uri? = null
    private var imageLocationUri: Uri? = null
    private var imageClicked: Boolean = false
    private var con: Context? = null
    override fun onViewCreated(context:Context) {
        con = context
        contactDetailsRepository
                .outObtainOfContactError
                .filter {
                    val contactId = it.first
                    contactId == eventProfileId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val error = it.second
                    messageManager.handlePlainMessage(error)
                    view.close()
                }
                .addTo(compositeDisposable)

        contactDetailsRepository
                .outUpdateOfContactError
                .filter {
                    val contactId = it.first
                    contactId == eventProfileId
                }
                .map {
                    val error = it.second
                    error
                }
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        contactDetailsRepository
                .outUpdateOfContactSuccess
                .filter { contactId ->
                    eventProfileId == contactId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    updateSystemAccount(changedData.name!!)
                    if(imageLocationUri!=null){
                        changedData = changedData.copy(imageUri = imageLocationUri)
                        view.setPickedThumbnail(imageLocationUri)
                    }
                    messageManager.handlePlainMessage(R.string.profile_edit_success)
                    view.close()
                }
                .addTo(compositeDisposable)

        contactDetailsRepository
                .outContactDetails
                .flatMapIterable()
                .filter { contactDetails ->
                    contactDetails.id == eventProfileId
                }
                .map { mapToUiModel(it) }
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { view.showLoading(true) }
                .subscribeBy {
                    initialData = it
                    changedData = initialData.copy()

                    view.showLoading(false)
                    if(imageLocationUri!=null){
                        it.copy(imageUri = imageLocationUri)
                        changedData = changedData.copy(imageUri = imageLocationUri)
                        view.setPickedThumbnail(pickedImageUri)
                    }
                    view.showProfileDetails(it)
                }
                .addTo(compositeDisposable)

        contactDetailsRepository.obtainOfContact(eventProfileId)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
        updateDisposable?.dispose()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onBackPressed() {
        if (isDataChanged(initialData, changedData)) {
            view.showDiscardDialog()
        } else {
            view.close()
        }
    }

    override fun onNameChanged(name: String?) {
        val newName = handleNull(name)

        view.showNameInputError(!isNameValid(newName))

        changedData = changedData.copy(name = newName)
    }

    override fun onRoleChanged(role: String?) {
        changedData = changedData.copy(occupation = handleNull(role))
    }

    override fun onBioChanged(bio: String?) {
        changedData = changedData.copy(biography = handleNull(bio))
    }

    override fun onTwitterChanged(twitter: String?) {
        changedData = changedData.copy(twitter = handleNull(twitter))
    }

    override fun onFacebookChanged(facebook: String?) {
        changedData = changedData.copy(facebook = handleNull(facebook))
    }

    override fun onLinkedInChanged(linkedIn: String?) {
        changedData = changedData.copy(linkedIn = handleNull(linkedIn))
    }

    override fun onEditDoneClicked() {

        if(imageClicked){
            updateAccountDetails(changedData)
        }else{
            if (!isDataChanged(initialData, changedData)) {
                view.showInfoMessage(R.string.profile_edit_no_changes)
            } else if (isDataValid(changedData)) {
                updateAccountDetails(changedData)
            } else {
                view.showInfoMessage(R.string.profile_edit_invalid_data)
            }
        }
    }
    override fun onAddPhotoClicked() {
        view.checkStoragePermission()
    }

    override fun onStoragePermissionCheckResult(granted: Boolean) {
        if (granted) {
            view.requestPhotoPicker(photoPickerManager.getPickImageIntent())
        } else {
            view.requestStoragePermission()
        }
    }

    override fun onStoragePermissionGranted() {
        onStoragePermissionCheckResult(true)
    }

    override fun onStoragePermissionNotGranted() {
        messageManager.handlePlainMessage(R.string.post_new_permission)
    }

    override fun onPicturePicked(data: Intent?) {
        pickedImageUri = photoPickerManager.imageResult(data)

        if (pickedImageUri != null) {
            view.setPickedThumbnail(pickedImageUri)
            imageClicked = true

            //view.showRemoveImage(true)
        } else {
            imageClicked = false
            messageManager.handlePlainMessage(R.string.post_new_can_not_pick_image)
        }
    }
    override fun onDiscardClicked() {
        view.close()
    }

    override fun onSaveClicked() {
        if (isDataValid(changedData)) {
            updateAccountDetails(changedData)
        } else {
            view.showInfoMessage(R.string.profile_edit_invalid_data)
        }
    }

    private fun updateAccountDetails(details: UiProfileEditDetails) {

        val path = photoPickerManager.getPath(pickedImageUri)?.path
        val file = if (!path.isNullOrEmpty()) {
            imageLocationUri = Uri.parse(path)
            val pref = con!!.getSharedPreferences("PROFILE_PIC", Context.MODE_PRIVATE)
            val editor = pref.edit()
            editor.remove("PROFILE_PIC")
            editor.commit()

            val prefEditor = pref.edit()
            prefEditor.putString("image", path.toString())
            prefEditor.commit()
            Log.d("File path save:",":::"+path)
            File(path)

        } else {
            null
        }

        requireNotNull(details.name) { "Name must not be null!" }
        messageManager.handlePlainMessage(R.string.profile_edit_progress)
        val twitter = getFormattedTwitter(details.twitter)
        val entity = ContactDetailsEntity(eventProfileId, details.name!!, details.occupation, profileEmail, null,
                twitter, details.linkedIn, details.facebook, details.biography, details.imageUrl,details.crmId)

        contactDetailsRepository.updateOfContact(eventProfileId, entity,file)
    }

    private fun mapToUiModel(contact: ContactDetailsEntity): UiProfileEditDetails {
        return UiProfileEditDetails(contact.name, contact.jobTitle, contact.biography,
                contact.twitter, contact.facebook, contact.linkedIn, contact.imageUrl,contact.crmId,pickedImageUri)
    }

    private fun getFormattedTwitter(twitter: String?): String? {
        return twitter?.let {
            if (it.indexOf("@") == 0) {
                it
            } else {
                "@$it"
            }
        }
    }

    private fun isDataChanged(initialData: UiProfileEditDetails?, newData: UiProfileEditDetails?): Boolean {
        return initialData != newData
    }

    private fun isDataValid(data: UiProfileEditDetails?): Boolean {
        return data != null && isNameValid(data.name)
    }

    private fun isNameValid(name: String?): Boolean {
        return !name.isNullOrBlank()
    }

    private fun handleNull(value: String?): String? {
        return if (value.isNullOrBlank()) {
            null
        } else {
            value
        }
    }

    private fun updateSystemAccount(name: String) {
        profileManager.updateName(name)
        parentPresenter.reloadProfileData(imageLocationUri)
    }
}
