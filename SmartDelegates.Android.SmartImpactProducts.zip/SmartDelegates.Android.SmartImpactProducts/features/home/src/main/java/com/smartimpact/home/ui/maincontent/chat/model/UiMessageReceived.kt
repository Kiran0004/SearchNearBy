package com.smartimpact.home.ui.maincontent.chat.model

internal data class UiMessageReceived(
        val id: String,
        val messageText: String
) : BaseUiMessageModel
