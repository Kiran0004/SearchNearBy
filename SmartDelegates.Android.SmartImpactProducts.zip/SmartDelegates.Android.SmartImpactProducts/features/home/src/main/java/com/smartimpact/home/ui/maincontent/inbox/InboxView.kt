package com.smartimpact.home.ui.maincontent.inbox

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.inbox.model.BaseUiConversationModel

internal interface InboxView {

    fun showConversations(conversations: List<BaseUiConversationModel>)
    fun showConversations(conversations: List<BaseUiConversationModel>, diffResult: DiffUtil.DiffResult)
    fun showContent(show: Boolean)
    fun hideRefresh()
    fun enableSwipeRefresh()

}
