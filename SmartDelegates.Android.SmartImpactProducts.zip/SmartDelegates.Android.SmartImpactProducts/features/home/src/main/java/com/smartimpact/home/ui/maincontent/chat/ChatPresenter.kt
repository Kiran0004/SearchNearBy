package com.smartimpact.home.ui.maincontent.chat

internal interface ChatPresenter {

    fun onViewCreatedContact(contactId: String)
    fun onSendClicked(newMessage: String)
    fun onDestroyView()

}
