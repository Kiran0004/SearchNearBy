package com.smartimpact.home.ui.maincontent.sessiondetails.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

internal abstract class BaseUiSessionDetailsTile(
        open val titleText: String? = null,
        open val text: String? = null,
        open val detailsText: String? = null,
        open val avatarPlaceholderText: String? = null,
        open val avatarImageUrl: String? = null
) : BaseUiSessionDetails {

    @DrawableRes
    abstract fun getLeadingImageResource(): Int

    @StringRes
    open fun getTextResource(): Int? {
        return null
    }

}
