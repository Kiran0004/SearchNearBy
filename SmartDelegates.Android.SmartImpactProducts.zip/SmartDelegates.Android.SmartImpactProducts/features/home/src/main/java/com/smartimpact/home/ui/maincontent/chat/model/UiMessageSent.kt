package com.smartimpact.home.ui.maincontent.chat.model

internal data class UiMessageSent(
        val id: String,
        val messageText: String
) : BaseUiMessageModel
