package com.smartimpact.home.ui.maincontent.notes

import dagger.Binds
import dagger.Module

@Module
internal interface NotesModule {

    @Binds fun bindView(fragment: NotesFragment): NotesView

    @Binds fun bindPresenter(presenterImpl: NotesPresenterImpl): NotesPresenter

}