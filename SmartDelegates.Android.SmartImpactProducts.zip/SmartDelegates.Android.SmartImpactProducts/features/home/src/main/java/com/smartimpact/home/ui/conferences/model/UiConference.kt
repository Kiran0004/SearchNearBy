package com.smartimpact.home.ui.conferences.model

import org.threeten.bp.ZonedDateTime

internal data class UiConference(
        val id: String,
        val imageUrl: String?,
        val dateLocationText: String,
        val conferenceNameText: String,
        val startDate: ZonedDateTime,
        val endDate: ZonedDateTime,
        val isSelected: Boolean = false
) : BaseUiConferencesModel
