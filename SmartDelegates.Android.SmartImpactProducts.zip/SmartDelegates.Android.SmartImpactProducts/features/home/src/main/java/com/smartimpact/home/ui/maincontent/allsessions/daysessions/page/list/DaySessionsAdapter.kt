package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.session.itemlayout.SessionAdItemLayout
import com.smartimpact.home.session.itemlayout.SessionFullResponseItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model.*
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class DaySessionsAdapter(
        context: Context,
        private val listener: DaySessionsAdapterListener,
        private val imageLoader: ImageLoader,
        private val analyticsManager: AnalyticsManager
) : BaseItemsAdapter<BaseUiDaySessionsModel, DaySessionsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiDaySessionsSessionAd -> TYPE_SESSION_AD
            is UiDaySessionsSessionFullResponse -> TYPE_SESSION_FULL_RESPONSE
            is UiDaySessionsSessionSimple -> TYPE_SESSION_SIMPLE
            is UiDaySessionsTimeline -> TYPE_TIMELINE
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_SESSION_AD -> R.layout.item_session_ad
            TYPE_SESSION_FULL_RESPONSE -> R.layout.item_session_full_response
            TYPE_SESSION_SIMPLE -> R.layout.item_session_simple
            TYPE_TIMELINE -> R.layout.item_session_timeline
            else -> throw IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_SESSION_AD -> {
                val layout = view as SessionAdItemLayout
                layout.inject(listener, imageLoader,  analyticsManager)
                SessionAdVH(layout)
            }
            TYPE_SESSION_FULL_RESPONSE -> {
                val layout = view as SessionFullResponseItemLayout
                layout.inject(listener, imageLoader)
                SessionFullResponseVH(layout)
            }
            TYPE_SESSION_SIMPLE -> {
                val layout = view as SessionSimpleItemLayout
                layout.inject(listener)
                SessionSimpleVH(layout)
            }
            TYPE_TIMELINE -> {
                TimelineVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(hold: BaseVH, item: BaseUiDaySessionsModel, position: Int) {
        hold.bind(item)
    }

    fun setData(data: List<BaseUiDaySessionsModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(data)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiDaySessionsModel)
    }


    private class SessionAdVH(
            override val containerView: SessionAdItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiDaySessionsModel) {
            containerView.setData(
                    (item as UiDaySessionsSessionAd).sessionAd
            )
        }
    }

    private class SessionFullResponseVH(
            override val containerView: SessionFullResponseItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiDaySessionsModel) {
            containerView.setData(
                    (item as UiDaySessionsSessionFullResponse).sessionFullResponse
            )
        }
    }

    private class SessionSimpleVH(
            override val containerView: SessionSimpleItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiDaySessionsModel) {
            containerView.setData(
                    (item as UiDaySessionsSessionSimple).sessionSimple
            )
        }
    }

    private class TimelineVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiDaySessionsModel) {}
    }

    companion object {
        const val TYPE_SESSION_AD = 0
        const val TYPE_SESSION_FULL_RESPONSE = 1
        const val TYPE_SESSION_SIMPLE = 2
        const val TYPE_TIMELINE = 3
    }

}
