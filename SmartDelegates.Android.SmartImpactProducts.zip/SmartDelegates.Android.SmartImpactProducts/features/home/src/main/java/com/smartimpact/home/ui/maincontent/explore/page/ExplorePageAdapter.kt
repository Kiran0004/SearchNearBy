package com.smartimpact.home.ui.maincontent.explore.page

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.explore.page.attendees.ExploreAttendeesFragment
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageFragment
import com.smartimpact.home.ui.maincontent.explore.page.speakers.ExploreSpeakersFragment
import com.smartimpact.home.ui.maincontent.explore.page.exhibitors.ExploreExhibitorsFragment

internal class ExplorePageAdapter(
        private val context: Context,
        fragmentManager: FragmentManager
) : FragmentStatePagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getPageTitle(position: Int): CharSequence? {
        return context.getString(when (getPageType(position)) {
            PAGE_TYPE_ATTENDEES -> R.string.explore_tab_attendees
            PAGE_TYPE_SPEAKERS -> R.string.explore_tab_speakers
            PAGE_TYPE_EXHIBITORS -> R.string.explore_tab_exhibitors
            else -> throw IllegalStateException()
        })
    }

    override fun getItem(position: Int): Fragment {
        return when (getPageType(position)) {
            PAGE_TYPE_ATTENDEES -> ExploreAttendeesFragment.newInstance()
            PAGE_TYPE_SPEAKERS -> ExploreSpeakersFragment.newInstance()
            PAGE_TYPE_EXHIBITORS -> ExploreExhibitorsFragment.newInstance()
            else -> throw IllegalStateException()
        }
    }

    override fun getCount(): Int {
        return 3
    }

    private fun getPageType(position: Int): Int {
        return when (position) {
            0 -> PAGE_TYPE_ATTENDEES
            1 -> PAGE_TYPE_SPEAKERS
            2 -> PAGE_TYPE_EXHIBITORS
            else -> throw IllegalStateException()
        }
    }

    fun reloadCurrentPage(currentFragment: BaseExplorePageFragment) {
        currentFragment.reloadPage()
    }

    fun searchCurrentPage(currentFragment: BaseExplorePageFragment, query: String?) {
        currentFragment.searchFor(query)
    }

    companion object {
        private const val PAGE_TYPE_ATTENDEES = 0
        private const val PAGE_TYPE_SPEAKERS = 1
        private const val PAGE_TYPE_EXHIBITORS = 2
    }

}
