package com.smartimpact.home.ui.maincontent.explore.page.exhibitors

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView

internal interface ExploreExhibitorsView: BaseExplorePageView {

}
