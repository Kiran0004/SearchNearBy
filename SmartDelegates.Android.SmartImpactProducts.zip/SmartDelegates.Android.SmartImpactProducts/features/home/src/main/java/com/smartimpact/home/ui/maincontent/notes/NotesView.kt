package com.smartimpact.home.ui.maincontent.notes

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.notes.model.BaseUiNote

internal interface NotesView {
    fun setData(data: List<BaseUiNote>)
    fun setData(data: List<BaseUiNote>, diffResult: DiffUtil.DiffResult)
    fun showErrorWithRetry(message: String)
    fun showContent(show: Boolean)

}
