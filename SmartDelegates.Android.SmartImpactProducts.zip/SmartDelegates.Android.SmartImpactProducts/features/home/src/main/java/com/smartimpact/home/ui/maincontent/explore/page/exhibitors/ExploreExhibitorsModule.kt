package com.smartimpact.home.ui.maincontent.explore.page.exhibitors

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView
import dagger.Binds
import dagger.Module

@Module
internal interface ExploreExhibitorsModule {

    @Binds
    fun bindView(fragment: ExploreExhibitorsFragment): ExploreExhibitorsView

    @Binds
    fun bindPresenter(presenterImpl: ExploreExhibitorsPresenterImpl): ExploreExhibitorsPresenter

    @Binds
    fun bindBaseView(view: ExploreExhibitorsView): BaseExplorePageView

    @Binds
    fun bindBasePresenter(presenter: ExploreExhibitorsPresenter): BaseExplorePagePresenter
}
