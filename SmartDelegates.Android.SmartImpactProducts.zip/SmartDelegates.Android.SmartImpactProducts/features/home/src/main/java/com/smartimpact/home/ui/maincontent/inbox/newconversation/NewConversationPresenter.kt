package com.smartimpact.home.ui.maincontent.inbox.newconversation


internal interface NewConversationPresenter {
    fun onViewCreated()
    fun onDestroyView()
    fun reloadPage()
    fun searchFor(query: String?)

    fun onDestroy()
    fun onSearchChanged(query: String?)
    fun showErrorMessage(errorMessage: String, isSearch: Boolean)
    fun onSearchViewClosed()
    fun onSearchViewShown()
    fun openChatViewForContact(contactId: String)
}
