package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model.*

internal class DaySessionsDiffUtilCallback(
        private val oldList: List<BaseUiDaySessionsModel>,
        private val newList: List<BaseUiDaySessionsModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiDaySessionsSessionAd && newItem is UiDaySessionsSessionAd ->
                oldItem == newItem
            oldItem is UiDaySessionsSessionFullResponse && newItem is UiDaySessionsSessionFullResponse ->
                oldItem.sessionFullResponse.sessionFull.sessionId == newItem.sessionFullResponse.sessionFull.sessionId
            oldItem is UiDaySessionsSessionSimple && newItem is UiDaySessionsSessionSimple ->
                oldItem.sessionSimple.sessionId == newItem.sessionSimple.sessionId
            oldItem is UiDaySessionsTimeline && newItem is UiDaySessionsTimeline ->
                oldItem == newItem
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiDaySessionsSessionAd && newItem is UiDaySessionsSessionAd ->
                oldItem == newItem
            oldItem is UiDaySessionsSessionFullResponse && newItem is UiDaySessionsSessionFullResponse ->
                oldItem == newItem
            oldItem is UiDaySessionsSessionSimple && newItem is UiDaySessionsSessionSimple ->
                oldItem == newItem
            oldItem is UiDaySessionsTimeline && newItem is UiDaySessionsTimeline ->
                oldItem == newItem
            else -> false
        }
    }

}
