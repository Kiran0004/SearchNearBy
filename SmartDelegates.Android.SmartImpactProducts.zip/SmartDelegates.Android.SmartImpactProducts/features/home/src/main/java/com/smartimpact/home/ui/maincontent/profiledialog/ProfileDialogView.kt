package com.smartimpact.home.ui.maincontent.profiledialog

import com.smartimpact.home.ui.maincontent.profiledialog.model.UiProfileDialog

internal interface ProfileDialogView {

    fun showShimmer(shouldShow: Boolean)
    fun showProfile(profile: UiProfileDialog)
    fun closeDialog()
    fun showBookmarAction(show: Boolean)
    fun showChatAction(show: Boolean)

}
