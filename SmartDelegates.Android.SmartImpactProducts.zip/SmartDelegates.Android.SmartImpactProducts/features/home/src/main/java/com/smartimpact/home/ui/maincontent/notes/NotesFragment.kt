package com.smartimpact.home.ui.maincontent.notes

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.DividerItemDecoration
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.notes.list.NoteAdapter
import com.smartimpact.home.ui.maincontent.notes.list.NoteAdapterNoteItemListener
import com.smartimpact.home.ui.maincontent.notes.model.BaseUiNote
import kotlinx.android.synthetic.main.fragment_notes.*
import javax.inject.Inject

internal class NotesFragment : BaseDrawerFragment(), NotesView, NoteAdapterNoteItemListener {

    @Inject internal lateinit var presenter: NotesPresenter

    private lateinit var adapter: NoteAdapter

    override fun layoutRes(): Int {
        return R.layout.fragment_notes
    }

    override fun menuRes(): Int? {
        return R.menu.menu_notes
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_notes
    }

    override fun toolbar(): MaterialToolbar {
        return notesToolbar
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NoteAdapter(requireContext(), this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.adapter = adapter
        recycler.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_new_note -> {
                presenter.onNewNoteClicked()
                true
            }
            else -> false
        }
    }

    override fun setData(data: List<BaseUiNote>) {
        adapter.setData(data)
    }

    override fun setData(data: List<BaseUiNote>, diffResult: DiffUtil.DiffResult) {
        adapter.setData(data, diffResult)
    }

    override fun onNoteClicked(noteId: String) {
        presenter.onNoteClicked(noteId)
    }

    override fun showErrorWithRetry(message: String) {
        showErrorRetrySnackbar(message)
    }

    override fun onSnackbarRetryClicked() {
        presenter.onRetryClicked()
    }

    override fun showContent(show: Boolean) {
        recycler.isVisible = show
        tvNoContent.isVisible = !show
    }

    companion object {

        fun newInstance(drawerLayout: DrawerLayout): NotesFragment {
            return NotesFragment().apply {
                setDrawer(drawerLayout)
            }
        }

    }
}
