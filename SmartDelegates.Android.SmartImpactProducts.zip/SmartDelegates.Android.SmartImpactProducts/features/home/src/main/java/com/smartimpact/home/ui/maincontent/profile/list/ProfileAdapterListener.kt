package com.smartimpact.home.ui.maincontent.profile.list

interface ProfileAdapterListener {

    fun onEmailClicked(email: String)
    fun onWebsiteClicked(website: String)
    fun onTwitterClicked(twitter: String)
    fun onLinkedInClicked(linkedIn: String)
    fun onFacebookClicked(facebook: String)

}
