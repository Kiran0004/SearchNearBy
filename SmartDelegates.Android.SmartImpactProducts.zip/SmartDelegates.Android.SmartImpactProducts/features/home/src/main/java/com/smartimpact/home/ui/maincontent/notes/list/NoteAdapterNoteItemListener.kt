package com.smartimpact.home.ui.maincontent.notes.list

import com.smartimpact.home.ui.maincontent.notes.list.itemlayout.NoteItemLayout

internal interface NoteAdapterNoteItemListener: NoteItemLayout.NoteItemListener