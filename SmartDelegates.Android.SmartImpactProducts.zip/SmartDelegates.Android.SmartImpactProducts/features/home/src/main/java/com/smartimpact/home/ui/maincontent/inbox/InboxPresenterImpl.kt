package com.smartimpact.home.ui.maincontent.inbox

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.inbox.InboxRepository
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.inbox.list.InboxDiffUtilCallback
import com.smartimpact.home.ui.maincontent.inbox.model.BaseUiConversationModel
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversationShimmer
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class InboxPresenterImpl @Inject constructor(
        private val view: InboxView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val inboxRepository: InboxRepository,
        private val dateTimeFormatHelper: DateTimeFormatHelper
) : InboxPresenter {

    private val compositeDisposable = CompositeDisposable()

    private var dataLoaded: Boolean = false
    private var data: List<BaseUiConversationModel> = emptyList()

    override fun onViewCreated(chatId: String?) {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    inboxRepository.initialize()
                }
        )

        inboxRepository
                .outInitializationError
                .subscribeBy {
                    view.hideRefresh()
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        inboxRepository
                .outError
                .subscribeBy {
                    view.hideRefresh()
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)

        inboxRepository
                .outInbox
                .map { data ->
                    val conversations = data.map { it.first }
                    val list = mutableListOf<BaseUiConversationModel>()
                    conversations.sortedByDescending { it.lastMessageTime }.forEach {
                        list.add(UiConversation(
                                it.id,
                                it.receiver.imageUrl,
                                dateTimeFormatHelper.getTimeString(it.lastMessageTime),
                                it.isRead,
                                it.receiver.name,
                                it.lastMessage,
                                it.receiver.id))
                    }
                    list
                }
                .map { newData ->
                    val diffResult = DiffUtil.calculateDiff(InboxDiffUtilCallback(data, newData))
                    Pair(newData, diffResult)
                }
                .doOnSubscribe {
                    if (!dataLoaded) {
                        data = createConversationShimmers()
                        view.showConversations(data)
                        view.showContent(true)
                    }
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            dataLoaded = true
                            view.enableSwipeRefresh()

                            val newData = it.first
                            data = newData

                            view.showContent(newData.isNotEmpty())
                            view.showConversations(data, it.second)
                            view.hideRefresh()

                            if (chatId != null) {
                                val contactId = data.find { it is UiConversation && it.conversationId == chatId }
                                if (contactId != null && contactId is UiConversation) {
                                    parentPresenter.openChatViewForContact(contactId.partnerId)
                                }
                            }
                        }
                ).addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
        messageManager.releaseActionableMessagesLock()
    }

    override fun onConversationClicked(conversation: UiConversation) {
        inboxRepository.refresh() // Refresh to handle new message indicator
        parentPresenter.openChatViewForContact(conversation.partnerId)
    }

    override fun onRefresh() {
        inboxRepository.refresh()
    }

    private fun createConversationShimmers(): List<UiConversationShimmer> {
        return (0 until 10).map { shimmerVariance ->
            UiConversationShimmer(shimmerVariance)
        }
    }

    override fun onOpenNewConversation() {
        parentPresenter.openNewConversationView()
    }

}
