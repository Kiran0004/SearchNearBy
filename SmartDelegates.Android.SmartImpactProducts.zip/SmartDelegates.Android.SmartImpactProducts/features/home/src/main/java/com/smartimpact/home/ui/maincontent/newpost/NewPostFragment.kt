package com.smartimpact.home.ui.maincontent.newpost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_post_new.*
import javax.inject.Inject

internal class NewPostFragment : BaseToolbarFragment(), NewPostView {

    @Inject
    internal lateinit var presenter: NewPostPresenter
    @Inject
    internal lateinit var imageLoader: ImageLoader

    override fun layoutRes(): Int {
        return R.layout.fragment_post_new
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun navIconRes(): Int {
        return R.drawable.ic_exit
    }

    override fun toolbar(): MaterialToolbar {
        return newPostToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.SECONDARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etNewPost.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, before: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                presenter.onPostTextChanged(s.toString())
            }
        })

        btnNewPostConfirm.setOnClickListener {
            val text = etNewPost.text?.toString()
            presenter.onPostClicked(text)
        }
        btnNewPostPhoto.setOnClickListener {
            presenter.onAddPhotoClicked()
        }
        btnRemoveImage.setOnClickListener {
            presenter.onRemovePickedImage()
        }

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun requestPhotoPicker(pickImageIntent: Intent?) {
        if (pickImageIntent != null) {
            startActivityForResult(pickImageIntent, REQUEST_PICK_IMAGE)
        }
    }

    override fun setPickedThumbnail(pickedImageUri: Uri?) {
        if (pickedImageUri != null) {
            imageLoader.load(pickedImageUri, ivNewPostCamera, R.drawable.ic_camera)
        } else {
            ivNewPostCamera.setImageResource(R.drawable.ic_camera)
        }
    }

    override fun showLoading(show: Boolean) {
        btnNewPostConfirm.isVisible = !show
        postProgress.isVisible = show
    }

    override fun enableCreatePost(enable: Boolean) {
        btnNewPostConfirm.isEnabled = enable
    }

    override fun showRemoveImage(show: Boolean) {
        btnRemoveImage.isVisible = show
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_PICK_IMAGE -> {
                if (resultCode == Activity.RESULT_OK) {
                    presenter.onPicturePicked(data)
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun checkStoragePermission() {
        val hasPermission = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        presenter.onStoragePermissionCheckResult(hasPermission)
    }

    override fun requestStoragePermission() {
        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSION_STORAGE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_PERMISSION_STORAGE -> {
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    presenter.onStoragePermissionNotGranted()
                } else {
                    presenter.onStoragePermissionGranted()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    companion object {
        private const val REQUEST_PICK_IMAGE = 1

        private const val REQUEST_PERMISSION_STORAGE = 2

        fun newInstance() = NewPostFragment()
    }
}
