package com.smartimpact.home.ui.maincontent.inbox.list

import com.smartimpact.home.ui.maincontent.inbox.list.listitem.ConversationItemLayout

internal interface ConversationsAdapterListener : ConversationItemLayout.Listener
