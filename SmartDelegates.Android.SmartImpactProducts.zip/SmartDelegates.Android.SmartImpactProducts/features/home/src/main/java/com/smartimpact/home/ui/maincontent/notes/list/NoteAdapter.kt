package com.smartimpact.home.ui.maincontent.notes.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.notes.list.itemlayout.NoteItemLayout
import com.smartimpact.home.ui.maincontent.notes.model.BaseUiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNoteShimmer
import si.kamino.adapter.BaseItemsAdapter

internal class NoteAdapter(
        context: Context,
        private val listener: NoteAdapterNoteItemListener
) : BaseItemsAdapter<BaseUiNote, RecyclerView.ViewHolder>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (data[position]) {
            is UiNote -> ITEM_TYPE_NOTE
            is UiNoteShimmer -> ITEM_TYPE_SHIMMER
            else -> throw IllegalArgumentException("Unexpected type ${data[position]}")
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            ITEM_TYPE_NOTE -> {
                val layout = view as NoteItemLayout
                layout.inject(listener)
                ItemVH(layout)
            }
            ITEM_TYPE_SHIMMER -> ShimmerVH(view)
            else -> throw IllegalArgumentException("Unexpected type $viewType")
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            ITEM_TYPE_NOTE -> R.layout.item_note
            ITEM_TYPE_SHIMMER -> R.layout.item_note_shimmer
            else -> throw IllegalArgumentException("Unexpected type $viewType")
        }
    }

    override fun doBind(holder: RecyclerView.ViewHolder, item: BaseUiNote, position: Int) {
        when (item) {
            is UiNote -> (holder as ItemVH).bind(item)
        }
    }

    fun setData(newData: List<BaseUiNote>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(newData)
    }

    inner class ItemVH(private val view: NoteItemLayout) : RecyclerView.ViewHolder(view) {

        fun bind(data: UiNote) {
            view.bind(data)
        }

    }

    inner class ShimmerVH(view: View) : RecyclerView.ViewHolder(view)

    companion object {
        private const val ITEM_TYPE_NOTE = 0
        private const val ITEM_TYPE_SHIMMER = 1
    }
}