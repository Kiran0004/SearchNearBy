package com.smartimpact.home.ui.maincontent.home.posts.model

import com.smartimpact.home.post.model.UiPostImage

internal data class UiHomePostImage(
        val postImage: UiPostImage
) : BaseUiHomePostModel
