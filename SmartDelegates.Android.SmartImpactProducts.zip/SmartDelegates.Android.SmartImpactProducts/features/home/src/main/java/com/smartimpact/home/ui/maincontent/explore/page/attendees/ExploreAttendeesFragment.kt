package com.smartimpact.home.ui.maincontent.explore.page.attendees

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageFragment
import javax.inject.Inject

internal class ExploreAttendeesFragment : BaseExplorePageFragment(), ExploreAttendeesView {

    @Inject
    internal lateinit var presenter: ExploreAttendeesPresenter

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        presenter.onPersonClicked(person)
    }

    companion object {
        fun newInstance(): ExploreAttendeesFragment {
            return ExploreAttendeesFragment()
        }
    }

}
