package com.smartimpact.home.ui.maincontent.allposts.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.post.itemlayout.PostAdItemLayout
import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout
import com.smartimpact.home.ui.maincontent.allposts.list.itemlayout.AllPostsTimeItemLayout
import com.smartimpact.home.ui.maincontent.allposts.model.*
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class AllPostsAdapter(
        context: Context,
        private val listener: AllPostsAdapterListener,
        private val imageLoader: ImageLoader,
        private val analyticsManager: AnalyticsManager
) : BaseItemsAdapter<BaseUiAllPostsModel, AllPostsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiAllPostsPostAd -> TYPE_POST_AD
            is UiAllPostsPostImage -> TYPE_POST_IMAGE
            is UiAllPostsPostShimmer -> TYPE_POST_SHIMMER
            is UiAllPostsPostText -> TYPE_POST_TEXT
            is UiAllPostsTime -> TYPE_TIME
            is UiAllPostsTimeShimmer -> TYPE_TIME_SHIMMER
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_POST_AD -> R.layout.item_post_ad
            TYPE_POST_IMAGE -> R.layout.item_post_image
            TYPE_POST_SHIMMER -> R.layout.item_post_shimmer
            TYPE_POST_TEXT -> R.layout.item_post_text
            TYPE_TIME -> R.layout.item_all_posts_time
            TYPE_TIME_SHIMMER -> R.layout.item_all_posts_time_shimmer
            else -> throw IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_POST_AD -> {
                val layout = view as PostAdItemLayout
                layout.inject(listener, imageLoader, analyticsManager)
                PostAdVH(layout)
            }
            TYPE_POST_IMAGE -> {
                val layout = view as PostImageItemLayout
                layout.inject(listener, imageLoader)
                PostImageVH(layout)
            }
            TYPE_POST_SHIMMER -> {
                PostShimmerVH(view)
            }
            TYPE_POST_TEXT -> {
                val layout = view as PostTextItemLayout
                layout.inject(listener, imageLoader)
                PostTextVH(layout)
            }
            TYPE_TIME -> {
                val layout = view as AllPostsTimeItemLayout
                TimeVH(layout)
            }
            TYPE_TIME_SHIMMER -> {
                TimeShimmerVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiAllPostsModel, position: Int) {
        holder.bind(item)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiAllPostsModel)
    }

    private class PostAdVH(
            override val containerView: PostAdItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {
            containerView.setData(
                    (item as UiAllPostsPostAd).postAd
            )
        }
    }

    private class PostImageVH(
            override val containerView: PostImageItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {
            containerView.setData(
                    (item as UiAllPostsPostImage).postImage
            )
        }
    }

    private class PostShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {}
    }

    private class PostTextVH(
            override val containerView: PostTextItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {
            containerView.setData(
                    (item as UiAllPostsPostText).postText
            )
        }
    }

    private class TimeVH(
            override val containerView: AllPostsTimeItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {
            containerView.setData(
                    item as UiAllPostsTime
            )
        }
    }

    private class TimeShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiAllPostsModel) {}
    }

    companion object {
        const val TYPE_POST_AD = 0
        const val TYPE_POST_IMAGE = 1
        const val TYPE_POST_SHIMMER = 2
        const val TYPE_POST_TEXT = 3
        const val TYPE_TIME = 4
        const val TYPE_TIME_SHIMMER = 5
    }
}
