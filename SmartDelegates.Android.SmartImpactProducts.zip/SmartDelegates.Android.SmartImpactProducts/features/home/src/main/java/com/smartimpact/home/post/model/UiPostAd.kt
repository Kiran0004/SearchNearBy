package com.smartimpact.home.post.model

import com.smartimpact.data.ads.entity.AdEntity

internal data class UiPostAd(
        val variants: List<AdEntity>
) : BaseUiPostModel
