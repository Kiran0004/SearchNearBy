package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.session.model.UiSessionFullResponse
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list.DaySessionsAdapter
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list.DaySessionsAdapterListener
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list.DaySessionsItemDecoration
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model.BaseUiDaySessionsModel
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_notes.*
import javax.inject.Inject

internal class DaySessionsPageFragment : DaggerFragment(), DaySessionsPageView, DaySessionsAdapterListener {

    @Inject internal lateinit var presenter: DaySessionsPagePresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    @Inject internal lateinit var analyticsManager: AnalyticsManager

    private lateinit var sessionAdapter: DaySessionsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_day_sessions, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sessionAdapter = DaySessionsAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.adapter = sessionAdapter
        recycler.addItemDecoration(DaySessionsItemDecoration())

        val day = arguments?.getParcelable<UiConferenceDay>(ARGS_DAY)
                ?: throw IllegalStateException("Day must be provided")

        presenter.onViewCreated(day)
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun setData(sessions: List<BaseUiDaySessionsModel>, diffResult: DiffUtil.DiffResult) {
        sessionAdapter.setData(sessions, diffResult)
    }

    override fun openWebsite(websiteIntent: Intent?) {
        startActivity(websiteIntent)
    }

    override fun onAdClicked(adUrl: String) {
        presenter.onSessionAdClicked(adUrl)
    }

    override fun onSessionClicked(session: UiSessionFullResponse) {
        presenter.onSessionFullResponseClicked(session)
    }

    override fun onSessionClicked(session: UiSessionSimple) {
        presenter.onSessionSimpleClicked(session)
    }

    override fun onSessionResponseClicked(sessionId: String, response: Int) {
        presenter.onSessionResponseClicked(sessionId, response)
    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        presenter.onSessionSpeakersClicked(sessionId, speakers)
    }

    companion object {
        private const val ARGS_DAY = "com.smartimpact.home.ui.maincontent.allsessions.page.daysessions.DaySessionsPageFragment.day"

        fun newInstance(day: UiConferenceDay): DaySessionsPageFragment {
            return DaySessionsPageFragment().apply {
                arguments = bundleOf(ARGS_DAY to day)
            }
        }
    }
}
