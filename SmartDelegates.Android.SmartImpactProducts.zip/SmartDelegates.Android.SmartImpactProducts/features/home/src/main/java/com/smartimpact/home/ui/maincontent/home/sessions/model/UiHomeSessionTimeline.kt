package com.smartimpact.home.ui.maincontent.home.sessions.model

import com.smartimpact.home.session.model.UiSessionTimeline

internal data class UiHomeSessionTimeline(
        val sessionTimeline: UiSessionTimeline
) : BaseUiHomeSessionModel
