package com.smartimpact.home.ui.maincontent.maps.page

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.ConferenceMapFragment
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap.LocationMapFragment

internal class MapsPageAdapter(
        private val context: Context,
        fragmentManager: FragmentManager) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getCount(): Int {
        return 2
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            ITEM_CONFERENCE_MAP -> context.resources.getString(R.string.maps_event)
            ITEM_LOCATION_MAP -> context.resources.getString(R.string.maps_location)
            else -> throw IllegalArgumentException("Unexpected position")
        }
    }

    override fun getItem(position: Int): Fragment {
        return when (getPageType(position)) {
            ITEM_CONFERENCE_MAP -> ConferenceMapFragment.newInstance()
            ITEM_LOCATION_MAP -> LocationMapFragment.newInstance()
            else -> throw IllegalStateException()
        }
    }

    private fun getPageType(position: Int): Int {
        return when (position) {
            0 -> ITEM_CONFERENCE_MAP
            1 -> ITEM_LOCATION_MAP
            else -> throw IllegalStateException()
        }
    }

    private companion object {
        const val ITEM_CONFERENCE_MAP = 0
        const val ITEM_LOCATION_MAP = 1
    }
}