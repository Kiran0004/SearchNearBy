package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.data.session.entity.SessionEntity
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.mod.ShowWhileResumedMessageManagerMod
import com.smartimpact.home.session.mapper.SessionUiMapper
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.maincontent.bookmarks.BookmarksPresenter
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter.BookmarksSessionsDuffUtilCallback
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.BaseUiBookmarksSessionsModel
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionFull
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionShimmer
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionSimple
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.ZonedDateTime
import javax.inject.Inject

internal class BookmarksSessionsPresenterImpl @Inject constructor(
        private val view: BookmarksSessionsView,
        private val parentPresenter: BookmarksPresenter,
        private val messageManager: MessageManager,
        private val bookmarksRepository: BookmarksRepository,
        private val sessionsRepository: SessionRepository,
        private val sessionUiMapper: SessionUiMapper
) : BookmarksSessionsPresenter {

    private var hasData: Boolean = false
    private lateinit var data: List<BaseUiBookmarksSessionsModel>

    private lateinit var messageManagerMod: ShowWhileResumedMessageManagerMod

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManagerMod = ShowWhileResumedMessageManagerMod(
                messageManager = messageManager,
                onAction = {
                    bookmarksRepository.initialize()
                    sessionsRepository.initialize()
                }
        )

        bookmarksRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        sessionsRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        sessionsRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        if (!hasData) {
            // TODO show shimmer only if bookmarksRepository and sessionsRepository have not been initialized
            data = createShimmerItems()
            view.showBookmarkedSessions(data)
        }

        Observable
                .combineLatest(
                        bookmarksRepository.outBookmarkedSessionIds,
                        sessionsRepository.outSessions,
                        BiFunction { bookmarkedSessionIds: Set<String>, sessions: List<SessionEntity> ->
                            Pair(bookmarkedSessionIds, sessions)
                        }
                )
                .map {
                    val bookmarkedSessionIds = it.first
                    val sessions = it.second

                    sessions.filter { session ->
                        bookmarkedSessionIds.contains(session.sessionId)
                    }
                }
                .map {
                    mapToUi(it)
                }
                .map { newData ->
                    val diffResult = DiffUtil.calculateDiff(BookmarksSessionsDuffUtilCallback(data, newData))

                    Pair(newData, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val newData = it.first
                    val diffResult = it.second

                    hasData = true
                    data = newData
                    view.showNoContent(data.isEmpty())
                    view.showBookmarkedSessions(data, diffResult)
                }
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onResume() {
        messageManagerMod.onResume()
    }

    override fun onPause() {
        messageManagerMod.onPause()
    }

    override fun onSessionFullClicked(session: UiSessionFull) {
        parentPresenter.openSessionDetailsView(session.sessionId)
    }

    override fun onSessionSimpleClicked(session: UiSessionSimple) {
        parentPresenter.openSessionDetailsView(session.sessionId)
    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        if (speakers.size == 1) {
            parentPresenter.openProfileDialog(speakers.first().speakerId)
        } else {
            parentPresenter.openSessionDetailsView(sessionId)
        }
    }

    private fun createShimmerItems(): List<UiBookmarksSessionShimmer> {
        return (0 until 5).map {
            UiBookmarksSessionShimmer()
        }
    }

    private fun mapToUi(sessionEntities: List<SessionEntity>): List<BaseUiBookmarksSessionsModel> {
        return sessionEntities
                .map { sessionEntity ->
                    sessionUiMapper.mapToUi(sessionEntity, ZonedDateTime.now())
                }
                .map { uiSession ->
                    when (uiSession) {
                        is UiSessionFull -> UiBookmarksSessionFull(uiSession)
                        is UiSessionSimple -> UiBookmarksSessionSimple(uiSession)
                        else -> throw IllegalStateException()
                    }
                }
    }

}
