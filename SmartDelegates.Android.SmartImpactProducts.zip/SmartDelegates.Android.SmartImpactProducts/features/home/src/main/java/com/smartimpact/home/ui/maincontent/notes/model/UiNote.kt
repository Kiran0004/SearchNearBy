package com.smartimpact.home.ui.maincontent.notes.model

internal data class UiNote(
        val noteId: String,
        val subject: String,
        val content: String?,
        val timeStamp: String
) : BaseUiNote