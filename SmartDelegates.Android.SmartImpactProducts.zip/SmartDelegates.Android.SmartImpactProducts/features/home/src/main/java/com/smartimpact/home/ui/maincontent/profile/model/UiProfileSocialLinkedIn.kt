package com.smartimpact.home.ui.maincontent.profile.model

import com.smartimpact.home.R

internal data class UiProfileSocialLinkedIn(val linkedIn: String) : BaseUiProfileSocialTile {

    override fun leadingImageRes(): Int? {
        return R.drawable.ic_linked_in
    }

    override fun titleTextRes(): Int? {
        return R.string.social_linked_in
    }

    override fun trailingText(): String? {
        return linkedIn
    }
}
