package com.smartimpact.home.ui.maincontent.bookmarks.page.people

import dagger.Binds
import dagger.Module

@Module
internal interface BookmarksPeopleModule {

    @Binds
    fun bindView(fragment: BookmarksPeopleFragment): BookmarksPeopleView

    @Binds
    fun bindPresenter(presenterImpl: BookmarksPeoplePresenterImpl): BookmarksPeoplePresenter

}
