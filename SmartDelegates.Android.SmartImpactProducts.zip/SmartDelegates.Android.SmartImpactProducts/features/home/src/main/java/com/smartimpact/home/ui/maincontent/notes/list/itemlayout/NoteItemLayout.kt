package com.smartimpact.home.ui.maincontent.notes.list.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.home.ui.maincontent.notes.model.UiNote
import kotlinx.android.synthetic.main.item_note.view.*

internal class NoteItemLayout(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    private lateinit var listener: NoteItemListener

    private lateinit var data: UiNote

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onNoteClicked(data.noteId)
        }
    }

    fun inject(listener: NoteItemListener) {
        this.listener = listener
    }

    fun bind(data: UiNote) {
        this.data = data
        tvSubject.text = data.subject
        tvContent.text = data.content
        tvTimeStamp.text = data.timeStamp
    }

    interface NoteItemListener {

        fun onNoteClicked(noteId: String)

    }

}