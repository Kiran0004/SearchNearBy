package com.smartimpact.home.session.itemlayout

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.card.MaterialCardView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.home.session.model.UiSessionAd
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_session_ad.view.*

internal class SessionAdItemLayout(context: Context?, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    fun inject(listener: AdView.Listener, imageLoader: ImageLoader, analyticsManager: AnalyticsManager) {
        ivAd.inject(imageLoader, listener, analyticsManager)
    }

    fun setData(sessionAd: UiSessionAd) {
        ivAd.bind(sessionAd.variants)
    }
}
