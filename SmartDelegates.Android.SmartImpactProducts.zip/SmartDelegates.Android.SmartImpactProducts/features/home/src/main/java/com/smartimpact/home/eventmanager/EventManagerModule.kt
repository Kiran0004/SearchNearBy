package com.smartimpact.home.eventmanager

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.connectivity.ConnectivityStatusManager
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.session.SessionRepository
import dagger.Module
import dagger.Provides

@Module
class EventManagerModule {

    @Provides
    @FragmentScope(FragmentScope.CONTAINER)
    fun provideEventManager(
            connectivityStatusManager: ConnectivityStatusManager,
            adsRepository: AdsRepository,
            bookmarksRepository: BookmarksRepository,
            contactRepository: ContactRepository,
            contactDetailsRepository: ContactDetailsRepository,
            postRepository: PostRepository,
            sessionRepository: SessionRepository
    ): EventManager {
        return EventManagerImpl(
                connectivityStatusManager = connectivityStatusManager,
                eventDataRepositories = listOf(
                        adsRepository,
                        bookmarksRepository,
                        contactRepository,
                        contactDetailsRepository,
                        postRepository,
                        sessionRepository
                )
        )
    }

}
