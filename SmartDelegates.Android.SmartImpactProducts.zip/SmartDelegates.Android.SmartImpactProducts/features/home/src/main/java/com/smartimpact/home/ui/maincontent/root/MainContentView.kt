package com.smartimpact.home.ui.maincontent.root

import android.content.Intent
import android.net.Uri
import com.smartimpact.base.messagemanager.data.ActionableMessage
import com.smartimpact.base.messagemanager.data.PlainMessage
import com.smartimpact.base.ui.navigation.model.UiProfileShort

interface MainContentView {
    // show used to show main fragments
    fun showHomeView()

    fun showInboxView(chatId: String?)
    fun showExploreView()
    fun showMapsView()
    fun showBookmarksView()
    fun showNotesView()
    fun showInfoView()
    fun showSettingsView()

    // open fragment over content
    fun openAllPostsView()

    fun openAllSessionsView()
    fun openPostDetailsView(postId: String, tweetUrl: String? = null)
    fun openNewPostView()
    fun openNoteEditView(noteId: String)
    fun openChatViewForContact(contactId: String)
    fun openSelectEventView()
    fun openSessionDetailsView(sessionId: String)
    fun openProfileDialog(profileId: String)
    fun openProfileView(profileId: String, isSponsor: Boolean)
    fun openProfileEditView()

    fun lockDrawer(lock: Boolean)
    fun closeDrawer()
    fun showProfile(profile: UiProfileShort)

    fun showProfileUri(profile:UiProfileShort,uri: Uri)

    fun showNavigationItems(hasNewMessage: Boolean)

    fun showPlainMessage(message: PlainMessage)
    fun showActionableMessage(message: ActionableMessage)
    fun dismissMessage()

    fun openNewConversationView()
    fun handleIntent(intent: Intent)

}
