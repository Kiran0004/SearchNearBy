package com.smartimpact.home.ui.conferences.model

internal class UiConferencesHeader : BaseUiConferencesModel
