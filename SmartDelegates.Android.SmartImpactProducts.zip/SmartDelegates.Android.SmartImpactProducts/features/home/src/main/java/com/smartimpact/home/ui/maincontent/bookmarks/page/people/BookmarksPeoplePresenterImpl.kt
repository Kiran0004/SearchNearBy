package com.smartimpact.home.ui.maincontent.bookmarks.page.people

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.base.ui.list.peoplelist.util.PeopleListUtil
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.mod.ShowWhileResumedMessageManagerMod
import com.smartimpact.home.ui.maincontent.bookmarks.page.people.model.UiBookmarkedPerson
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class BookmarksPeoplePresenterImpl @Inject constructor(
        private val view: BookmarksPeopleView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val bookmarksRepository: BookmarksRepository,
        private val contactRepository: ContactRepository
) : BookmarksPeoplePresenter {

    private var hasData: Boolean = false
    private var data: List<BaseUiPeopleListModel> = emptyList()

    private lateinit var messageManagerMod: ShowWhileResumedMessageManagerMod

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManagerMod = ShowWhileResumedMessageManagerMod(
                messageManager = messageManager,
                onAction = {
                    bookmarksRepository.initialize()
                    contactRepository.initialize()
                }
        )

        bookmarksRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)


        contactRepository
                .outInitializationError
                .subscribeBy { messageManagerMod.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        contactRepository
                .outError
                .subscribeBy { messageManagerMod.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        if (!hasData) {
            // TODO show shimmer only if bookmarksRepository and contactRepository have not been initialized
            data = PeopleListUtil.createShimmers(true)
            view.showPeopleList(data)
        }

        Observable
                .combineLatest(
                        bookmarksRepository.outBookmarkedContactIds,
                        contactRepository.outPeople,
                        BiFunction { bookmarkedContactIds: Set<String>, people: List<ContactEntity> ->
                            Pair(bookmarkedContactIds, people)
                        }
                )
                .map {
                    val bookmarkedContactIds = it.first
                    val people = it.second

                    people.filter { person ->
                        bookmarkedContactIds.contains(person.id)
                    }
                }
                .map { mapToUi(it) }
                .map { PeopleListUtil.sortAndGroup(it) }
                .map { newData ->
                    val diffResult = PeopleListUtil.computeDiffResult(data, newData)
                    Pair(newData, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val newData = it.first
                    val diffResult = it.second

                    hasData = true
                    data = newData
                    view.showNoContent(data.isEmpty())
                    view.showPeopleList(data, diffResult)
                }
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onResume() {
        messageManagerMod.onResume()
    }

    override fun onPause() {
        messageManagerMod.onPause()
    }

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        parentPresenter.openProfileDialog(person.id)
    }

    private fun mapToUi(contactEntities: List<ContactEntity>): List<UiBookmarkedPerson> {
        return contactEntities.map {
            UiBookmarkedPerson(
                    it.id,
                    it.imageUrl,
                    it.name,
                    it.description,
                    it.isSponsor)
        }
    }

}
