package com.smartimpact.home.ui.maincontent.profiledialog

internal interface ProfileDialogPresenter {

    fun onActivityCreated(profileId: String)
    fun onDismissDialog()
    fun onViewProfileClicked()
    fun onToggleBookmarkClicked()
    fun onChatProfileClicked()

}
