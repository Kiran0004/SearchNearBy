package com.smartimpact.home.ui.maincontent.profiledialog.model

data class UiProfileDialog(
        val profileName: String,
        val isProfileBookmarked: Boolean,
        val profileDescription: String?,
        val profilePhotoUrl: String?
)
