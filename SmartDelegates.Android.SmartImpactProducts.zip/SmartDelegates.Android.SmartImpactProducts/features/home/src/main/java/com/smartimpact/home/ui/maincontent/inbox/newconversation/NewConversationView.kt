package com.smartimpact.home.ui.maincontent.inbox.newconversation

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel


internal interface NewConversationView {
    fun showContent(show: Boolean)
    fun showPeopleList(list: List<BaseUiPeopleListModel>)
    fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult)

    fun reloadPage()
    fun searchFor(query: String?)
}
