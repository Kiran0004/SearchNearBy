package com.smartimpact.home.ui.maincontent.allsessions

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.DaySessionsPageFragment
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.DaySessionsPageModule
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal interface AllSessionsModule {

    @Binds fun bindView(fragment: AllSessionsFragment): AllSessionsView

    @Binds fun bindPresenter(presenterImpl: AllSessionsPresenterImpl): AllSessionsPresenter

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [DaySessionsPageModule::class])
    fun contributeDaySessionsPageFragmentInjector(): DaySessionsPageFragment
}
