package com.smartimpact.home.ui.maincontent.profile.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

internal interface BaseUiProfileTile : BaseUiProfileModel {

    @DrawableRes fun leadingImageRes(): Int?
    fun titleText(): String?
    @StringRes fun titleTextRes(): Int?
    fun text(): String?
    fun detailsText(): String?
    fun trailingText(): String?

}
