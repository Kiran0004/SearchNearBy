package com.smartimpact.home.ui.maincontent.profiledialog

import dagger.Binds
import dagger.Module

@Module
internal interface ProfileDialogModule {

    @Binds fun bindView(fragment: ProfileDialogFragment): ProfileDialogView

    @Binds fun bindPresenter(presenterImpl: ProfileDialogPresenterImpl): ProfileDialogPresenter

}
