package com.smartimpact.home.ui.maincontent.explore.page.speakers

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter

internal interface ExploreSpeakersPresenter : BaseExplorePagePresenter {

    fun onPersonClicked(person: BaseUiPeopleListPerson)

}
