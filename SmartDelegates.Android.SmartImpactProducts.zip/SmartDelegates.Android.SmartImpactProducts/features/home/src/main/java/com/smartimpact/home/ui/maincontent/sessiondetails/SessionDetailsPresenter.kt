package com.smartimpact.home.ui.maincontent.sessiondetails

import android.net.Uri

internal interface SessionDetailsPresenter {

    fun onCreate(sessionId: String)
    fun onDestroy()
    fun onViewCreated()
    fun onDestroyView()
    fun onToggleBookmarkClicked()
    fun onSpeakerClicked(speakerId: String)
    fun onSessionResponseClicked(response: Int)
    fun onAttachmentClicked(attachmentUri: Uri)
    fun onStoragePermissionCheckResult(granted: Boolean)
    fun onStoragePermissionGranted()
    fun onStoragePermissionNotGranted()

}
