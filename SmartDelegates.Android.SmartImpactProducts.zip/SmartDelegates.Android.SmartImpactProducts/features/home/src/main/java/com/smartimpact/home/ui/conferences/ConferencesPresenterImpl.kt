package com.smartimpact.home.ui.conferences

import com.smartimpact.api.ApiService
import com.smartimpact.auth.AccountManager
import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.datetime.DateTimeConverterHelper
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.ui.conferences.model.BaseUiConferencesModel
import com.smartimpact.home.ui.conferences.model.UiConference
import com.smartimpact.home.ui.conferences.model.UiConferenceShimmer
import com.smartimpact.home.ui.conferences.model.UiConferencesHeader
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class ConferencesPresenterImpl @Inject constructor(
        private val view: ConferencesView,
        private val parentPresenter: MainContentPresenter,
        private val profileManager: ProfileManager,
        private val accountManager: AccountManager,
        private val apiService: ApiService,
        private val errorMessageManager: ErrorMessageManager,
        private val dateTimeFormatHelper: DateTimeFormatHelper
) : ConferencesPresenter {

    private var disposable: Disposable? = null
    private var conferences: List<BaseUiConferencesModel> = emptyList()

    override fun onActivityCreated() {
        loadConferences()
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun onConferenceClicked(conference: UiConference) {
        conferences = conferences.map {
            if (it is UiConference) {
                val isSelected = (it.id == conference.id)
                it.copy(isSelected = isSelected)
            } else {
                it
            }
        }
        view.setConferencesListItems(conferences)
        disposable?.dispose()

        view.showErrorMessage(false)

        disposable = apiService.getUserProfile(conference.id, profileManager.getProfileData().email)
                .flatMap { profile ->
                    val pushAccountId = accountManager.currentUserData?.pushData?.pushAccountId
                            ?: throw IllegalStateException("User must be selected, before calling this function")

                    apiService.registerPushNotifications(profile.contact.id, conference.id, "\"${pushAccountId}\"")
                            .andThen(Single.just(profile))
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            profileManager.updateUser(it.id, it.contact.name, it.contact.thumbnailUrl)
                            profileManager.selectEvent(conference.id, conference.startDate, conference.endDate, null, null,
                                    it.contact.id, null)
                            parentPresenter.onNewEventSelected()
                        },
                        onError = {
                            view.showErrorMessage(true, errorMessageManager.getErrorMessage(it))
                        }
                )
    }

    override fun onRetryClicked() {
        loadConferences()
    }

    private fun createShimmerListItems(): List<BaseUiConferencesModel> {
        val header = UiConferencesHeader()
        val shimmers = (0 until 5).map { shimmerVariance ->
            UiConferenceShimmer(shimmerVariance)
        }
        return listOf(header, *shimmers.toTypedArray())
    }

    private fun loadConferences() {
        disposable?.dispose()

        view.showErrorMessage(false)
        view.setConferencesListItems(createShimmerListItems())

        disposable = apiService.getConferences(profileManager.getProfileData().email)
                .delaySubscription(SHIMMER_DELAY_MS, TimeUnit.MILLISECONDS) // Allow shimmer to have effect
                .flattenAsObservable { it }
                .map {
                    val startDate = DateTimeConverterHelper.toSystemZonedDateTime(it.startDate)
                    val endDate = DateTimeConverterHelper.toSystemZonedDateTime(it.endDate)
                    UiConference(it.id,
                            it.imageUrl,
                            "${dateTimeFormatHelper.getTwoDatesString(startDate, endDate)},  ${it.city}",
                            it.title,
                            it.startDate,
                            it.endDate)
                }
                .toList()
                .map {
                    val list = mutableListOf<BaseUiConferencesModel>(UiConferencesHeader())
                    list.addAll(it)
                    list
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            conferences = it
                            view.setConferencesListItems(it)
                        },
                        onError = {
                            view.showErrorMessage(true, errorMessageManager.getErrorMessage(it))
                        }
                )
    }

    private companion object {
        private const val SHIMMER_DELAY_MS = 500L
    }

}
