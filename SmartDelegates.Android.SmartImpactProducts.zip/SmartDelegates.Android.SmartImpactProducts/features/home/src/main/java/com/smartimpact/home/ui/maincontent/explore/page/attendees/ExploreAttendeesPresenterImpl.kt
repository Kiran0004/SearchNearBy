package com.smartimpact.home.ui.maincontent.explore.page.attendees

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.home.ui.maincontent.explore.ExplorePresenter
import com.smartimpact.home.ui.maincontent.explore.page.attendees.model.UiAttendee
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenterImpl
import io.reactivex.Observable
import io.reactivex.Single
import javax.inject.Inject

@FragmentScope(FragmentScope.SUB_FRAGMENT)
internal class ExploreAttendeesPresenterImpl @Inject constructor(
        private val view: ExploreAttendeesView,
        private val adsRepository: AdsRepository,
        private val contactRepository: ContactRepository,
        private val parentPresenter: ExplorePresenter,
        errorMessageManager: ErrorMessageManager

) : BaseExplorePagePresenterImpl<UiAttendee>(view, parentPresenter, errorMessageManager, adsRepository), ExploreAttendeesPresenter {

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        parentPresenter.onPersonClicked(person.id)
    }

    override fun mapToUi(data: List<ContactEntity>): List<UiAttendee> {
        return data.map {
            UiAttendee(it.id,
                    it.imageUrl,
                    it.name,
                    it.description,
                    it.isSponsor)
        }
    }

    override fun searchSingle(query: String?): Single<List<ContactEntity>> {
        return contactRepository.searchAttendees(query)
    }

    override fun dataObservable(): Observable<List<ContactEntity>> {
        return contactRepository.outAttendees
    }

}
