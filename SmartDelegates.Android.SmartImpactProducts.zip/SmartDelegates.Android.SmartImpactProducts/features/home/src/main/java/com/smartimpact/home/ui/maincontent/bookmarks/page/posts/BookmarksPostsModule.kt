package com.smartimpact.home.ui.maincontent.bookmarks.page.posts

import dagger.Binds
import dagger.Module

@Module
internal interface BookmarksPostsModule {

    @Binds
    fun bindView(fragment: BookmarksPostsFragment): BookmarksPostsView

    @Binds
    fun bindPresenter(presenterImpl: BookmarksPostsPresenterImpl): BookmarksPostsPresenter

}
