package com.smartimpact.home.ui.conferences

import com.smartimpact.home.ui.conferences.model.UiConference

internal interface ConferencesPresenter {

    fun onActivityCreated()
    fun onDestroyView()
    fun onConferenceClicked(conference: UiConference)
    fun onRetryClicked()

}
