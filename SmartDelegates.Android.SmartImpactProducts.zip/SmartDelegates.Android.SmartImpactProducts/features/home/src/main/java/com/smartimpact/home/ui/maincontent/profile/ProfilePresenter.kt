package com.smartimpact.home.ui.maincontent.profile

internal interface ProfilePresenter {

    fun onCreate(profileId: String, isSponsor: Boolean)
    fun onViewCreated()
    fun onDestroyView()

    fun onToggleBookmarkClicked()
    fun onChatProfileClicked()
    fun onEditProfileClicked()

    fun onEmailClicked(email: String)
    fun onWebsiteClicked(website: String)
    fun onTwitterClicked(twitter: String)
    fun onLinkedInClicked(linkedIn: String)
    fun onFacebookClicked(facebook: String)
    fun onDestroy()

}
