package com.smartimpact.home.ui.maincontent.maps

import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import javax.inject.Inject

internal class MapsPresenterImpl @Inject constructor(private val view: MapsView,
        private val parentPresenter: MainContentPresenter) : MapsPresenter