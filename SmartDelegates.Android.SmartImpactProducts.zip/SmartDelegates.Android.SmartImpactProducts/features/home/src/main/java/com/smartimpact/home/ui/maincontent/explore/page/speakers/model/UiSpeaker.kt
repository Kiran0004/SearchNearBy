package com.smartimpact.home.ui.maincontent.explore.page.speakers.model

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

data class UiSpeaker(
        override val id: String,
        override val imageUrl: String?,
        override val nameText: String?,
        override val bioText: String?,
        override val isSponsor: Boolean?
) : BaseUiPeopleListPerson()
