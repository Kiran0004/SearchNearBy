package com.smartimpact.home.ui.maincontent.settings

import com.smartimpact.base.manager.logout.LogoutManager
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class SettingsPresenterImpl @Inject constructor(
        private val view: SettingsView,
        private val parentPresenter: MainContentPresenter,
        private val logoutManager: LogoutManager) : SettingsPresenter {

    private var disposable: Disposable? = null

    override fun onLogoutClicked() {
        disposable?.dispose()
        disposable = logoutManager.logout()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onComplete = {
                            parentPresenter.openOnboardingView()
                        }
                )

    }

    override fun onDestroyView() {
        disposable?.dispose()
    }
}