package com.smartimpact.home.eventmanager

interface EventManager {

    fun refresh()
    fun dispose()

}
