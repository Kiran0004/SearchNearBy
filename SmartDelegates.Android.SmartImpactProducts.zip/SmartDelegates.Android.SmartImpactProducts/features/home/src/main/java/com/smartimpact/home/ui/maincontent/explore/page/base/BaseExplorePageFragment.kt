package com.smartimpact.home.ui.maincontent.explore.page.base

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapter
import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapterListener
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.home.R
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_explore_tab.*
import javax.inject.Inject

internal abstract class BaseExplorePageFragment : DaggerFragment(), BaseExplorePageView, PeopleListAdapterListener {

    @Inject
    internal lateinit var socialIntentManager: SocialIntentManager

    @Inject
    internal lateinit var basePresenter: BaseExplorePagePresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    @Inject
    internal lateinit var analyticsManager: AnalyticsManager

    private lateinit var peopleListAdapter: PeopleListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        peopleListAdapter = PeopleListAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_explore_tab, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        exploreRecycler.adapter = peopleListAdapter

        basePresenter.onViewCreated()
    }

    override fun onDestroyView() {
        basePresenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onAdClicked(adUrl: String) {
        if(adUrl.contains("https")) {
            startActivity(socialIntentManager.getWebsiteIntent(adUrl))
        }else
            startActivity(socialIntentManager.getWebsiteIntent("https://".plus(adUrl)))
    }

    fun reloadPage() {
        basePresenter.reloadPage()
    }

    fun searchFor(query: String?) {
        basePresenter.searchFor(query)
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>) {
        peopleListAdapter.setData(list)
    }

    override fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult) {
        peopleListAdapter.setData(list, diffResult)
    }

    override fun showContent(show: Boolean) {
        exploreRecycler.isVisible = show
        tvNoContent.isVisible = !show
    }

}
