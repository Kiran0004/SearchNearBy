package com.smartimpact.home.ui.maincontent.chat

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.chat.list.MessagesAdapter
import com.smartimpact.home.ui.maincontent.chat.list.MessagesDecoration
import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel
import kotlinx.android.synthetic.main.fragment_chat.*
import javax.inject.Inject

internal class ChatFragment : BaseToolbarFragment(), ChatView {

    private lateinit var messagesAdapter: MessagesAdapter

    @Inject
    internal lateinit var presenter: ChatPresenter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        messagesAdapter = MessagesAdapter(requireContext())
        messagesRecycler.adapter = messagesAdapter

        val messagesDecoration = MessagesDecoration(requireContext())
        messagesRecycler.addItemDecoration(messagesDecoration)

        btnSend.setOnClickListener {
            val newMessage = etNewMessage.text.toString()
            presenter.onSendClicked(newMessage)
        }

        val contactId = arguments?.getString(ARG_CONTACT_ID)
                ?: throw IllegalStateException("Contact id cannot be null if chat id is null!")
        presenter.onViewCreatedContact(contactId)
    }

    override fun enableSend(enabled: Boolean) {
        btnSend.isEnabled = enabled
        etNewMessage.isEnabled = enabled
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun toolbar(): MaterialToolbar {
        return toolbar
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_chat
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun updateToolBarTitle(toolBarTitle: String) {
        super.setToolBarTitle(toolBarTitle)
    }

    override fun setData(messages: List<BaseUiMessageModel>, diffResult: DiffUtil.DiffResult) {
        messagesAdapter.setData(messages, diffResult)
    }

    override fun setData(messages: List<BaseUiMessageModel>) {
        messagesAdapter.setData(messages)
    }

    override fun clearNewMessageInput() {
        etNewMessage.text?.clear()
    }

    override fun scrollToLatestMessage(shouldScrollBeSmooth: Boolean) {
        val position = messagesAdapter.itemCount - 1
        if (position != RecyclerView.NO_POSITION) {
            if (shouldScrollBeSmooth) {
                messagesRecycler.smoothScrollToPosition(position)
            } else {
                messagesRecycler.scrollToPosition(position)
            }
        }
    }

    override fun showSendLoading(show: Boolean) {
        sendingLoading.isVisible = show
    }

    override fun onKeyboardShownChanged(shown: Boolean, keyboardHeight: Int) {
        val position = messagesAdapter.itemCount - 1
        if (position != RecyclerView.NO_POSITION) {
            messagesRecycler.scrollToPosition(position)
        }
    }

    companion object {
        private const val ARG_CONTACT_ID = "com.smartimpact.home.ui.maincontent.chat.ChatFragment.contactId"

        fun newInstanceContact(contactId: String): ChatFragment {
            return ChatFragment().apply {
                arguments = bundleOf(ARG_CONTACT_ID to contactId)
            }
        }
    }

}
