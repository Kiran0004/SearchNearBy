package com.smartimpact.home.ui.maincontent.home.sessions.model

import com.smartimpact.home.session.model.UiSessionFull

internal data class UiHomeSessionFull(
        val sessionFull: UiSessionFull
) : BaseUiHomeSessionModel
