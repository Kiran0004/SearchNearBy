package com.smartimpact.home.session.itemlayout

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.card.MaterialCardView
import com.smartimpact.home.R
import com.smartimpact.home.session.model.UiSessionSimple
import kotlinx.android.synthetic.main.item_session_simple.view.*

internal class SessionSimpleItemLayout(context: Context, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiSessionSimple

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onSessionClicked(data)
        }
    }

    fun inject(listener: Listener) {
        this.listener = listener
    }

    fun setData(session: UiSessionSimple) {
        this.data = session

        tvSessionTitle.text = data.sessionTitle
        tvSessionDescription.text = if (data.sessionLocation.isNullOrBlank()) {
            data.sessionTime
        } else {
            context.getString(R.string.session_time_and_location,
                    data.sessionTime,
                    data.sessionLocation)
        }

        if (session.sessionPassed) {
            clContent.alpha = SessionBase.PASSED_SESSION_ALPHA
        }
    }

    interface Listener {
        fun onSessionClicked(session: UiSessionSimple)
    }

}
