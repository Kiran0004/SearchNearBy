package com.smartimpact.home.ui.maincontent.newpost

import android.content.Intent

internal interface NewPostPresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onPostClicked(body: String?)
    fun onAddPhotoClicked()
    fun onPicturePicked(data: Intent?)
    fun onPostTextChanged(text: String?)
    fun onRemovePickedImage()
    fun onStoragePermissionCheckResult(granted: Boolean)
    fun onStoragePermissionGranted()
    fun onStoragePermissionNotGranted()
    fun onDestroy()

}
