package com.smartimpact.home.ui.maincontent.chat.model.shimmer

import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel

class UiMessageSentShimmer : BaseUiMessageModel