package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model

internal interface BaseUiBookmarksPostModel
