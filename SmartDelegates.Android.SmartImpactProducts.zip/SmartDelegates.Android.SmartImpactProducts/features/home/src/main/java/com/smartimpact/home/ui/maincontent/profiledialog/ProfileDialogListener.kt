package com.smartimpact.home.ui.maincontent.profiledialog

internal interface ProfileDialogListener : ProfileDialogLayout.Listener
