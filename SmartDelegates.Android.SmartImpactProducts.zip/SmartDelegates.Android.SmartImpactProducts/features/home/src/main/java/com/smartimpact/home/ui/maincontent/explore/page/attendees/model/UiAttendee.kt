package com.smartimpact.home.ui.maincontent.explore.page.attendees.model

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

data class UiAttendee(
        override val id: String,
        override val imageUrl: String?,
        override val nameText: String?,
        override val bioText: String?,
        override val isSponsor: Boolean?
) : BaseUiPeopleListPerson()
