package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap

import dagger.Binds
import dagger.Module

@Module
internal interface LocationMapModule {

    @Binds
    fun bindView(fragment: LocationMapFragment): LocationMapView

    @Binds
    fun bindPresenter(presenterImpl: LocationMapPresenterImpl): LocationMapPresenter

}