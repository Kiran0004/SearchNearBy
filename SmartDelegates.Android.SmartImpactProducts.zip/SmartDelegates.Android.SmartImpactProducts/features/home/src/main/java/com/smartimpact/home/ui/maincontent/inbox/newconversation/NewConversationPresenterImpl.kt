package com.smartimpact.home.ui.maincontent.inbox.newconversation

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.list.peoplelist.mapper.PeopleListUiMapper
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.base.ui.list.peoplelist.model.UiPeopleListAd
import com.smartimpact.base.ui.list.peoplelist.util.PeopleListUtil
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.explore.page.attendees.model.UiAttendee
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.subjects.BehaviorSubject
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class NewConversationPresenterImpl @Inject constructor(
        private val view: NewConversationView,
        private val adsRepository: AdsRepository,
        private val contactRepository: ContactRepository,
        private val parentPresenter: MainContentPresenter,
        private val errorMessageManager: ErrorMessageManager,
        private val messageManager: MessageManager

        ) : NewConversationPresenter {
    private var searchDisposable: Disposable? = null

    private val searchSubject = BehaviorSubject.create<String>()

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    adsRepository.initialize()
                    contactRepository.initialize()
                    view.reloadPage()
                }
        )

        adsRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        adsRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)

        contactRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        contactRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)


        loadData()
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()

        searchDisposable?.dispose()
        compositeDisposable.clear()

        disposable?.dispose()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onSearchViewClosed() {
        searchDisposable?.dispose()
        view.reloadPage()
    }

    override fun onSearchViewShown() {
        subscribeSearch()
    }

    override fun onSearchChanged(query: String?) {
        searchSubject.onNext(query ?: "")
    }

    override fun showErrorMessage(errorMessage: String, isSearch: Boolean) {
        if (isSearch) {
            messageManager.handlePlainMessage(errorMessage)
        } else {
            messageManager.handleActionableMessage(errorMessage)
        }
    }

    private fun subscribeSearch() {
        searchDisposable?.dispose()
        searchDisposable = searchSubject
                .debounce(SEARCH_DEBOUNCE_DELAY, TimeUnit.MILLISECONDS)
                .distinctUntilChanged()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.searchFor(it)
                        },
                        onError = {
                            messageManager.handlePlainMessage(it)
                        }
                )
    }

    override fun openChatViewForContact(contactId: String) {
        parentPresenter.openChatViewForContact(contactId)
    }

    private fun searchSingle(query: String?): Single<List<ContactEntity>> {
        return contactRepository.searchAttendees(query)
    }

    private fun dataObservable(): Observable<List<ContactEntity>> {
        return contactRepository.outAttendees
    }

    private var disposable: Disposable? = null

    private var dataLoaded: Boolean = false
    private var data: List<BaseUiPeopleListModel> = emptyList()

    private val adsObservable = adsRepository
            .outAds

    override fun reloadPage() {
        loadData()
    }

    override fun searchFor(query: String?) {
        disposable?.dispose()
        disposable = Observable
                .combineLatest(
                        adsObservable,
                        searchSingle(query).toObservable(),
                        BiFunction { ads: List<AdEntity>, contacts: List<ContactEntity> ->
                            Pair(ads, contacts)
                        }
                )
                .map {
                    val ads = it.first
                    val contacts = it.second
                    mapToUi(ads, contacts)
                }
                .map { newList ->
                    val diffResult = PeopleListUtil.computeDiffResult(data, newList)
                    Pair(newList, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            data = it.first
                            val diffResult = it.second
                            view.showPeopleList(data, diffResult)
                        },
                        onError = {
                            showErrorMessage(errorMessageManager.getErrorMessage(it), true)
                        }
                )

    }

    private fun loadData() {
        if (!dataLoaded) {
            data = PeopleListUtil.createShimmers(false)
            view.showPeopleList(data)
        }

        disposable?.dispose()
        disposable = Observable
                .combineLatest(
                        adsObservable,
                        dataObservable(),
                        BiFunction { ads: List<AdEntity>, contacts: List<ContactEntity> ->
                            Pair(ads, contacts)
                        }
                )
                .map {
                    val ads = it.first
                    val contacts = it.second
                    mapToUi(ads, contacts)
                }
                .map { newList ->
                    val diffResult = PeopleListUtil.computeDiffResult(data, newList)
                    Pair(newList, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            data = it.first
                            val diffResult = it.second

                            dataLoaded = true

                            if (data.any { item -> item !is UiPeopleListAd }) {
                                view.showContent(true)
                            } else {
                                view.showContent(false)
                            }
                            view.showPeopleList(data, diffResult)
                        },
                        onError = {
                            showErrorMessage(errorMessageManager.getErrorMessage(it), false)
                        }
                )
    }

    private fun mapToUi(adEntities: List<AdEntity>, contactEntities: List<ContactEntity>): List<BaseUiPeopleListModel> {
        val mapped = mutableListOf<BaseUiPeopleListModel>()

        if (adEntities.isNotEmpty()) {
            val mappedAd = PeopleListUiMapper.mapToUi(adEntities)
            mapped.add(mappedAd)
        }

        mapped.addAll(mapToUi(contactEntities))

        return mapped
    }

    private fun mapToUi(data: List<ContactEntity>): List<UiAttendee> {
        return data.map {
            UiAttendee(it.id,
                    it.imageUrl,
                    it.name,
                    it.description,
                    it.isSponsor)
        }
    }



    companion object {
        private const val SEARCH_DEBOUNCE_DELAY = 300L
    }

}
