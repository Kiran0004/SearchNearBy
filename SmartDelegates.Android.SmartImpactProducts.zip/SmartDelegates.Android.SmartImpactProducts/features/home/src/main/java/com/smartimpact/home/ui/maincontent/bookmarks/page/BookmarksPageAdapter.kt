package com.smartimpact.home.ui.maincontent.bookmarks.page

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.bookmarks.page.people.BookmarksPeopleFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.BookmarksPostsFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.BookmarksSessionsFragment

internal class BookmarksPageAdapter(
        private val context: Context,
        fragmentManager: FragmentManager
) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getPageTitle(position: Int): CharSequence? {
        return context.getString(
                when (getPageType(position)) {
                    PAGE_TYPE_PEOPLE -> R.string.bookmarks_tab_people
                    PAGE_TYPE_POSTS -> R.string.bookmarks_tab_posts
                    PAGE_TYPE_SESSIONS -> R.string.bookmarks_tab_sessions
                    else -> throw IllegalStateException()
                }
        )
    }

    override fun getItem(position: Int): Fragment {
        return when (getPageType(position)) {
            PAGE_TYPE_PEOPLE -> BookmarksPeopleFragment.newInstance()
            PAGE_TYPE_POSTS -> BookmarksPostsFragment.newInstance()
            PAGE_TYPE_SESSIONS -> BookmarksSessionsFragment.newInstance()
            else -> throw IllegalStateException()
        }
    }

    override fun getCount(): Int {
        return 3
    }

    private fun getPageType(position: Int): Int {
        return when (position) {
            0 -> PAGE_TYPE_SESSIONS
            1 -> PAGE_TYPE_PEOPLE
            2 -> PAGE_TYPE_POSTS
            else -> throw IllegalStateException()
        }
    }

    companion object {
        private const val PAGE_TYPE_PEOPLE = 0
        private const val PAGE_TYPE_POSTS = 1
        private const val PAGE_TYPE_SESSIONS = 2
    }

}
