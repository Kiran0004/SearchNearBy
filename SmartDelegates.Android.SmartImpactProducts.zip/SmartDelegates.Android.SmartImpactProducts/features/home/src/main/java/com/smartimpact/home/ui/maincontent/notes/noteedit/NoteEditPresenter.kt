package com.smartimpact.home.ui.maincontent.notes.noteedit

internal interface NoteEditPresenter {
    fun onViewCreated(noteId: String?)
    fun onDestroyView()
    fun onDeleteClicked()
    fun onSaveClicked(subject: String, content: String?)
    fun onSnackbarRetryClicked()
    fun onBackPressed(subject: String?, content: String?)
    fun onDiscardClicked()
}