package com.smartimpact.home.ui.maincontent.home.posts.model

import com.smartimpact.home.post.model.UiPostAd

internal data class UiHomePostAd(
        val postAd: UiPostAd
) : BaseUiHomePostModel
