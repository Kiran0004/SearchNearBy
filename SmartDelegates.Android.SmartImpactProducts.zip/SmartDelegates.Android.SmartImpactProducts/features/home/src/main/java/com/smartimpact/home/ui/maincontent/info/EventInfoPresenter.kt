package com.smartimpact.home.ui.maincontent.info

interface EventInfoPresenter {

    fun onAboutEventClicked()
    fun onContactOrganizersClicked()
    fun onHelpClicked()

}
