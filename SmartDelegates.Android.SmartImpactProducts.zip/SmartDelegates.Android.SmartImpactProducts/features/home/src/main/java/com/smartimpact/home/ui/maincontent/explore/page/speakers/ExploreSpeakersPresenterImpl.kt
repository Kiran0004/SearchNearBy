package com.smartimpact.home.ui.maincontent.explore.page.speakers

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.home.ui.maincontent.explore.ExplorePresenter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenterImpl
import com.smartimpact.home.ui.maincontent.explore.page.speakers.model.UiSpeaker
import io.reactivex.Observable
import io.reactivex.Single
import javax.inject.Inject

internal class ExploreSpeakersPresenterImpl @Inject constructor(
        private val view: ExploreSpeakersView,
        private val adsRepository: AdsRepository,
        private val contactRepository: ContactRepository,
        private val parentPresenter: ExplorePresenter,
        errorMessageManager: ErrorMessageManager
) : BaseExplorePagePresenterImpl<UiSpeaker>(view, parentPresenter, errorMessageManager, adsRepository), ExploreSpeakersPresenter {

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        parentPresenter.onPersonClicked(person.id)
    }

    override fun mapToUi(data: List<ContactEntity>): List<UiSpeaker> {
        return data.map {
            UiSpeaker(it.id,
                    it.imageUrl,
                    it.name,
                    it.description,
                    it.isSponsor)
        }
    }

    override fun searchSingle(query: String?): Single<List<ContactEntity>> {
        return contactRepository.searchSpeakers(query)
    }

    override fun dataObservable(): Observable<List<ContactEntity>> {
        return contactRepository.outSpeakers
    }

}
