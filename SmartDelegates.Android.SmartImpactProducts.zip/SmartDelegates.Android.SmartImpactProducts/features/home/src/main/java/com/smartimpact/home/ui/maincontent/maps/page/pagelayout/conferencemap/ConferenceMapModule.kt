package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap

import dagger.Binds
import dagger.Module

@Module
internal interface ConferenceMapModule {

    @Binds
    fun bindView(fragment: ConferenceMapFragment): ConferenceMapView

    @Binds
    fun bindPresenter(presenterImpl: ConferenceMapPresenterImpl): ConferenceMapPresenter

}