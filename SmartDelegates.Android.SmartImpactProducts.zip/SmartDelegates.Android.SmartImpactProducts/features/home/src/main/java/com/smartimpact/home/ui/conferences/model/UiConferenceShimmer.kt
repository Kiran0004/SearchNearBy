package com.smartimpact.home.ui.conferences.model

internal data class UiConferenceShimmer(
        val shimmerVariance: Int
) : BaseUiConferencesModel
