package com.smartimpact.home.ui.maincontent.home

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.post.entity.PostEntity
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.data.session.entity.SessionEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.post.mapper.PostUiMapper
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.session.mapper.SessionUiMapper
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.session.model.UiSessionTimeline
import com.smartimpact.home.ui.maincontent.home.posts.list.HomePostsDiffUtilCallback
import com.smartimpact.home.ui.maincontent.home.posts.model.*
import com.smartimpact.home.ui.maincontent.home.sessions.list.HomeSessionsDiffUtilCallback
import com.smartimpact.home.ui.maincontent.home.sessions.model.*
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.LocalDateTime
import org.threeten.bp.ZoneId
import org.threeten.bp.ZonedDateTime
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class HomePresenterImpl @Inject constructor(
        private val view: HomeView,
        private val parentPresenter: MainContentPresenter,
        private val adsRepository: AdsRepository,
        private val sessionRepository: SessionRepository,
        private val postRepository: PostRepository,
        private val sessionUiMapper: SessionUiMapper,
        private val postUiMapper: PostUiMapper,
        private val dateTimeFormatHelper: DateTimeFormatHelper,
        private val messageManager: MessageManager,
        private val socialIntentManager: SocialIntentManager
) : HomePresenter {

    private val compositeDisposable = CompositeDisposable()

    private var sessionData: List<BaseUiHomeSessionModel> = emptyList()
    private var postData: List<BaseUiHomePostModel> = emptyList()

    override fun onViewCreated() {
        // TODO test error handling, refresh timeline dispose, retry fetch, validate if correct messages are show etc...

        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    adsRepository.initialize()
                    sessionRepository.initialize()
                    postRepository.initialize()
                }
        )

        adsRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        adsRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)

        sessionRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        sessionRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)

        Observable
                .combineLatest(
                        sessionRepository.outSessions,
                        Observable.interval(0, TIME_LINE_REFRESH_SECONDS, TimeUnit.SECONDS),
                        BiFunction { sessions: List<SessionEntity>, _: Long ->
                            sessions
                        }
                )
                .map { mapSessionsToUi(it) }
                .doOnSubscribe {
                    showSessionsShimmer()
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val newData = it.first
                    val diffResult = it.second
                    view.showSessions(newData, diffResult)

                    // scroll to next item after timeline if previous data is shimmer
                    if (sessionData.find { oldItem -> oldItem is UiHomeSessionShimmer } != null) {
                        view.sessionScrollToPosition(newData.indexOfFirst { newItem -> newItem is UiHomeSessionTimeline } + 1)
                    }

                    sessionData = newData
                }
                .addTo(compositeDisposable)

        postRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        val topPostsAdsObservable = adsRepository
                .outAds

        Observable
                .combineLatest(
                        topPostsAdsObservable,
                        postRepository.outTopPosts,
                        BiFunction { ads: List<AdEntity>, posts: List<PostEntity> ->
                            Pair(ads, posts)
                        }
                )
                .map {
                    val ads = it.first
                    val posts = it.second

                    mapPostsToUi(ads, posts)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { showPostsShimmer() }
                .subscribeBy { topPosts ->
                    val newData = topPosts.first
                    val diffResult = topPosts.second

                    postData = newData
                    view.showPosts(newData, diffResult)
                }
                .addTo(compositeDisposable)

        postRepository.startTopPostsIntervalRefresh(
                TOP_POSTS_REFRESH_SECONDS, TOP_POSTS_REFRESH_SECONDS, TimeUnit.SECONDS
        )
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()
        postRepository.stopTopPostsIntervalRefresh()

        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onAllSessionsClicked() {
        parentPresenter.openAllSessionsView()
    }

    override fun onAllPostsClicked() {
        parentPresenter.openAllPostsView()
    }

    override fun onNewPostClicked() {
        parentPresenter.openNewPostView()
    }

    override fun onAdClicked(adUrl: String) {
        if(adUrl!=null && adUrl.contains("https"))
            view.openWebsite(socialIntentManager.getWebsiteIntent(adUrl))
        else
            view.openWebsite(socialIntentManager.getWebsiteIntent("https://"+adUrl))
    }

    override fun onPostClicked(post: UiPostImage) {
        parentPresenter.openPostDetailsView(post.postId, post.tweetUrl)
    }

    override fun onPostClicked(post: UiPostText) {
        parentPresenter.openPostDetailsView(post.postId, post.tweetUrl)
    }

    override fun onPostAuthorClicked(postAuthor: UiPostAuthor) {
        parentPresenter.openProfileDialog(postAuthor.authorId)
    }

    override fun onSessionFullClicked(sessionFull: UiSessionFull) {
        parentPresenter.openSessionDetailsView(sessionFull.sessionId)
    }

    override fun onSessionSimpleClicked(sessionSimple: UiSessionSimple) {
        parentPresenter.openSessionDetailsView(sessionSimple.sessionId)
    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        if (speakers.size == 1) {
            parentPresenter.openProfileDialog(speakers.first().speakerId)
        } else {
            parentPresenter.openSessionDetailsView(sessionId)
        }
    }

    private fun showPostsShimmer() {
        if (postData.isEmpty()) {
            val shimmer = listOf(
                    UiHomePostShimmer()
            )

            postData = shimmer
            view.showPosts(shimmer)
        }
    }

    private fun showSessionsShimmer() {
        if (sessionData.isEmpty()) {
            val shimmer = listOf(
                    UiHomeSessionShimmer(),
                    UiHomeSessionShimmer()
            )
            sessionData = shimmer
            view.showSessions(shimmer)
        }
    }

    private fun mapPostsToUi(adEntities: List<AdEntity>, postEntities: List<PostEntity>): Pair<List<BaseUiHomePostModel>, DiffUtil.DiffResult> {
        val result = if (postEntities.isEmpty()) {
            val mapped = mutableListOf<BaseUiHomePostModel>()
            if (adEntities.isNotEmpty()) {
                val mappedAd = UiHomePostAd(
                        postUiMapper.mapToUi(adEntities)
                )
                mapped.add(mappedAd)
            }

            mapped.add(UiHomePostEmpty())

            mapped
        } else {
            val mapped = mutableListOf<BaseUiHomePostModel>()

            if (adEntities.isNotEmpty()) {
                val mappedAd = UiHomePostAd(
                        postUiMapper.mapToUi(adEntities)
                )
                mapped.add(mappedAd)
            }

            val mappedPosts = postEntities.map { entity ->
                when (val uiPostModel = postUiMapper.mapToUi(entity)) {
                    is UiPostImage -> UiHomePostImage(uiPostModel)
                    is UiPostText -> UiHomePostText(uiPostModel)
                    else -> throw IllegalStateException()
                }
            }
            mapped.addAll(mappedPosts)

            mapped
        }

        val diffResult = DiffUtil.calculateDiff(HomePostsDiffUtilCallback(postData, result))
        return Pair(result, diffResult)
    }

    private fun mapSessionsToUi(sessionEntities: List<SessionEntity>): Pair<List<BaseUiHomeSessionModel>, DiffUtil.DiffResult> {
        val result = mutableListOf<BaseUiHomeSessionModel>()

        var previousDayLocal = ZonedDateTime.of(LocalDateTime.MIN, ZoneId.systemDefault())

        val currentTime = ZonedDateTime.now()

        var timelineShown = false

        var dayCount = 0
        sessionEntities
                .filter { it.going != false } // only show going == true or going == null
                .sortedBy { it.startAt }
                .forEach { sessionEntity ->
                    // adds day marker if necessary
                    val startAt = sessionEntity.startAt
                    if (previousDayLocal.toLocalDate() < startAt.toLocalDate()) {
                        val sessionDay = UiHomeSessionDay(dayCount, dateTimeFormatHelper.getDayString(startAt),
                                dateTimeFormatHelper.getDayShortString(startAt).toUpperCase(),
                                dateTimeFormatHelper.getDayNumberString(startAt))
                        dayCount++
                        result.add(sessionDay)
                        previousDayLocal = startAt
                    }

                    // Timeline
                    if (!timelineShown &&
                            currentTime < startAt) {
                        timelineShown = true
                        result.add(UiHomeSessionTimeline(UiSessionTimeline()))
                    }

                    // adds session
                    val uiHomeSession = when (val uiSession = sessionUiMapper.mapToUi(sessionEntity, currentTime)) {
                        is UiSessionFull -> UiHomeSessionFull(uiSession)
                        is UiSessionSimple -> UiHomeSessionSimple(uiSession)
                        else -> throw IllegalStateException()
                    }
                    result.add(uiHomeSession)
                }

        val diffResult = DiffUtil.calculateDiff(HomeSessionsDiffUtilCallback(sessionData, result))
        return Pair(result, diffResult)
    }

    companion object {
        private const val TIME_LINE_REFRESH_SECONDS = 30L
        private const val TOP_POSTS_REFRESH_SECONDS = 30L
    }

}
