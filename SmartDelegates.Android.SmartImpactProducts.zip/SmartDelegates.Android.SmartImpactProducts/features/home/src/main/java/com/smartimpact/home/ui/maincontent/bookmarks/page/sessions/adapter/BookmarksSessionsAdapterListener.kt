package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter

import com.smartimpact.home.session.itemlayout.SessionFullItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout

internal interface BookmarksSessionsAdapterListener :
        SessionFullItemLayout.Listener,
        SessionSimpleItemLayout.Listener
