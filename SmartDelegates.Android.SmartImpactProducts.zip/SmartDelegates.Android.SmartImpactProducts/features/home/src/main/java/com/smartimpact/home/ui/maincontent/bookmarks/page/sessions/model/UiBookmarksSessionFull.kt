package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model

import com.smartimpact.home.session.model.UiSessionFull

internal data class UiBookmarksSessionFull(
        val sessionFull: UiSessionFull
) : BaseUiBookmarksSessionsModel
