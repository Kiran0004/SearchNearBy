package com.smartimpact.home.post.mapper

import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.data.post.entity.PostEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.post.model.*
import org.threeten.bp.ZonedDateTime

internal class PostUiMapper(
        private val dateTimeFormatHelper: DateTimeFormatHelper
) {

    fun mapToUi(adEntities: List<AdEntity>): UiPostAd {
        return UiPostAd(adEntities)
    }

    fun mapToUi(entity: PostEntity): BaseUiPostModel {
        return when (entity.imageUrl.isNullOrEmpty()) {
            true -> mapToUiPostText(entity)
            false -> mapToUiPostImage(entity)
        }
    }

    fun mapAuthor(entity: ContactEntity): UiPostAuthor {
        return UiPostAuthor(
                entity.id,
                entity.name,
                entity.imageUrl
        )
    }

    private fun mapToUiPostText(entity: PostEntity): UiPostText {
        return UiPostText(
                entity.id,
                mapAuthor(entity.profileReferences),
                mapPostTime(entity.createdOn),
                entity.content,
                entity.tweetUrl,
                entity.tweetTags
        )
    }

    private fun mapToUiPostImage(entity: PostEntity): UiPostImage {
        return UiPostImage(
                entity.id,
                mapAuthor(entity.profileReferences),
                mapPostTime(entity.createdOn),
                entity.content,
                entity.imageUrl!!,
                entity.tweetUrl,
                entity.tweetTags
        )
    }

    private fun mapPostTime(createdOn: ZonedDateTime): String {
        return dateTimeFormatHelper.getTimeString(createdOn)
    }

}
