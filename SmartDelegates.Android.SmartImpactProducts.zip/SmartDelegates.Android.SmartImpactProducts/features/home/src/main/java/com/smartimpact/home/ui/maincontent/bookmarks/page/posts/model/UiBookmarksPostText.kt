package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model

import com.smartimpact.home.post.model.UiPostText

internal data class UiBookmarksPostText(
        val postText: UiPostText
) : BaseUiBookmarksPostModel
