package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model

internal class UiDaySessionsTimeline : BaseUiDaySessionsModel
