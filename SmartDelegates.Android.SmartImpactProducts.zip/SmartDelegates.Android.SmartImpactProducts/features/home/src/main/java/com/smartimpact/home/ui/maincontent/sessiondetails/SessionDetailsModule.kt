package com.smartimpact.home.ui.maincontent.sessiondetails

import dagger.Binds
import dagger.Module

@Module
internal interface SessionDetailsModule {

    @Binds fun bindView(fragment: SessionDetailsFragment): SessionDetailsView

    @Binds fun bindPresenter(presenterImpl: SessionDetailsPresenterImpl): SessionDetailsPresenter

}
