package com.smartimpact.home.post.model

internal data class UiPostAuthor(
        val authorId: String,
        val authorName: String?,
        val authorImageUrl: String?
)
