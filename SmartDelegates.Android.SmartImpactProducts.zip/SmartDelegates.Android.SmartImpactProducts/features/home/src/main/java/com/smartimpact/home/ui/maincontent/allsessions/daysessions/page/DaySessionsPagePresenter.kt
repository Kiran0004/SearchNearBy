package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page

import com.smartimpact.home.session.model.UiSessionFullResponse
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay

internal interface DaySessionsPagePresenter {
    fun onDestroyView()
    fun onViewCreated(day: UiConferenceDay)
    fun onSessionAdClicked(adUrl: String)
    fun onSessionFullResponseClicked(sessionFullResponse: UiSessionFullResponse)
    fun onSessionSimpleClicked(sessionSimple: UiSessionSimple)
    fun onSessionResponseClicked(sessionId: String, response: Int)
    fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>)

}
