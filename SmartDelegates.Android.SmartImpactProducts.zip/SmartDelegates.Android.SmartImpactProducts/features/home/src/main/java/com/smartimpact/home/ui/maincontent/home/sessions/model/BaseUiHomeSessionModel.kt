package com.smartimpact.home.ui.maincontent.home.sessions.model

internal interface BaseUiHomeSessionModel
