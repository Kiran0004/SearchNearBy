package com.smartimpact.home.ui.maincontent.explore.page.attendees

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView
import dagger.Binds
import dagger.Module

@Module
internal interface ExploreAttendeesModule {

    @Binds
    fun bindView(fragment: ExploreAttendeesFragment): ExploreAttendeesView

    @Binds
    fun bindPresenter(presenterImpl: ExploreAttendeesPresenterImpl): ExploreAttendeesPresenter

    @Binds
    fun bindBaseView(view: ExploreAttendeesView): BaseExplorePageView

    @Binds
    fun bindBasePresenter(presenter: ExploreAttendeesPresenter): BaseExplorePagePresenter

}


