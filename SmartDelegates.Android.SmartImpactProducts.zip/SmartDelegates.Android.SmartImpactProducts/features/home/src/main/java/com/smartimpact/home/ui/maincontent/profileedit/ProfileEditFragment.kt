package com.smartimpact.home.ui.maincontent.profileedit

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.widget.addTextChangedListener
import androidx.core.widget.doOnTextChanged
import com.bumptech.glide.Glide
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartimpact.base.ui.theme.getThemeColor
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.base.ui.profileedit.model.UiProfileEditDetails
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_profile_edit.*
import javax.inject.Inject






internal class ProfileEditFragment : BaseToolbarFragment(), ProfileEditView {

    @Inject internal lateinit var presenter: ProfileEditPresenter
    @Inject internal lateinit var imageLoader: ImageLoader


    private var imageUrl: String? = null

    override fun layoutRes(): Int {
        return R.layout.fragment_profile_edit
    }

    override fun titleRes(): Int? {
        return R.string.profile_edit_title
    }

    override fun menuRes(): Int? {
        return R.menu.menu_profile_edit
    }

    override fun toolbar(): MaterialToolbar {
        return profileEditToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupNameHandler()
        setupIconTintHandlers()
        setupImageHandler()
        presenter.onViewCreated(context!!)
    }

   private fun setupImageHandler(){
        ivProfilePhotoEdit.setOnClickListener{
            presenter.onAddPhotoClicked()
        }
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        presenter.onBackPressed()
    }

    override fun showProfileDetails(details: UiProfileEditDetails) {
        this.imageUrl = details.imageUrl
        val pref = context!!.getSharedPreferences("PROFILE_PIC", Context.MODE_PRIVATE)
        if(details.imageUri!=null){
            IMAGE_URI = details.imageUri!!
            val editor = pref.edit()
            editor.remove("PROFILE_PIC")
            editor.commit()

            val prefEditor = pref.edit()
            prefEditor.putString("image", IMAGE_URI.toString())
            prefEditor.commit()
        }

        if(IMAGE_URI!=null){
            try{
                ivProfilePhotoView.setImageURI(null)
                ivProfilePhotoView.setImageURI(IMAGE_URI)
            }catch (e:Exception){

                Glide.with(this)
                        .asBitmap()
                        .load(imageUrl)
                        .override(300, 300)
                        .fitCenter()
                        .placeholder(R.drawable.empty_image_placeholder)
                        .into(ivProfilePhotoView)
            }

        }else{
            Glide.with(this)
                    .asBitmap()
                    .load(imageUrl)
                    .override(300, 300)
                    .fitCenter()
                    .placeholder(R.drawable.empty_image_placeholder)
                    .into(ivProfilePhotoView)
        }
        etProfileName.setText(details.name, TextView.BufferType.EDITABLE)
        etProfileRole.setText(details.occupation, TextView.BufferType.EDITABLE)
        etProfileBio.setText(details.biography, TextView.BufferType.EDITABLE)
        etProfileTwitter.setText(details.twitter, TextView.BufferType.EDITABLE)
        etProfileFacebook.setText(details.facebook, TextView.BufferType.EDITABLE)
        etProfileLinkedIn.setText(details.linkedIn, TextView.BufferType.EDITABLE)

        etProfileName.addTextChangedListener {
            presenter.onNameChanged(it?.toString())
        }
        etProfileRole.addTextChangedListener {
            presenter.onRoleChanged(it?.toString())
        }
        etProfileBio.addTextChangedListener {
            presenter.onBioChanged(it?.toString())
        }
        etProfileTwitter.addTextChangedListener {
            presenter.onTwitterChanged(it?.toString())
        }
        etProfileFacebook.addTextChangedListener {
            presenter.onFacebookChanged(it?.toString())
        }
        etProfileLinkedIn.addTextChangedListener {
            presenter.onLinkedInChanged(it?.toString())
        }
    }

    override fun showLoading(show: Boolean) {
        editBottomGroup.isVisible = !show
        profileEditLoading.isVisible = show
    }

    override fun showErrorWithRetry(errorMessage: String) {
        super.showErrorRetrySnackbar(errorMessage)
    }

    override fun showNameInputError(show: Boolean) {
        if (show) {
            etProfileNameLayout.error = getString(R.string.profile_edit_error_name)
        } else {
            etProfileNameLayout.isErrorEnabled = false
        }
    }

    override fun showInfoMessage(messageRes: Int) {
        super.showSnackbar(messageRes)
    }

    override fun showDiscardDialog() {
        MaterialAlertDialogBuilder(context, R.style.SmartImpact_Dialog)
                .setTitle(R.string.profile_edit_dialog_title)
                .setMessage(R.string.profile_edit_dialog_message)
                .setPositiveButton(R.string.profile_edit_dialog_discard) { _, _ ->
                    presenter.onDiscardClicked()
                }
                .setNegativeButton(R.string.profile_edit_dialog_save) { _, _ ->
                    presenter.onSaveClicked()
                }
                .setNeutralButton(R.string.profile_edit_dialog_cancel, null)
                .show()
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_profile_edit_done -> {
                presenter.onEditDoneClicked()
                true
            }
            else -> super.onMenuItemClick(item)
        }
    }

    private fun setupNameHandler() {
        etProfileName.doOnTextChanged { text, _, _, _ ->
            showNameInputError(text == null || text.isBlank())
        }
    }

    private fun setupIconTintHandlers() {
        val textLayouts = mapOf(
                etProfileTwitter to etProfileTwitterLayout,
                etProfileFacebook to etProfileFacebookLayout,
                etProfileLinkedIn to etProfileLinkedInLayout
        )
        textLayouts.forEach {
            it.key.doOnTextChanged { text, _, _, _ ->
                it.value.setEndIconTintList(getIconTintList(text))
            }
        }
    }

    override fun checkStoragePermission() {
        val hasPermission = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        presenter.onStoragePermissionCheckResult(hasPermission)
    }

    override fun requestStoragePermission() {
        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSION_STORAGE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_PERMISSION_STORAGE -> {
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    presenter.onStoragePermissionNotGranted()
                } else {
                    presenter.onStoragePermissionGranted()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_PICK_IMAGE -> {
                if (resultCode == Activity.RESULT_OK) {
                    presenter.onPicturePicked(data)
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }
    override fun requestPhotoPicker(pickImageIntent: Intent?) {
        if (pickImageIntent != null) {
            startActivityForResult(pickImageIntent, REQUEST_PICK_IMAGE)
        }
    }

    override fun setPickedThumbnail(pickedImageUri: Uri?) {
        if (pickedImageUri != null) {
            ivProfilePhotoView.setImageURI(null)
            ivProfilePhotoView.setImageURI(pickedImageUri)
        } else {
            ivProfilePhotoEdit.setImageResource(R.drawable.ic_camera)
        }
    }




    private fun getIconTintList(text: CharSequence?): ColorStateList {
        return if (text == null || text.isBlank()) {
            ColorStateList.valueOf(requireContext().getThemeColor(android.R.attr.textColorHint))
        } else {
            ColorStateList.valueOf(requireContext().getThemeColor(android.R.attr.textColorPrimary))
        }
    }

    companion object {
         var IMAGE_URI:Uri? = null
        private const val REQUEST_PICK_IMAGE = 1

        private const val REQUEST_PERMISSION_STORAGE = 2

        fun newInstance(): ProfileEditFragment {
            return ProfileEditFragment()
        }
    }

}
