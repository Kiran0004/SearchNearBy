package com.smartimpact.home.ui.maincontent.profile.model

internal data class UiProfileHeader(
        val name: String,
        val occupation: String?,
        val photoUrl: String?
) : BaseUiProfileModel
