package com.smartimpact.home.ui.maincontent.sessiondetails.model

internal data class UiSessionDetailsResponse(
        val response: Int,
        val sessionPassed: Boolean
) : BaseUiSessionDetails {

    companion object {
        const val RESPONSE_NONE = 0
        const val RESPONSE_GOING = 1
        const val RESPONSE_NOT_GOING = 3
    }

}
