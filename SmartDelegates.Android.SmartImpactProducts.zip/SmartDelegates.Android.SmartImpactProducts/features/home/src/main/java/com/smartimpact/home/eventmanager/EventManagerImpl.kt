package com.smartimpact.home.eventmanager

import com.smartimpact.connectivity.ConnectivityStatusListener
import com.smartimpact.connectivity.ConnectivityStatusManager
import com.smartimpact.data.base.repository.BaseEventDataRepository

class EventManagerImpl(
        private val connectivityStatusManager: ConnectivityStatusManager,
        private val eventDataRepositories: List<BaseEventDataRepository>
) : EventManager {

    private val connectivityStatusListener = object : ConnectivityStatusListener {
        override fun onConnectivityStatusChanged(isConnected: Boolean) {
            if (isConnected) {
                refresh()
            }
        }
    }

    init {
        connectivityStatusManager.registerListener(connectivityStatusListener)
    }

    override fun refresh() {
        eventDataRepositories.forEach { repository ->
            repository.refresh()
        }
    }

    override fun dispose() {
        connectivityStatusManager.unregisterListener(connectivityStatusListener)

        eventDataRepositories.forEach { repository ->
            repository.dispose()
        }
    }

}
