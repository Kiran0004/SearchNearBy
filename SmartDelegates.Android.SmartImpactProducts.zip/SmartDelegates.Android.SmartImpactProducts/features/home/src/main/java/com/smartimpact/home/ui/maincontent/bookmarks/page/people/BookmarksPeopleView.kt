package com.smartimpact.home.ui.maincontent.bookmarks.page.people

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel

internal interface BookmarksPeopleView {

    fun showPeopleList(list: List<BaseUiPeopleListModel>)
    fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult)
    fun showNoContent(show: Boolean)

}
