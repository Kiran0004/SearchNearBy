package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.data.session.entity.SessionEntity
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.home.session.mapper.SessionUiMapper
import com.smartimpact.home.session.model.UiSessionFullResponse
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list.DaySessionsDiffUtilCallback
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model.*
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Function3
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.LocalDate
import org.threeten.bp.ZonedDateTime
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class DaySessionsPagePresenterImpl @Inject constructor(
        private val view: DaySessionsPageView,
        private val sessionRepository: SessionRepository,
        private val sessionUiMapper: SessionUiMapper,
        private val parentPresenter: MainContentPresenter,
        private val socialIntentManager: SocialIntentManager,
        adsRepository: AdsRepository
) : DaySessionsPagePresenter {

    private lateinit var day: UiConferenceDay
    private var data: List<BaseUiDaySessionsModel> = emptyList()

    private lateinit var disposable: Disposable

    private val adsObservable = adsRepository
            .outAds

    private val sessionsObservable = sessionRepository
            .outSessions
            .map { extractSessionsOfDay(it) }

    override fun onViewCreated(day: UiConferenceDay) {
        this.day = day

        val refreshTimelineObservable = Observable
                .interval(0, TIME_LINE_REFRESH_SECONDS, TimeUnit.SECONDS)

        disposable =
                Observable
                        .combineLatest(
                                adsObservable,
                                sessionsObservable,
                                refreshTimelineObservable,
                                Function3 { ads: List<AdEntity>, sessions: List<SessionEntity>, _: Long ->
                                    Pair(ads, sessions)
                                }
                        )
                        .map {
                            val ads = it.first
                            val sessions = it.second
                            mapToUi(ads, sessions)
                        }
                        .map { newData ->
                            val diffResult = DiffUtil.calculateDiff(DaySessionsDiffUtilCallback(data, newData))
                            Pair(newData, diffResult)
                        }
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeBy {
                            val newData = it.first
                            val diffResult = it.second

                            data = newData
                            view.setData(newData, diffResult)
                        }
    }

    override fun onDestroyView() {
        disposable.dispose()
    }

    override fun onSessionAdClicked(adUrl: String) {
        if(adUrl.contains("https")) {
            view.openWebsite(socialIntentManager.getWebsiteIntent(adUrl))
        }else
            view.openWebsite(socialIntentManager.getWebsiteIntent("https://".plus(adUrl)))
    }

    override fun onSessionFullResponseClicked(sessionFullResponse: UiSessionFullResponse) {
        parentPresenter.openSessionDetailsView(sessionFullResponse.sessionFull.sessionId)
    }

    override fun onSessionSimpleClicked(sessionSimple: UiSessionSimple) {
        parentPresenter.openSessionDetailsView(sessionSimple.sessionId)
    }

    override fun onSessionResponseClicked(sessionId: String, response: Int) {
        when (response) {
            UiSessionFullResponse.RESPONSE_GOING -> sessionRepository.attendSession(sessionId)
            UiSessionFullResponse.RESPONSE_NOT_GOING -> sessionRepository.notAttendSession(sessionId)
        }

    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        if (speakers.size == 1) {
            parentPresenter.openProfileDialog(speakers.first().speakerId)
        } else {
            parentPresenter.openSessionDetailsView(sessionId)
        }
    }

    private fun extractSessionsOfDay(sessions: List<SessionEntity>): List<SessionEntity> {
        return sessions
                .filter { session ->
                    session.startAt.toLocalDate() == day.date.toLocalDate()
                }
    }

    private fun mapToUi(ads: List<AdEntity>, sessionsEntities: List<SessionEntity>): List<BaseUiDaySessionsModel> {
        val result = mutableListOf<BaseUiDaySessionsModel>()

        if (ads.isNotEmpty()) {
            val mappedAd = UiDaySessionsSessionAd(sessionUiMapper.mapToUi(ads))
            result.add(mappedAd)
        }

        val shouldShowTimeLine = day.date.toLocalDate() == LocalDate.now()
        val currentTime = ZonedDateTime.now()
        var timelineShown = false

        sessionsEntities
                .forEach { sessionEntity ->

                    // Timeline
                    if (shouldShowTimeLine && !timelineShown && currentTime < sessionEntity.startAt) {
                        timelineShown = true
                        result.add(UiDaySessionsTimeline())
                    }

                    // Session
                    val uiDaySessionsSession = when (val uiSession = sessionUiMapper.mapToUiModelWith(sessionEntity, currentTime)) {
                        is UiSessionFullResponse -> UiDaySessionsSessionFullResponse(uiSession)
                        is UiSessionSimple -> UiDaySessionsSessionSimple(uiSession)
                        else -> throw IllegalStateException()
                    }
                    result.add(uiDaySessionsSession)
                }

        return result
    }

    companion object {
        private const val TIME_LINE_REFRESH_SECONDS = 30L
    }

}
