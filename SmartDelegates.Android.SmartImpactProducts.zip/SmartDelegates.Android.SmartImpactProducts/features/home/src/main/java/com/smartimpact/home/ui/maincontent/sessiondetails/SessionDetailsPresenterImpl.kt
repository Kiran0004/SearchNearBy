package com.smartimpact.home.ui.maincontent.sessiondetails

import android.content.res.Resources
import android.net.Uri
import com.smartimpact.base.manager.download.FileDownloadManager
import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.data.session.entity.SessionEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.R
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.home.ui.maincontent.sessiondetails.model.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.ZonedDateTime
import javax.inject.Inject

internal class SessionDetailsPresenterImpl @Inject constructor(
        private val view: SessionDetailsView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val sessionRepository: SessionRepository,
        private val bookmarksRepository: BookmarksRepository,
        private val dateTimeFormatHelper: DateTimeFormatHelper,
        private val downloadManager: FileDownloadManager,
        private val resources: Resources
) : SessionDetailsPresenter {

    private lateinit var sessionId: String

    private val compositeDisposable = CompositeDisposable()
    private var detailsDisposable: Disposable? = null

    private var attachmentUri: Uri? = null

    override fun onCreate(sessionId: String) {
        this.sessionId = sessionId
    }

    override fun onViewCreated() {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    bookmarksRepository.initialize()
                }
        )

        bookmarksRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outBookmarkedSessionIds
                .map { bookmarkedSessionIds ->
                    bookmarkedSessionIds.contains(sessionId)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy { isBookmarked ->
                    view.showBookmarkStatus(isBookmarked)
                }
                .addTo(compositeDisposable)

        sessionRepository
                .outSessions
                .map { extractSession(it) }
                .map { mapToUiModel(it) }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.showSessionDetails(it)
                        },
                        onError = {
                            // session with this.sessionId could not be found
                            messageManager.handlePlainMessage(it)
                            view.close()
                        }
                )
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()

        compositeDisposable.clear()
        detailsDisposable?.dispose()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onToggleBookmarkClicked() {
        bookmarksRepository.toggleSessionBookmark(sessionId)
    }

    override fun onSpeakerClicked(speakerId: String) {
        parentPresenter.openProfileDialog(speakerId)
    }

    override fun onSessionResponseClicked(response: Int) {
        when (response) {
            UiSessionDetailsResponse.RESPONSE_GOING -> sessionRepository.attendSession(sessionId)
            UiSessionDetailsResponse.RESPONSE_NOT_GOING -> sessionRepository.notAttendSession(sessionId)
        }
    }

    override fun onAttachmentClicked(attachmentUri: Uri) {
        this.attachmentUri = attachmentUri
        view.checkStoragePermission()
    }

    override fun onStoragePermissionCheckResult(granted: Boolean) {
        val uri = attachmentUri
        if (granted && uri != null) {
            val fileName = uri.lastPathSegment!!
            downloadManager.download(uri, fileName)
            messageManager.handlePlainMessage(resources.getString(R.string.session_details_downloading, fileName))
        } else {
            view.requestStoragePermission()
        }
    }

    override fun onStoragePermissionGranted() {
        onStoragePermissionCheckResult(true)
    }

    override fun onStoragePermissionNotGranted() {
        messageManager.handlePlainMessage(R.string.session_permission)
    }

    private fun extractSession(sessions: List<SessionEntity>): SessionEntity {
        return sessions
                .first { session ->
                    session.sessionId == sessionId
                }
    }

    private fun mapToUiModel(entity: SessionEntity): List<BaseUiSessionDetails> {
        val list = mutableListOf<BaseUiSessionDetails>()

        list.add(UiSessionDetailsHeader(entity.title, entity.tags))
        if (entity.sessionType == SessionEntity.SESSION_TYPE_FULL) {
            val response = when (entity.going) {
                true -> UiSessionDetailsResponse.RESPONSE_GOING
                false -> UiSessionDetailsResponse.RESPONSE_NOT_GOING
                else -> UiSessionDetailsResponse.RESPONSE_NONE
            }

            list.add(UiSessionDetailsResponse(response, entity.startAt < ZonedDateTime.now()))
        }
        list.add(UiSessionDetailsTime(dateTimeFormatHelper.getDateString(entity.startAt), dateTimeFormatHelper.getTwoTimeStrings(entity.startAt, entity.endAt)))
        val location = entity.location
        if (!location.isNullOrBlank()) {
            list.add(UiSessionDetailsLocation(location))
        }

        entity.speakerReferences?.forEach {
            list.add(UiSessionDetailsSpeaker(it.id, it.name, it.description, it.imageUrl))
        }

        if (!entity.description.isNullOrEmpty()) {
            list.add(UiSessionDetailsAbout(entity.description!!))
        }

        entity.attachmentUrls?.forEach {
            val fileUri = Uri.parse(it)
            val fileName = fileUri.lastPathSegment
            if (!fileName.isNullOrBlank()) {
                list.add(UiSessionDetailsAttachment(fileName, fileUri)) // todo get name ids ...
            }
        }

        return list
    }

}
