package com.smartimpact.home.ui.maincontent.profile.model

internal interface BaseUiProfileModel
