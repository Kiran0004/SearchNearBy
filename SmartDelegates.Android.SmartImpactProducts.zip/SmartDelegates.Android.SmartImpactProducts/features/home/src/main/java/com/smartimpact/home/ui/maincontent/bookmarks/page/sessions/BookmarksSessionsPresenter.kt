package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions

import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker

internal interface BookmarksSessionsPresenter {

    fun onViewCreated()
    fun onDestroy()
    fun onDestroyView()
    fun onResume()
    fun onPause()
    fun onSessionFullClicked(session: UiSessionFull)
    fun onSessionSimpleClicked(session: UiSessionSimple)
    fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>)

}
