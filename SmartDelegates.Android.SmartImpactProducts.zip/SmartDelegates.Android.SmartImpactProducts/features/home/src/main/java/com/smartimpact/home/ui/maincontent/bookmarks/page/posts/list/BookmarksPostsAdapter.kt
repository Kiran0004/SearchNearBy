package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.BaseUiBookmarksPostModel
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostImage
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostShimmer
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.UiBookmarksPostText
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class BookmarksPostsAdapter(
        context: Context,
        private val listener: BookmarksPostsAdapterListener,
        private val imageLoader: ImageLoader
) : BaseItemsAdapter<BaseUiBookmarksPostModel, BookmarksPostsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiBookmarksPostImage -> TYPE_POST_IMAGE
            is UiBookmarksPostShimmer -> TYPE_POST_SHIMMER
            is UiBookmarksPostText -> TYPE_POST_TEXT
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_POST_IMAGE -> R.layout.item_post_image
            TYPE_POST_SHIMMER -> R.layout.item_post_shimmer
            TYPE_POST_TEXT -> R.layout.item_post_text
            else -> throw IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_POST_IMAGE -> {
                val layout = view as PostImageItemLayout
                layout.inject(listener, imageLoader)
                PostImageVH(layout)
            }
            TYPE_POST_SHIMMER -> {
                PostShimmerVH(view)
            }
            TYPE_POST_TEXT -> {
                val layout = view as PostTextItemLayout
                layout.inject(listener, imageLoader)
                PostTextVH(layout)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiBookmarksPostModel, position: Int) {
        holder.bind(item)
    }

    fun setData(list: List<BaseUiBookmarksPostModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(list)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiBookmarksPostModel)
    }

    private class PostImageVH(
            override val containerView: PostImageItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksPostModel) {
            containerView.setData(
                    (item as UiBookmarksPostImage).postImage
            )
        }
    }

    private class PostShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksPostModel) {}
    }

    private class PostTextVH(
            override val containerView: PostTextItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksPostModel) {
            containerView.setData(
                    (item as UiBookmarksPostText).postText
            )
        }
    }

    companion object {
        private const val TYPE_POST_IMAGE = 0
        private const val TYPE_POST_SHIMMER = 1
        private const val TYPE_POST_TEXT = 2
    }

}
