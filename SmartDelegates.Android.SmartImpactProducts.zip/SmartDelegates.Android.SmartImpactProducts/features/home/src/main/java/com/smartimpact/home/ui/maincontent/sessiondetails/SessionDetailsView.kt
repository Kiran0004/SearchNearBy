package com.smartimpact.home.ui.maincontent.sessiondetails

import com.smartimpact.home.ui.maincontent.sessiondetails.model.BaseUiSessionDetails

internal interface SessionDetailsView {

    fun showBookmarkStatus(isBookmarked: Boolean)
    fun showSessionDetails(details: List<BaseUiSessionDetails>)
    fun close()
    fun checkStoragePermission()
    fun requestStoragePermission()

}
