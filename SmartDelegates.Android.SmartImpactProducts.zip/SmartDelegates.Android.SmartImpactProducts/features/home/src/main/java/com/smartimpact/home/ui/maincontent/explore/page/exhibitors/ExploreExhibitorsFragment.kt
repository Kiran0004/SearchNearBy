package com.smartimpact.home.ui.maincontent.explore.page.exhibitors

import com.smartimpact.base.ui.list.peoplelist.PeopleListAdapterListener
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageFragment
import javax.inject.Inject

internal class ExploreExhibitorsFragment : BaseExplorePageFragment(), ExploreExhibitorsView, PeopleListAdapterListener {

    @Inject
    internal lateinit var presenter: ExploreExhibitorsPresenter

    override fun onPersonClicked(person: BaseUiPeopleListPerson) {
        presenter.onExhibitorClicked(person)
    }

    companion object {
        fun newInstance(): ExploreExhibitorsFragment {
            return ExploreExhibitorsFragment()
        }
    }

}
