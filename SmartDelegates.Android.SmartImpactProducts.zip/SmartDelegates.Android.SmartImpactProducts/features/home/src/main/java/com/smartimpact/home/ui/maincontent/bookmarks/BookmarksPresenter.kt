package com.smartimpact.home.ui.maincontent.bookmarks

interface BookmarksPresenter {

    fun openPostDetailsView(postId: String)
    fun openSessionDetailsView(sessionId: String)
    fun openProfileDialog(profileId: String)

}
