package com.smartimpact.home.ui.maincontent.allsessions

internal interface AllSessionsPresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onRetryClicked()

}
