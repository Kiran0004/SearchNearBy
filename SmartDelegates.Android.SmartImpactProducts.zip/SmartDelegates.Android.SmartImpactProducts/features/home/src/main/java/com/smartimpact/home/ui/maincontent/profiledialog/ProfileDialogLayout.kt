package com.smartimpact.home.ui.maincontent.profiledialog

import android.content.Context
import android.util.AttributeSet
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.isVisible
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.profiledialog.model.UiProfileDialog
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.dialog_profile.view.*

internal class ProfileDialogLayout(context: Context, attrs: AttributeSet?) : CoordinatorLayout(context, attrs) {

    private lateinit var listener: Listener

    fun inject(imageLoader: ImageLoader, listener: Listener) {
        this.listener = listener

        viAvatar.inject(imageLoader)
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        btnProfileView.setOnClickListener {
            listener.onViewProfileClicked()
        }
        ivProfileBookmark.setOnClickListener {
            listener.onBookmarkProfileClicked()
        }
        ivProfileChat.setOnClickListener {
            listener.onChatProfileClicked()
        }
    }

    fun showBookmarkButton(show:Boolean){
        ivProfileBookmark.isVisible = show
    }

    fun showChatButton(show:Boolean){
        ivProfileChat.isVisible = show
    }

    fun showShimmer(shouldShow: Boolean){
        profileDialogShimmer.isVisible = shouldShow
    }

    fun showProfile(profile: UiProfileDialog) {
        ivProfileBookmark.setImageResource(
                when (profile.isProfileBookmarked) {
                    true -> R.drawable.ic_bookmark_filled
                    false -> R.drawable.ic_bookmark
                }
        )

        viAvatar.setData(profile.profileName, profile.profilePhotoUrl)
        tvProfileName.text = profile.profileName
        tvProfileDescription.text = profile.profileDescription
    }

    interface Listener {
        fun onViewProfileClicked()
        fun onBookmarkProfileClicked()
        fun onChatProfileClicked()
    }

}
