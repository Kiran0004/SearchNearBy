package com.smartimpact.home.ui.maincontent.explore.page.attendees

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView


internal interface ExploreAttendeesView : BaseExplorePageView {
}
