package com.smartimpact.home.ui.maincontent.allposts

import dagger.Binds
import dagger.Module

@Module
internal interface AllPostsModule {

    @Binds fun bindView(fragment: AllPostsFragment): AllPostsView

    @Binds fun bindPresenter(presenterImpl: AllPostsPresenterImpl): AllPostsPresenter

}
