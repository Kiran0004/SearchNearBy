package com.smartimpact.home.ui.maincontent.allposts.list.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.smartimpact.home.ui.maincontent.allposts.model.UiAllPostsTime

internal class AllPostsTimeItemLayout(context: Context?, attrs: AttributeSet?) : AppCompatTextView(context, attrs) {

    fun setData(data: UiAllPostsTime) {
        text = data.timeText
    }

}
