package com.smartimpact.home.ui.maincontent.explore

import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.subjects.BehaviorSubject
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class ExplorePresenterImpl @Inject constructor(
        private val view: ExploreView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val adsRepository: AdsRepository,
        private val contactRepository: ContactRepository
) : ExplorePresenter {

    private var searchDisposable: Disposable? = null

    private val searchSubject = BehaviorSubject.create<String>()

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    adsRepository.initialize()
                    contactRepository.initialize()
                    view.reloadCurrentPage()
                }
        )

        adsRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        adsRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)

        contactRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        contactRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()

        searchDisposable?.dispose()
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onSearchViewClosed() {
        view.showTabLayout(true)
        view.lockViewPagerSwipe(false)
        searchDisposable?.dispose()
        view.reloadCurrentPage()
    }

    override fun onSearchViewShown() {
        view.showTabLayout(false)
        view.lockViewPagerSwipe(true)
        subscribeSearch()
    }

    override fun onSearchChanged(query: String?) {
        searchSubject.onNext(query ?: "")
    }

    override fun onPersonClicked(id: String, showDialog: Boolean, isSponsor : Boolean) {
        if (showDialog) {
            parentPresenter.openProfileDialog(id)
        } else {
            parentPresenter.openProfileView(id, isSponsor)
        }
    }

    override fun showErrorMessage(errorMessage: String, isSearch: Boolean) {
        if (isSearch) {
            messageManager.handlePlainMessage(errorMessage)
        } else {
            messageManager.handleActionableMessage(errorMessage)
        }
    }

    private fun subscribeSearch() {
        searchDisposable?.dispose()
        searchDisposable = searchSubject
                .debounce(SEARCH_DEBOUNCE_DELAY, TimeUnit.MILLISECONDS)
                .distinctUntilChanged()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.searchCurrentPage(it)
                        },
                        onError = {
                            messageManager.handlePlainMessage(it)
                        }
                )
    }

    override fun openChatViewForContact(contactId: String) {
       parentPresenter.openChatViewForContact(contactId)
    }

    companion object {
        private const val SEARCH_DEBOUNCE_DELAY = 300L
    }

}
