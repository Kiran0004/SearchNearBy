package com.smartimpact.home.ui.maincontent.home.sessions.list

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.base.ui.theme.getThemeColor
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.home.sessions.model.UiHomeSessionDay
import kotlin.math.roundToInt

internal class HomeSessionsItemDecoration(context: Context) : RecyclerView.ItemDecoration() {

    private val font = ResourcesCompat.getFont(context, R.font.rubik_medium)!!
    private val textColor = context.getThemeColor(android.R.attr.textColorSecondary)
    private val textSizeSmall = context.resources.getDimensionPixelSize(R.dimen.home_session_day_text_size).toFloat()
    private val textSizeLarge = context.resources.getDimensionPixelSize(R.dimen.home_session_day_number_size).toFloat()
    private val textMarginTop = context.resources.getDimensionPixelOffset(R.dimen.home_session_day_text_margin_top).toFloat()

    private val paintSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = font
        color = textColor
        textSize = textSizeSmall
    }

    private val paintLarge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = font
        color = textColor
        textSize = textSizeLarge
    }

    private val fadeMargin = paintSmall.textSize + paintLarge.textSize + textMarginTop
    private val availableWidth = context.resources.getDimensionPixelSize(R.dimen.home_session_margin_start)

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        if (itemPosition == RecyclerView.NO_POSITION) {
            return
        }

        val adapter = parent.adapter ?: return
        if (adapter.itemCount == 0) {
            return
        }

        when (adapter.getItemViewType(itemPosition)) {
            HomeSessionsAdapter.TYPE_SESSION_AD,
            HomeSessionsAdapter.TYPE_SESSION_FULL,
            HomeSessionsAdapter.TYPE_SESSION_SIMPLE,
            HomeSessionsAdapter.TYPE_SESSION_SHIMMER -> {
                outRect.top = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_margin_top)
                outRect.bottom = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_margin_bottom)
                outRect.left = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_margin_start)
                outRect.right = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_margin_end)
            }
            HomeSessionsAdapter.TYPE_SESSION_DAY -> {
                if (itemPosition != 0) {
                    outRect.top = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_day_margin_top)
                }
                outRect.bottom = parent.context.resources.getDimensionPixelSize(R.dimen.home_session_day_margin_bottom)
            }
        }
    }

    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val manager = parent.layoutManager as? LinearLayoutManager ?: return
        val adapter = parent.adapter as? HomeSessionsAdapter ?: return
        val first = manager.findFirstVisibleItemPosition()
        val last = manager.findLastVisibleItemPosition()
        if (first < 0 || last < 0) return
        val itemTypes = IntRange(first, last).map {
            adapter.getItemViewType(it)
        }

        // First, find where the day breaks are! Indicators should be shown between the day breaks.
        val dayIndexes = itemTypes.mapIndexedNotNull { index: Int, type: Int ->
            if (type == HomeSessionsAdapter.TYPE_SESSION_DAY) {
                index
            } else {
                null
            }
        }

        // If a day break is not the first view, the indicator should be in the top corner
        if (dayIndexes.firstOrNull() != 0) {
            val dayModel = adapter.getDayForPosition(first) ?: return
            // If a day break is the second view, we should fade the indicator out.
            if (dayIndexes.firstOrNull() == 1) {
                val viewBeforeDay = manager.findViewByPosition(first) ?: return
                val bottom = viewBeforeDay.bottom
                val alpha = ((bottom / fadeMargin - 1) * 255).roundToInt().coerceIn(0, 255)
                drawIndicator(c, dayModel, textMarginTop, alpha)
            } else {
                drawIndicator(c, dayModel, textMarginTop)
            }
        }

        // The day indicator is shown after the day breaks!
        dayIndexes.forEach {
            val nextIndex = it + 1
            val viewAfterDay = manager.findViewByPosition(first + nextIndex)
            if (viewAfterDay != null) {
                val dayModel = adapter.getDayForPosition(first + it) ?: return
                drawIndicator(c, dayModel, viewAfterDay.y)
            }
        }

        super.onDrawOver(c, parent, state)
    }

    private fun drawIndicator(canvas: Canvas, model: UiHomeSessionDay, offsetY: Float = 0f, alpha: Int = 255) {
        paintSmall.alpha = alpha
        val xDay = getStartX(model.shortDayName, paintSmall)
        val yDay = paintSmall.textSize + offsetY
        canvas.drawText(model.shortDayName, xDay, yDay, paintSmall)
        paintLarge.alpha = alpha
        val xNumber = getStartX(model.dayNumber, paintLarge)
        val yNumber = yDay + paintLarge.textSize
        canvas.drawText(model.dayNumber, xNumber, yNumber, paintLarge)
    }

    private fun getStartX(text: String, paint: Paint): Float {
        val width = paint.measureText(text)
        return (availableWidth - width) / 2
    }
}
