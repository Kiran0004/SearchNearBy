package com.smartimpact.home.ui.conferences

import android.os.Bundle
import android.view.View
import android.webkit.WebViewClient
import androidx.core.view.isVisible
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseFragment
import com.smartimpact.home.ui.conferences.list.ConferenceAdapterListener
import com.smartimpact.home.ui.conferences.list.ConferencesAdapter
import com.smartimpact.home.ui.conferences.model.BaseUiConferencesModel
import com.smartimpact.home.ui.conferences.model.UiConference
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_conferences.*
import javax.inject.Inject

internal class ConferencesFragment : BaseFragment(), ConferencesView, ConferenceAdapterListener {

    private lateinit var adapter: ConferencesAdapter

    @Inject
    internal lateinit var presenter: ConferencesPresenter

    @Inject internal  lateinit var mainPresenter: MainContentPresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    override fun layoutRes(): Int {
        return R.layout.fragment_conferences
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        presenter.onActivityCreated()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ConferencesAdapter(requireContext(), this, imageLoader)
        recycler.adapter = adapter

        btnRetry.setOnClickListener {
            presenter.onRetryClicked()
        }


    }

    override fun onBackPressed() {
        mainPresenter.backToAppChoiceView()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun setConferencesListItems(items: List<BaseUiConferencesModel>) {
         var isLoading: Boolean = false

        isLoading = items.find{it is UiConference && it.id.isNotEmpty()}!=null
       // if(!isLoading){
            btnHome.visibility = View.VISIBLE
            btnHome.setOnClickListener(View.OnClickListener {
            //    mainPresenter.backToAppChoiceView()
                lavada.settings.javaScriptEnabled = true
                lavada.loadUrl("https://asclauth.b2clogin.com/asclauth.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1_PasswordReset&client_id=44acfc65-ec2d-4747-863d-e3f2a8593c73&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fgetpostman.com%2Fpostman&scope=openid&response_type=id_token&prompt=login")
                lavada.settings.javaScriptEnabled = true
                lavada.settings.setSupportZoom(true)
                lavada.webViewClient = WebViewClient()
            })
//        }else{
//           btnHome.visibility = View.GONE
//        }
        adapter.setData(items)
    }

    override fun showErrorMessage(isVisible: Boolean, errorMessage: String?) {
        recycler.isVisible = !isVisible
        scrollViewError.isVisible = isVisible
        tvErrorDescription.text = errorMessage
        if(btnRetry.isVisible){
            btnHome.visibility = View.GONE
            btnHomeNew.visibility = View.VISIBLE
            btnHomeNew.setOnClickListener(View.OnClickListener {
                mainPresenter.backToAppChoiceView()

            })
        }
    }

    override fun onConferenceClicked(conference: UiConference) {
        presenter.onConferenceClicked(conference)
    }

    companion object {
        fun newInstance(): ConferencesFragment {
            return ConferencesFragment()
        }
    }
}
