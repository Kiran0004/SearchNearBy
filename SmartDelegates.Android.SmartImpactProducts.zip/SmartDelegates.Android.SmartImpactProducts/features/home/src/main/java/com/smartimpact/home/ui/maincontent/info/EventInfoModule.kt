package com.smartimpact.home.ui.maincontent.info

import dagger.Binds
import dagger.Module

@Module
internal interface EventInfoModule {

    @Binds
    fun bindView(fragment: EventInfoFragment): EventInfoView

    @Binds
    fun bindPresenter(presenterImpl: EventInfoPresenterImpl): EventInfoPresenter

}
