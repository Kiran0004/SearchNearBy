package com.smartimpact.home.ui.maincontent.profileedit

import android.content.Intent
import android.net.Uri
import androidx.annotation.StringRes
import com.smartimpact.base.ui.profileedit.model.UiProfileEditDetails

interface ProfileEditView {

    fun showProfileDetails(details: UiProfileEditDetails)
    fun showLoading(show: Boolean)

    fun showErrorWithRetry(errorMessage: String)
    fun showNameInputError(show: Boolean)

    fun showInfoMessage(@StringRes messageRes: Int)

    fun showDiscardDialog()
    fun close()

    fun checkStoragePermission()
    fun requestStoragePermission()


    fun requestPhotoPicker(pickImageIntent: Intent?)
    fun setPickedThumbnail(pickedImageUri: Uri?)

}
