package com.smartimpact.home.ui.maincontent.explore.page.speakers

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView


internal interface ExploreSpeakersView : BaseExplorePageView {

}
