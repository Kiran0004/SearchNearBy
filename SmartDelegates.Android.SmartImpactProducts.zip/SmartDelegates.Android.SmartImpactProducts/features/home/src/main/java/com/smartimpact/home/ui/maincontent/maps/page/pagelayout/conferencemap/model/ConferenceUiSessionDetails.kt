package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.model

internal interface ConferenceUiSessionDetails
