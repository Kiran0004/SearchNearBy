package com.smartimpact.home.ui.maincontent.maps

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.ConferenceMapFragment
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.ConferenceMapModule
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap.LocationMapFragment
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap.LocationMapModule
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal interface MapsModule {

    @Binds
    fun bindView(fragment: MapsFragment): MapsView

    @Binds
    fun bindPresenter(presenterImpl: MapsPresenterImpl): MapsPresenter

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [ConferenceMapModule::class])
    fun contributeConferenceMapFragmentInjector(): ConferenceMapFragment

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [LocationMapModule::class])
    fun contributeLocationMapFragmentInjector(): LocationMapFragment

}