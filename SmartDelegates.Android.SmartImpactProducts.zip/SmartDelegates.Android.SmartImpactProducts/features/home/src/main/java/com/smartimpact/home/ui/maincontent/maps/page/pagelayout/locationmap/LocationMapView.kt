package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap

import com.google.android.gms.maps.model.LatLng

internal interface LocationMapView {

    fun showMarker(location: LatLng)

}
