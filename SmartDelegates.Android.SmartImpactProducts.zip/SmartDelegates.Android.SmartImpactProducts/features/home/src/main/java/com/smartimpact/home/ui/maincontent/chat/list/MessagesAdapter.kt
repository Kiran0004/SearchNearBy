package com.smartimpact.home.ui.maincontent.chat.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.chat.list.listitem.MessageReceivedItemLayout
import com.smartimpact.home.ui.maincontent.chat.list.listitem.MessageSentItemLayout
import com.smartimpact.home.ui.maincontent.chat.list.listitem.MessageTimeItemLayout
import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageReceived
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageSent
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageTime
import com.smartimpact.home.ui.maincontent.chat.model.shimmer.UiMessageRecivedShimmer
import com.smartimpact.home.ui.maincontent.chat.model.shimmer.UiMessageSentShimmer
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class MessagesAdapter(
        context: Context
) : BaseItemsAdapter<BaseUiMessageModel, MessagesAdapter.BaseVH>(context) {

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_MESSAGE_RECEIVED -> {
                val layout = view as MessageReceivedItemLayout
                MessageReceivedVH(layout)
            }
            TYPE_MESSAGE_SENT -> {
                val layout = view as MessageSentItemLayout
                MessageSentVH(layout)
            }
            TYPE_MESSAGE_TIME -> {
                val layout = view as MessageTimeItemLayout
                MessageTimeVH(layout)
            }
            TYPE_MESSAGE_RECEIVED_SHIMMER,
            TYPE_MESSAGE_SENT_SHIMMER -> {
                NoBindingVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_MESSAGE_RECEIVED -> R.layout.item_chat_message_received
            TYPE_MESSAGE_SENT -> R.layout.item_chat_message_sent
            TYPE_MESSAGE_TIME -> R.layout.item_chat_message_time
            TYPE_MESSAGE_RECEIVED_SHIMMER -> R.layout.item_chat_message_received_shimmer
            TYPE_MESSAGE_SENT_SHIMMER -> R.layout.item_chat_message_sent_shimmer
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiMessageModel, position: Int) {
        holder.bind(item)
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiMessageReceived -> TYPE_MESSAGE_RECEIVED
            is UiMessageSent -> TYPE_MESSAGE_SENT
            is UiMessageTime -> TYPE_MESSAGE_TIME
            is UiMessageRecivedShimmer -> TYPE_MESSAGE_RECEIVED_SHIMMER
            is UiMessageSentShimmer -> TYPE_MESSAGE_SENT_SHIMMER
            else -> throw IllegalStateException()
        }
    }

    fun setData(list: List<BaseUiMessageModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(list)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiMessageModel)
    }

    private class MessageReceivedVH(
            override val containerView: MessageReceivedItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiMessageModel) {
            containerView.bind(item as UiMessageReceived)
        }
    }

    private class MessageSentVH(
            override val containerView: MessageSentItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiMessageModel) {
            containerView.bind(item as UiMessageSent)
        }
    }

    private class MessageTimeVH(
            override val containerView: MessageTimeItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiMessageModel) {
            containerView.bind(item as UiMessageTime)
        }
    }

    private class NoBindingVH(override val containerView: View) : BaseVH(containerView) {
        override fun bind(item: BaseUiMessageModel) {}
    }

    companion object {
        const val TYPE_MESSAGE_RECEIVED = 0
        const val TYPE_MESSAGE_SENT = 1
        const val TYPE_MESSAGE_TIME = 2
        const val TYPE_MESSAGE_RECEIVED_SHIMMER = 4
        const val TYPE_MESSAGE_SENT_SHIMMER = 5
    }

}
