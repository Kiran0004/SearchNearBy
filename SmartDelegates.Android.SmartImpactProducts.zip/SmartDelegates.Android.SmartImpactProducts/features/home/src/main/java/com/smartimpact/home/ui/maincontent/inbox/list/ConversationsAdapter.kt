package com.smartimpact.home.ui.maincontent.inbox.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.inbox.list.listitem.ConversationItemLayout
import com.smartimpact.home.ui.maincontent.inbox.model.BaseUiConversationModel
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversationShimmer
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class ConversationsAdapter(
        context: Context,
        private val listener: ConversationsAdapterListener,
        private val imageLoader: ImageLoader
) : BaseItemsAdapter<BaseUiConversationModel, ConversationsAdapter.BaseVH>(context) {

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_CONVERSATION -> {
                val layout = view as ConversationItemLayout
                layout.inject(listener, imageLoader)
                ConversationVH(layout)
            }
            TYPE_CONVERSATION_SHIMMER_0, TYPE_CONVERSATION_SHIMMER_1 -> {
                NonBindingVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_CONVERSATION -> R.layout.item_inbox_conversation
            TYPE_CONVERSATION_SHIMMER_0 -> R.layout.item_inbox_conversation_shimmer_0
            TYPE_CONVERSATION_SHIMMER_1 -> R.layout.item_inbox_conversation_shimmer_1
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiConversationModel, position: Int) {
        holder.bind(item)
    }

    override fun getItemViewType(position: Int): Int {
        return when (val item = getItem(position)) {
            is UiConversation -> TYPE_CONVERSATION
            is UiConversationShimmer -> determineShimmerType(item)
            else -> throw IllegalStateException()
        }
    }

    fun setData(list: List<BaseUiConversationModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(list)
    }


    private fun determineShimmerType(uiShimmer: UiConversationShimmer): Int {
        return when (uiShimmer.shimmerVariance % 2) {
            0 -> TYPE_CONVERSATION_SHIMMER_0
            1 -> TYPE_CONVERSATION_SHIMMER_1
            else -> throw IllegalStateException()
        }
    }

    abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiConversationModel)
    }

    private class ConversationVH(
            override val containerView: ConversationItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiConversationModel) {
            containerView.bind(item as UiConversation)
        }
    }

    private class NonBindingVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiConversationModel) {}
    }

    companion object {
        private const val TYPE_CONVERSATION = 0
        private const val TYPE_CONVERSATION_SHIMMER_0 = 1
        private const val TYPE_CONVERSATION_SHIMMER_1 = 2
    }

}
