package com.smartimpact.home.ui.maincontent.allsessions

import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay

internal interface AllSessionsView {

    fun showDays(data: List<UiConferenceDay>)
    fun showErrorWithRetry(message: String)
    fun close()

}
