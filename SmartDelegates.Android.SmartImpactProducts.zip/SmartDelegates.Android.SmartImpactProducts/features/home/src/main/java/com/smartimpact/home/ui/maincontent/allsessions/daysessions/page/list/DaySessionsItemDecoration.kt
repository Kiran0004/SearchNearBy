package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list

import android.graphics.Rect
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class DaySessionsItemDecoration : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        val adapter = parent.adapter!!

        val thisItemType = when (adapter.getItemViewType(itemPosition)) {
            DaySessionsAdapter.TYPE_TIMELINE ->
                TYPE_TIMELINE
            DaySessionsAdapter.TYPE_SESSION_AD,
            DaySessionsAdapter.TYPE_SESSION_FULL_RESPONSE,
            DaySessionsAdapter.TYPE_SESSION_SIMPLE ->
                TYPE_SESSION
            else -> throw IllegalStateException()
        }

        val topItemType = when {
            itemPosition == 0 ->
                TYPE_EDGE
            adapter.getItemViewType(itemPosition - 1) == DaySessionsAdapter.TYPE_TIMELINE ->
                TYPE_TIMELINE
            else ->
                TYPE_SESSION
        }

        val bottomItemType = when {
            itemPosition == adapter.itemCount - 1 ->
                TYPE_EDGE
            adapter.getItemViewType(itemPosition + 1) == DaySessionsAdapter.TYPE_TIMELINE ->
                TYPE_TIMELINE
            else ->
                TYPE_SESSION
        }

        val top: Int
        val bottom: Int
        val left: Int
        val right: Int

        when (thisItemType) {
            TYPE_TIMELINE -> {
                left = R.dimen.all_sessions_timeline_to_left_margin
                right = R.dimen.all_sessions_timeline_to_right_margin
                top = when (topItemType) {
                    TYPE_EDGE -> R.dimen.all_sessions_timeline_to_top_margin
                    TYPE_SESSION -> R.dimen.all_sessions_timeline_to_session_margin
                    else -> throw IllegalStateException()
                }
                bottom = when (bottomItemType) {
                    TYPE_EDGE -> R.dimen.all_sessions_timeline_to_bottom_margin
                    TYPE_SESSION -> R.dimen.all_sessions_timeline_to_session_margin
                    else -> throw IllegalStateException()
                }
            }
            TYPE_SESSION -> {
                left = R.dimen.all_sessions_session_to_left_margin
                right = R.dimen.all_sessions_session_to_right_margin
                top = when (topItemType) {
                    TYPE_EDGE -> R.dimen.all_sessions_session_to_top_margin
                    TYPE_TIMELINE -> R.dimen.all_sessions_session_to_timeline_margin
                    TYPE_SESSION -> R.dimen.all_sessions_session_to_session_margin
                    else -> throw IllegalStateException()
                }
                bottom = when (bottomItemType) {
                    TYPE_EDGE -> R.dimen.all_sessions_session_to_bottom_margin
                    TYPE_TIMELINE -> R.dimen.all_sessions_session_to_timeline_margin
                    TYPE_SESSION -> R.dimen.all_sessions_session_to_session_margin
                    else -> throw IllegalStateException()
                }
            }
            else -> throw IllegalStateException()
        }

        val resources = parent.context.resources

        outRect.top = resources.getDimensionPixelSize(top)
        outRect.bottom = resources.getDimensionPixelSize(bottom)
        outRect.left = resources.getDimensionPixelSize(left)
        outRect.right = resources.getDimensionPixelSize(right)
    }

    companion object {
        private const val TYPE_EDGE = 0
        private const val TYPE_SESSION = 1
        private const val TYPE_TIMELINE = 2
    }
}
