package com.smartimpact.home.ui.maincontent.info

import com.smartimpact.home.R
import com.smartimpact.userprofile.manager.ProfileManager
import javax.inject.Inject

class EventInfoPresenterImpl @Inject constructor(
        private val view: EventInfoView,
        private val profileManager: ProfileManager
) : EventInfoPresenter {

    override fun onAboutEventClicked() {
        view.openAboutEventDialog(profileManager.getEventProfileData().eventDescription)
    }

    override fun onContactOrganizersClicked() {
        view.sendEmail(R.string.event_organizator_email)
    }

    override fun onHelpClicked() {
        view.openWebSite(R.string.event_help_website)
    }

}
