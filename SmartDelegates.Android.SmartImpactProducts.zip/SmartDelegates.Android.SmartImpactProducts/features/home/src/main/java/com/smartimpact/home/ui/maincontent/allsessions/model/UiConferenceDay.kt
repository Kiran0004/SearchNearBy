package com.smartimpact.home.ui.maincontent.allsessions.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import org.threeten.bp.ZonedDateTime

// Used on the all sessions screen for tabs
@Parcelize
internal data class UiConferenceDay(val date: ZonedDateTime) : Parcelable
