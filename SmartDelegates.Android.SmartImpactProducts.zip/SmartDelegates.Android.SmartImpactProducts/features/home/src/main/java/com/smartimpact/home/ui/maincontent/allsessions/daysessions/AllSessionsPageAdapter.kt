package com.smartimpact.home.ui.maincontent.allsessions.daysessions

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.DaySessionsPageFragment

internal class AllSessionsPageAdapter(
        private val dateTimeFormatHelper: DateTimeFormatHelper,
        fragmentManager: FragmentManager
) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private var days: List<UiConferenceDay> = emptyList()

    override fun getCount(): Int {
        return days.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        val date = days[position].date
        return dateTimeFormatHelper.getDateShortString(date)
    }

    override fun getItem(position: Int): Fragment {
        return DaySessionsPageFragment.newInstance(days[position])
    }

    fun setData(data: List<UiConferenceDay>) {
        this.days = data
        notifyDataSetChanged()
    }
}
