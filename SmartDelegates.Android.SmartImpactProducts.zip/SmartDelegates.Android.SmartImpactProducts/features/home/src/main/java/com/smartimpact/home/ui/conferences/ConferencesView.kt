package com.smartimpact.home.ui.conferences

import com.smartimpact.home.ui.conferences.model.BaseUiConferencesModel

internal interface ConferencesView {

    fun setConferencesListItems(items: List<BaseUiConferencesModel>)
    fun showErrorMessage(isVisible: Boolean, errorMessage: String? = null)

}
