package com.smartimpact.home.session.itemlayout

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.card.MaterialCardView
import com.smartimpact.home.R
import com.smartimpact.home.session.model.UiSessionFullResponse
import com.smartimpact.home.session.widget.SessionFullView
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_session_full_response.view.*

internal class SessionFullResponseItemLayout(context: Context, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiSessionFullResponse

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onSessionClicked(data)
        }
        btnResponseGoing.setOnClickListener {
            listener.onSessionResponseClicked(data.sessionFull.sessionId, UiSessionFullResponse.RESPONSE_GOING)
        }
        btnResponseNotGoing.setOnClickListener {
            listener.onSessionResponseClicked(data.sessionFull.sessionId, UiSessionFullResponse.RESPONSE_NOT_GOING)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener

        viSessionFull.setListener(listener)
        viSessionFull.inject(imageLoader)
    }

    fun setData(session: UiSessionFullResponse) {
        this.data = session

        viSessionFull.setData(data.sessionFull)

        updateResponseIndication()

        if (session.sessionFull.sessionPassed) {
            tvResponseStatus.alpha = SessionBase.PASSED_SESSION_ALPHA
            btnResponseGoing.alpha = SessionBase.PASSED_SESSION_ALPHA
            btnResponseNotGoing.alpha = SessionBase.PASSED_SESSION_ALPHA

            btnResponseNotGoing.isEnabled = false
            btnResponseGoing.isEnabled = false
        }
    }

    private fun updateResponseIndication() {
        val goingTextResource: Int
        val btnGoingResource: Int
        val btnNotGoingResource: Int

        when (data.sessionResponse) {
            UiSessionFullResponse.RESPONSE_NONE -> {
                goingTextResource = R.string.session_response_none
                btnGoingResource = R.drawable.ic_session_response_going
                btnNotGoingResource = R.drawable.ic_session_response_not_going
            }
            UiSessionFullResponse.RESPONSE_GOING -> {
                goingTextResource = R.string.session_response_going
                btnGoingResource = R.drawable.ic_session_response_going_confirmed
                btnNotGoingResource = R.drawable.ic_session_response_not_going
            }
            UiSessionFullResponse.RESPONSE_NOT_GOING -> {
                goingTextResource = R.string.session_response_not_going
                btnGoingResource = R.drawable.ic_session_response_going
                btnNotGoingResource = R.drawable.ic_session_response_not_going_confirmed
            }
            else -> throw IllegalStateException()
        }

        tvResponseStatus.setText(goingTextResource)
        btnResponseGoing.setImageResource(btnGoingResource)
        btnResponseNotGoing.setImageResource(btnNotGoingResource)
    }

    interface Listener : SessionFullView.Listener {
        fun onSessionClicked(session: UiSessionFullResponse)
        fun onSessionResponseClicked(sessionId: String, response: Int)
    }

}
