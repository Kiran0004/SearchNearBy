package com.smartimpact.home.ui.maincontent.bookmarks

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.home.ui.maincontent.bookmarks.page.people.BookmarksPeopleFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.people.BookmarksPeopleModule
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.BookmarksPostsFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.BookmarksPostsModule
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.BookmarksSessionsFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.BookmarksSessionsModule
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal interface BookmarksModule {

    @Binds
    fun bindView(fragment: BookmarksFragment): BookmarksView

    @Binds
    fun bindPresenter(presenterImpl: BookmarksPresenterImpl): BookmarksPresenter

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [BookmarksPeopleModule::class])
    fun contributeBookmarksPeopleFragmentInjector(): BookmarksPeopleFragment

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [BookmarksPostsModule::class])
    fun contributeBookmarksPostsFragmentInjector(): BookmarksPostsFragment

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [BookmarksSessionsModule::class])
    fun contributeBookmarksSessionsFragmentInjector(): BookmarksSessionsFragment

}
