package com.smartimpact.home.ui.conferences.list.itemlayout

import android.content.Context
import android.util.AttributeSet
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import com.google.android.material.card.MaterialCardView
import com.smartimpact.home.R
import com.smartimpact.home.ui.conferences.model.UiConference
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_conferences_conference.view.*

internal class ConferenceItemLayout(context: Context, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var imageLoader: ImageLoader

    private lateinit var data: UiConference

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onConferenceClicked(data)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener
        this.imageLoader = imageLoader
    }

    fun bind(data: UiConference) {
        this.data = data
        ivImage.isInvisible = data.isSelected
        pbConference.isVisible = data.isSelected
        imageLoader.load(data.imageUrl, ivImage, R.drawable.empty_image_placeholder)
        tvDateLocation.text = data.dateLocationText
        tvConferenceName.text = data.conferenceNameText
    }

    interface Listener {

        fun onConferenceClicked(conference: UiConference)

    }

}
