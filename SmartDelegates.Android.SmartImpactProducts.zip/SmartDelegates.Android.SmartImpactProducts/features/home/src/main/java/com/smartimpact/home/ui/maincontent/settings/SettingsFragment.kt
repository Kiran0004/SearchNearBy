package com.smartimpact.home.ui.maincontent.settings

import android.os.Bundle
import android.view.View
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import kotlinx.android.synthetic.main.fragment_settings.*
import javax.inject.Inject

internal class SettingsFragment : BaseDrawerFragment(), SettingsView {

    @Inject internal lateinit var presenter: SettingsPresenter

    override fun toolbar(): MaterialToolbar {
        return settingsToolbar
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return R.string.settings_title
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_settings
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnLogout.setOnClickListener { presenter.onLogoutClicked() }
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    companion object {

        fun newInstance(drawerLayout: DrawerLayout): SettingsFragment {
            return SettingsFragment().apply {
                setDrawer(drawerLayout)
            }
        }

    }
}
