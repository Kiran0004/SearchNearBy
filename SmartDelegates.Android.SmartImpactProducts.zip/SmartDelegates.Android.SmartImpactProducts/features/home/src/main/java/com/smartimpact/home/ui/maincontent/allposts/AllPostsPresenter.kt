package com.smartimpact.home.ui.maincontent.allposts

import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText

internal interface AllPostsPresenter {

    fun onDestroy()
    fun onViewCreated()
    fun onDestroyView()
    fun onPostAdClicked(adUrl: String)
    fun onPostClicked(post: UiPostImage, tweetUrl: String? = null)
    fun onPostClicked(post: UiPostText, tweetUrl: String? = null)
    fun onPostAuthorClicked(postAuthor: UiPostAuthor)

}
