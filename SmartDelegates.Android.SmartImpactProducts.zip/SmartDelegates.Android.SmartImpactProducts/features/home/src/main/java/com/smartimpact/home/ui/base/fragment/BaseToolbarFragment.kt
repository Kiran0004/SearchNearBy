package com.smartimpact.home.ui.base.fragment

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.annotation.DrawableRes
import androidx.annotation.MenuRes
import androidx.annotation.StringRes
import androidx.appcompat.widget.Toolbar
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R

/**
 *  Extend this class for second, third, ... level of screens. You must set status bar mode
 *  appropriately by overriding statusBarMode().
 */

abstract class BaseToolbarFragment : BaseFragment(), Toolbar.OnMenuItemClickListener {

    abstract fun toolbar(): MaterialToolbar

    @MenuRes abstract fun menuRes(): Int?

    @StringRes abstract fun titleRes(): Int?

    @DrawableRes open fun navIconRes(): Int {
        return R.drawable.ic_back
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar().setNavigationIcon(navIconRes())
        toolbar().setNavigationOnClickListener {
            onBackPressed()
        }

        menuRes()?.let {
            setToolbarMenuRes(it)
        }

        titleRes()?.let {
            toolbar().setTitle(it)
        }
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return false
    }

    protected fun setToolbarMenuRes(menuRes: Int) {
        toolbar().menu.clear()
        toolbar().inflateMenu(menuRes)
        toolbar().setOnMenuItemClickListener(this)
    }

    protected fun setToolBarTitle(title: CharSequence?) {
        toolbar().title = title
    }
}
