package com.smartimpact.home.ui.maincontent.home.posts.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.home.posts.model.*

internal class HomePostsDiffUtilCallback(
        private val oldList: List<BaseUiHomePostModel>,
        private val newList: List<BaseUiHomePostModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiHomePostAd && newItem is UiHomePostAd ->
                oldItem == newItem
            oldItem is UiHomePostEmpty && newItem is UiHomePostEmpty ->
                true
            oldItem is UiHomePostImage && newItem is UiHomePostImage ->
                oldItem.postImage.postId == newItem.postImage.postId
            oldItem is UiHomePostShimmer && newItem is UiHomePostShimmer ->
                true
            oldItem is UiHomePostText && newItem is UiHomePostText ->
                oldItem.postText.postId == newItem.postText.postId
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiHomePostAd && newItem is UiHomePostAd ->
                oldItem == newItem
            oldItem is UiHomePostEmpty && newItem is UiHomePostEmpty ->
                true
            oldItem is UiHomePostImage && newItem is UiHomePostImage ->
                oldItem == newItem
            oldItem is UiHomePostShimmer && newItem is UiHomePostShimmer ->
                true
            oldItem is UiHomePostText && newItem is UiHomePostText ->
                oldItem == newItem
            else -> false
        }
    }
}
