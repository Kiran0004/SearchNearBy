package com.smartimpact.home.ui.maincontent.sessiondetails.list

import android.content.Context
import android.view.View
import androidx.core.os.LocaleListCompat
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.base.ui.widget.ListTile
import com.smartimpact.base.ui.widget.chip.CompactChip
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.sessiondetails.list.itemlayout.SessionDetailsResponseItemLayout
import com.smartimpact.home.ui.maincontent.sessiondetails.model.*
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_session_details_header.view.*
import si.kamino.adapter.BaseItemsAdapter

internal class SessionDetailsAdapter(
        context: Context,
        private val imageLoader: ImageLoader,
        private val itemListener: SessionDetailsItemListener
) : BaseItemsAdapter<BaseUiSessionDetails, RecyclerView.ViewHolder>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (data[position]) {
            is UiSessionDetailsHeader -> ITEM_TYPE_SESSION_DETAILS_HEADER
            is UiSessionDetailsResponse -> ITEM_TYPE_SESSION_DETAILS_RESPONSE
            is BaseUiSessionDetailsTile -> ITEM_TYPE_SESSION_DETAILS_LIST_TILE
            else -> throw IllegalArgumentException("Unexpected type ${data[position]}")
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            ITEM_TYPE_SESSION_DETAILS_HEADER -> R.layout.item_session_details_header
            ITEM_TYPE_SESSION_DETAILS_RESPONSE -> R.layout.item_session_details_response
            ITEM_TYPE_SESSION_DETAILS_LIST_TILE -> R.layout.item_session_details_list_tile
            else -> throw IllegalArgumentException("Unexpected type $viewType")
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            ITEM_TYPE_SESSION_DETAILS_HEADER -> HeaderViewHolder(view)
            ITEM_TYPE_SESSION_DETAILS_RESPONSE -> {
                val layout = view as SessionDetailsResponseItemLayout
                layout.inject(itemListener)
                ResponseViewHolder(layout)
            }
            ITEM_TYPE_SESSION_DETAILS_LIST_TILE -> {
                val layout = view as ListTile
                layout.inject(imageLoader)
                TileViewHolder(layout)
            }
            else -> throw IllegalArgumentException("Unexpected type $viewType")
        }
    }

    override fun doBind(holder: RecyclerView.ViewHolder, model: BaseUiSessionDetails, position: Int) {
        when (model) {
            is UiSessionDetailsHeader -> (holder as HeaderViewHolder).bind(model)
            is UiSessionDetailsResponse -> (holder as ResponseViewHolder).bind(model)
            is BaseUiSessionDetailsTile -> (holder as TileViewHolder).bind(model)
        }
    }

    inner class HeaderViewHolder(override val containerView: View) :
            RecyclerView.ViewHolder(containerView), LayoutContainer {

        fun bind(data: UiSessionDetailsHeader) {
            val chipGroup = containerView.sessionChips
            chipGroup.removeAllViews()
            data.sessionTags.forEach { tag ->
                val chip = CompactChip(containerView.context).apply {
                    setMaxChipHeight(R.dimen.session_max_chip_height)
                    text = tag.toUpperCase(LocaleListCompat.getDefault().get(0))
                }
                chipGroup.addView(chip)
            }
            containerView.tvSessionTitle.text = data.sessionTitle
        }
    }

    inner class ResponseViewHolder(private val view: SessionDetailsResponseItemLayout) : RecyclerView.ViewHolder(view) {
        fun bind(data: UiSessionDetailsResponse) {
            view.bind(data)
        }
    }

    inner class TileViewHolder(private val listTile: ListTile) : RecyclerView.ViewHolder(listTile) {

        fun bind(data: BaseUiSessionDetailsTile) {
            listTile.setLeadingImageResource(data.getLeadingImageResource())
            listTile.titleText = data.titleText

            if (data.text != null) {
                listTile.text = data.text
            } else if (data.getTextResource() != null) {
                listTile.setText(data.getTextResource())
            }

            listTile.detailsText = data.detailsText

            listTile.setAvatarViewData(data.avatarPlaceholderText, data.avatarImageUrl)

            setupOnClickListener(data)
        }

        private fun setupOnClickListener(data: BaseUiSessionDetailsTile) {
            val onClickListener: ((View) -> Unit)? = when (data) {
                is UiSessionDetailsSpeaker ->
                    { _: View ->
                        itemListener.onSpeakerClicked(data.speakerId)
                    }
                is UiSessionDetailsAttachment ->
                    { _: View ->
                        itemListener.onAttachmentClicked(data.attachmentUri)
                    }

                else -> null
            }

            if (onClickListener != null) {
                listTile.setOnClickListener(onClickListener)
            }
        }

    }

    companion object {
        const val ITEM_TYPE_SESSION_DETAILS_HEADER = 0
        const val ITEM_TYPE_SESSION_DETAILS_RESPONSE = 1
        const val ITEM_TYPE_SESSION_DETAILS_LIST_TILE = 2
    }

}
