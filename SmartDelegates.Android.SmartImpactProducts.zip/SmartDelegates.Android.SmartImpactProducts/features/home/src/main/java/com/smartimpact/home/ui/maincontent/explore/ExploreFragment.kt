package com.smartimpact.home.ui.maincontent.explore

import android.os.Bundle
import android.util.TypedValue
import android.view.View
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import com.ferfalk.simplesearchview.SimpleSearchView
import com.ferfalk.simplesearchview.SimpleSearchViewListener
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.explore.page.ExplorePageAdapter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageFragment
import kotlinx.android.synthetic.main.fragment_explore.*
import javax.inject.Inject

internal class ExploreFragment : BaseDrawerFragment(), ExploreView {

    @Inject internal lateinit var presenter: ExplorePresenter

    private lateinit var adapter: ExplorePageAdapter

    private var elevationSize = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        elevationSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, resources.getDimension(R.dimen.elevation_size), requireContext().resources.displayMetrics)
        adapter = ExplorePageAdapter(requireContext(), childFragmentManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewPager.adapter = adapter

        searchView.setMenuItem(exploreToolbar.menu.findItem(R.id.menu_item_search))
        searchView.setOnQueryTextListener(object : SimpleSearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                presenter.onSearchChanged(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                presenter.onSearchChanged(newText)
                return false
            }

            override fun onQueryTextCleared(): Boolean {
                presenter.onSearchChanged(null)
                return false
            }
        })

        searchView.setOnSearchViewListener(object : SimpleSearchViewListener() {
            override fun onSearchViewShown() {
                presenter.onSearchViewShown()
            }

            override fun onSearchViewClosed() {
                presenter.onSearchViewClosed()
            }
        })

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (searchView.onBackPressed()) {
            return
        }

        super.onBackPressed()
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_explore
    }

    override fun toolbar(): MaterialToolbar {
        return exploreToolbar
    }

    override fun menuRes(): Int? {
        return R.menu.menu_explore
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_explore
    }

    override fun reloadCurrentPage() {
        adapter.reloadCurrentPage(getCurrentFragment())
    }

    override fun showTabLayout(show: Boolean) {
        // todo animate someday
        if (show) {
            appBarLayout.elevation = 0f
            tabLayout.isVisible = true
        } else {
            appBarLayout.elevation = elevationSize
            tabLayout.isVisible = false
        }
    }

    override fun searchCurrentPage(query: String?) {
        adapter.searchCurrentPage(getCurrentFragment(), query)
    }

    override fun lockViewPagerSwipe(lockSwipe: Boolean) {
        viewPager.setPagingEnabled(!lockSwipe)
    }

    private fun getCurrentFragment(): BaseExplorePageFragment {
        return adapter.instantiateItem(viewPager, viewPager.currentItem) as BaseExplorePageFragment
    }

    companion object {
        fun newInstance(drawerLayout: DrawerLayout): ExploreFragment {
            return ExploreFragment().apply {
                setDrawer(drawerLayout)
            }
        }
    }

}
