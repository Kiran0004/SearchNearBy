package com.smartimpact.home.ui.base.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import com.google.android.material.snackbar.Snackbar
import com.smartimpact.base.manager.keyboard.KeyboardManager
import com.smartimpact.base.manager.keyboard.KeyboardShownListener
import com.smartimpact.base.ui.snackbar.SnackbarUtils
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import dagger.android.support.DaggerFragment
import javax.inject.Inject

/**
 *  This is a base fragment for (almost) all other fragments. Status bar mode is updated for you
 *  and the supplied layout is auto-inflated. Navigation drawer is auto-locked when needed.
 */

abstract class BaseFragment : DaggerFragment(), KeyboardShownListener {

    private var snackbar: Snackbar? = null

    @Inject internal lateinit var parentPresenter: MainContentPresenter
    @Inject internal lateinit var keyboardManager: KeyboardManager

    @LayoutRes abstract fun layoutRes(): Int

    abstract fun statusBarMode(): StatusBarMode

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(layoutRes(), container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val callback = requireActivity().onBackPressedDispatcher.addCallback(this, onBackPressed = {
            onBackPressed()
        })

        requireActivity().onBackPressedDispatcher.addCallback(this, callback)

        keyboardManager.addKeyboardShownListener(this)
        keyboardManager.start()
    }

    override fun onResume() {
        parentPresenter.lockDrawer(shouldLockNavigationDrawer())
        parentPresenter.updateStatusBar(statusBarMode())
        super.onResume()
    }


    override fun onDestroyView() {
        snackbar?.dismiss()

        super.onDestroyView()
        keyboardManager.removeKeyboardShownListener(this)
        keyboardManager.close()
    }

    private fun shouldLockNavigationDrawer(): Boolean {
        return this !is BaseDrawerFragment
    }

    protected fun showSnackbar(@StringRes messageRes: Int) {
        snackbar?.dismiss()
        snackbar = SnackbarUtils.createSnackbar(requireView(), messageRes)
        snackbar?.show()
    }

    protected fun showSnackbar(message: String) {
        snackbar?.dismiss()
        snackbar = SnackbarUtils.createSnackbar(requireView(), message)
        snackbar?.show()
    }

    protected fun showErrorRetrySnackbar(message: String) {
        snackbar?.dismiss()
        snackbar = SnackbarUtils.createErrorRetrySnackbar(requireContext(), requireView(), message, ::onSnackbarRetryClicked)
        snackbar?.show()
    }

    protected open fun onSnackbarRetryClicked() {}

    open fun onBackPressed() {
        close()
    }

    fun close() {
        if (keyboardManager.shown) {
            keyboardManager.hideKeyboard(view!!)
        }

        if (requireFragmentManager().backStackEntryCount > 0) {
            requireFragmentManager().popBackStack()
        } else {
            requireActivity().finishAffinity()
        }
    }

    override fun onKeyboardShownChanged(shown: Boolean, keyboardHeight: Int) {
        // override if needed
    }

}
