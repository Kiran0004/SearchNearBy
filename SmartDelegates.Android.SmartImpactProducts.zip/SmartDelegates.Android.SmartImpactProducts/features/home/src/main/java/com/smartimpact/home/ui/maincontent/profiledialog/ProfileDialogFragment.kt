package com.smartimpact.home.ui.maincontent.profiledialog

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.core.os.bundleOf
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.profiledialog.model.UiProfileDialog
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerDialogFragment
import javax.inject.Inject

internal class ProfileDialogFragment : DaggerDialogFragment(), ProfileDialogView, ProfileDialogListener {

    @Inject internal lateinit var presenter: ProfileDialogPresenter
    @Inject internal lateinit var imageLoader: ImageLoader

    private lateinit var dialogLayout: ProfileDialogLayout
    private lateinit var profileId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profileId = requireArguments().getString(ARG_KEY_PROFILE_ID)
                ?: throw IllegalStateException("Profile ID cannot be null!")
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val inflater = requireActivity().layoutInflater
        dialogLayout = inflater.inflate(R.layout.dialog_profile, null) as ProfileDialogLayout
        dialogLayout.inject(imageLoader, this)
        return MaterialAlertDialogBuilder(context, R.style.SmartImpact_Dialog)
                .setView(dialogLayout)
                .create()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        presenter.onActivityCreated(profileId)
    }

    override fun onViewProfileClicked() {
        presenter.onViewProfileClicked()
    }

    override fun onBookmarkProfileClicked() {
        presenter.onToggleBookmarkClicked()
    }

    override fun onChatProfileClicked() {
        presenter.onChatProfileClicked()
    }

    override fun showShimmer(shouldShow: Boolean) {
        dialogLayout.showShimmer(shouldShow)
    }

    override fun showProfile(profile: UiProfileDialog) {
        dialogLayout.showProfile(profile)
    }

    override fun closeDialog() {
        dismiss()
    }

    override fun onDismiss(dialog: DialogInterface) {
        presenter.onDismissDialog()
        super.onDismiss(dialog)
    }

    override fun showBookmarAction(show: Boolean) {
        dialogLayout.showBookmarkButton(show)
    }

    override fun showChatAction(show: Boolean) {
        dialogLayout.showChatButton(show)
    }

    companion object {

        fun newInstance(profileId: String): ProfileDialogFragment {
            return ProfileDialogFragment().apply {
                arguments = bundleOf(ARG_KEY_PROFILE_ID to profileId)
            }
        }

        private const val ARG_KEY_PROFILE_ID = "com.smartimpact.home.ui.maincontent.profiledialog.ProfileDialogFragment.argProfileId"
    }
}
