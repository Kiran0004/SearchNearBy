package com.smartimpact.home.ui.maincontent.explore.page.base

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.list.peoplelist.mapper.PeopleListUiMapper
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel
import com.smartimpact.base.ui.list.peoplelist.model.UiPeopleListAd
import com.smartimpact.base.ui.list.peoplelist.util.PeopleListUtil
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.home.ui.maincontent.explore.ExplorePresenter
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.subscribeBy

internal abstract class BaseExplorePagePresenterImpl<T>(
        private val view: BaseExplorePageView,
        private val parentPresenter: ExplorePresenter,
        private val errorMessageManager: ErrorMessageManager,
        adsRepository: AdsRepository
) : BaseExplorePagePresenter {

    private var disposable: Disposable? = null

    private var dataLoaded: Boolean = false
    private var data: List<BaseUiPeopleListModel> = emptyList()

    private val adsObservable = adsRepository
            .outAds

    override fun onViewCreated() {
        loadData()
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun reloadPage() {
        loadData()
    }

    override fun searchFor(query: String?) {
        disposable?.dispose()
        disposable = Observable
                .combineLatest(
                        adsObservable,
                        searchSingle(query).toObservable(),
                        BiFunction { ads: List<AdEntity>, contacts: List<ContactEntity> ->
                            Pair(ads, contacts)
                        }
                )
                .map {
                    val ads = it.first
                    val contacts = it.second
                    mapToUi(ads, contacts)
                }
                .map { newList ->
                    val diffResult = PeopleListUtil.computeDiffResult(data, newList)
                    Pair(newList, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            data = it.first
                            val diffResult = it.second
                            view.showPeopleList(data, diffResult)
                        },
                        onError = {
                            parentPresenter.showErrorMessage(errorMessageManager.getErrorMessage(it), true)
                        }
                )

    }

    private fun loadData() {
        if (!dataLoaded) {
            data = PeopleListUtil.createShimmers(false)
            view.showPeopleList(data)
        }

        disposable?.dispose()
        disposable = Observable
                .combineLatest(
                        adsObservable,
                        dataObservable(),
                        BiFunction { ads: List<AdEntity>, contacts: List<ContactEntity> ->
                            Pair(ads, contacts)
                        }
                )
                .map {
                    val ads = it.first
                    val contacts = it.second
                    mapToUi(ads, contacts)
                }
                .map { newList ->
                    val diffResult = PeopleListUtil.computeDiffResult(data, newList)
                    Pair(newList, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            data = it.first
                            val diffResult = it.second

                            dataLoaded = true

                            if (data.any { item -> item !is UiPeopleListAd }) {
                                view.showContent(true)
                            } else {
                                view.showContent(false)
                            }
                            view.showPeopleList(data, diffResult)
                        },
                        onError = {
                            parentPresenter.showErrorMessage(errorMessageManager.getErrorMessage(it), false)
                        }
                )
    }

    private fun mapToUi(adEntities: List<AdEntity>, contactEntities: List<ContactEntity>): List<BaseUiPeopleListModel> {
        val mapped = mutableListOf<BaseUiPeopleListModel>()

        if (adEntities.isNotEmpty()) {
            val mappedAd = PeopleListUiMapper.mapToUi(adEntities)
            mapped.add(mappedAd)
        }

        mapped.addAll(mapToUi(contactEntities))

        return mapped
    }

    abstract fun mapToUi(data: List<ContactEntity>): List<BaseUiPeopleListModel>

    abstract fun searchSingle(query: String?): Single<List<ContactEntity>>

    abstract fun dataObservable(): Observable<List<ContactEntity>>

}
