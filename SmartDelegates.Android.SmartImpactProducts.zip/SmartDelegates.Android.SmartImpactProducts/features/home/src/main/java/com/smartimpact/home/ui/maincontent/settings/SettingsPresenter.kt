package com.smartimpact.home.ui.maincontent.settings

internal interface SettingsPresenter {
    fun onLogoutClicked()
    fun onDestroyView()

}