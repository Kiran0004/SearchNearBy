package com.smartimpact.home.ui.maincontent.profile.model

import com.smartimpact.home.R

internal data class UiProfileBiography(val biography: String) : BaseUiProfileTile {

    override fun leadingImageRes(): Int? {
        return R.drawable.ic_pen
    }

    override fun titleText(): String? {
        return null
    }

    override fun titleTextRes(): Int? {
        return null
    }

    override fun text(): String? {
        return biography
    }

    override fun detailsText(): String? {
        return null
    }

    override fun trailingText(): String? {
        return null
    }
}
