package com.smartimpact.home.ui.maincontent.profileedit

import android.content.Context
import android.content.Intent

interface ProfileEditPresenter {

    fun onViewCreated(context: Context)
    fun onDestroyView()
    fun onDestroy()

    fun onBackPressed()
    fun onEditDoneClicked()

    fun onDiscardClicked()
    fun onSaveClicked()

    fun onNameChanged(name: String?)
    fun onRoleChanged(role: String?)
    fun onBioChanged(bio: String?)
    fun onTwitterChanged(twitter: String?)
    fun onFacebookChanged(facebook: String?)
    fun onLinkedInChanged(linkedIn: String?)


    fun onAddPhotoClicked()
    fun onPicturePicked(data: Intent?)
    fun onStoragePermissionCheckResult(granted: Boolean)
    fun onStoragePermissionGranted()
    fun onStoragePermissionNotGranted()


}
