package com.smartimpact.home.ui.base.fragment

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.annotation.MenuRes
import androidx.annotation.StringRes
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.R

/**
 *  Extend this class for first level screens (the ones with the navigation drawer).
 *  After creating a fragment, always call setDrawer(drawerLayout). The drawer menu icon
 *  will be auto-created for you. The status bar mode is by default primary.
 */

abstract class BaseDrawerFragment : BaseFragment(), Toolbar.OnMenuItemClickListener {

    private lateinit var drawerLayout: DrawerLayout

    abstract fun toolbar(): MaterialToolbar

    @MenuRes abstract fun menuRes(): Int?

    @StringRes abstract fun titleRes(): Int?

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        menuRes()?.let {
            toolbar().inflateMenu(it)
            toolbar().setOnMenuItemClickListener(this)
        }
        titleRes()?.let {
            toolbar().setTitle(it)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val actionBarDrawerToggle = ActionBarDrawerToggle(
                requireActivity(),
                drawerLayout,
                toolbar(),
                R.string.nav_drawer_open,
                R.string.nav_drawer_close
        )

        actionBarDrawerToggle.isDrawerIndicatorEnabled = false
        // Menu icon color is dependent on theme. If set directly on the toggle, it seems to default to black.
        val menuIcon = resources.getDrawable(R.drawable.ic_menu, requireView().context.theme)
        actionBarDrawerToggle.setHomeAsUpIndicator(menuIcon)
        actionBarDrawerToggle.setToolbarNavigationClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
        actionBarDrawerToggle.syncState()

        drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
            override fun onDrawerStateChanged(newState: Int) {
            }

            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
            }

            override fun onDrawerClosed(drawerView: View) {
                parentPresenter.onDrawerClosed()
            }

            override fun onDrawerOpened(drawerView: View) {
                parentPresenter.onDrawerOpened()
            }
        })
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return false
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawers()
        } else {
            super.onBackPressed()
        }
    }

    protected fun setDrawer(drawerLayout: DrawerLayout) {
        this.drawerLayout = drawerLayout
    }
}
