package com.smartimpact.home.ui.maincontent.profile

import dagger.Binds
import dagger.Module

@Module
internal interface ProfileModule {

    @Binds fun bindView(fragment: ProfileFragment): ProfileView

    @Binds fun bindPresenter(presenterImpl: ProfilePresenterImpl): ProfilePresenter

}
