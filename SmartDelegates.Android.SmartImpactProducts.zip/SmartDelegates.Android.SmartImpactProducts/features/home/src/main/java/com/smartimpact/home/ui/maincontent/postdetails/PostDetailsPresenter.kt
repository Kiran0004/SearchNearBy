package com.smartimpact.home.ui.maincontent.postdetails

import com.smartimpact.home.post.model.UiPostAuthor

internal interface PostDetailsPresenter {

    fun onViewCreated(postId: String)
    fun onDestroyView()
    fun onDestroy()
    fun onToggleBookmarkClicked()
    fun onPostAuthorClicked(author: UiPostAuthor)

}
