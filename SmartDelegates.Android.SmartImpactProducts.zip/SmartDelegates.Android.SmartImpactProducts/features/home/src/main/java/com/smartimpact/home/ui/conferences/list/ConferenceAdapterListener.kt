package com.smartimpact.home.ui.conferences.list

import com.smartimpact.home.ui.conferences.list.itemlayout.ConferenceItemLayout

internal interface ConferenceAdapterListener
    : ConferenceItemLayout.Listener
