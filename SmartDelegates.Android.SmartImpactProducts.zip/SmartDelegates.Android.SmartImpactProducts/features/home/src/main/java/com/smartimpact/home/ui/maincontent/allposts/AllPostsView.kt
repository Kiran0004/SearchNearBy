package com.smartimpact.home.ui.maincontent.allposts

import android.content.Intent
import com.smartimpact.home.ui.maincontent.allposts.model.BaseUiAllPostsModel

internal interface AllPostsView {

    fun showPosts(posts: List<BaseUiAllPostsModel>)
    fun showNoContent(show: Boolean)
    fun openWebsite(websiteIntent: Intent?)

}
