package com.smartimpact.home.ui.maincontent.explore

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.home.ui.maincontent.explore.page.attendees.ExploreAttendeesFragment
import com.smartimpact.home.ui.maincontent.explore.page.attendees.ExploreAttendeesModule
import com.smartimpact.home.ui.maincontent.explore.page.speakers.ExploreSpeakersFragment
import com.smartimpact.home.ui.maincontent.explore.page.speakers.ExploreSpeakersModule
import com.smartimpact.home.ui.maincontent.explore.page.exhibitors.ExploreExhibitorsFragment
import com.smartimpact.home.ui.maincontent.explore.page.exhibitors.ExploreExhibitorsModule
import dagger.Binds
import dagger.Module
import dagger.android.AndroidInjectionModule
import dagger.android.ContributesAndroidInjector

@Module(includes = [AndroidInjectionModule::class])
internal interface ExploreModule {

    @Binds
    fun bindView(fragment: ExploreFragment): ExploreView

    @Binds
    fun bindPresenter(presenterImpl: ExplorePresenterImpl): ExplorePresenter

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [ExploreAttendeesModule::class])
    fun contributeExploreAttendeesFragmentInjector(): ExploreAttendeesFragment

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [ExploreSpeakersModule::class])
    fun contributeExploreSpeakersFragmentInjector(): ExploreSpeakersFragment

    @FragmentScope(FragmentScope.SUB_FRAGMENT)
    @ContributesAndroidInjector(modules = [ExploreExhibitorsModule::class])
    fun contributeExploreSponsorsFragmentInjector(): ExploreExhibitorsFragment


}
