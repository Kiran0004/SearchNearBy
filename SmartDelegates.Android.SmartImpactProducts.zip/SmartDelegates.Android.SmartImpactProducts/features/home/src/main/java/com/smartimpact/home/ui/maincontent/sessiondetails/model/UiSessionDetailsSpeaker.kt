package com.smartimpact.home.ui.maincontent.sessiondetails.model

import com.smartimpact.home.R

internal data class UiSessionDetailsSpeaker(
        val speakerId: String,
        val speakerName: String?,
        val speakerDescription: String?,
        val speakerImageUrl: String?

) : BaseUiSessionDetailsTile(
        titleText = speakerName,
        detailsText = speakerDescription,
        avatarPlaceholderText = speakerName,
        avatarImageUrl = speakerImageUrl
) {

    override fun getLeadingImageResource(): Int {
        return R.drawable.ic_user
    }

}
