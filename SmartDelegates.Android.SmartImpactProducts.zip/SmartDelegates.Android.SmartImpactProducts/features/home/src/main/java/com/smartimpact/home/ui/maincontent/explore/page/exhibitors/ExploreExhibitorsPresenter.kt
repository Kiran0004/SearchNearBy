package com.smartimpact.home.ui.maincontent.explore.page.exhibitors

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter

internal interface ExploreExhibitorsPresenter : BaseExplorePagePresenter {

    fun onExhibitorClicked(basePerson: BaseUiPeopleListPerson)

}
