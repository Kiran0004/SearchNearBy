package com.smartimpact.home.ui.maincontent.postdetails

import com.smartimpact.home.ui.maincontent.postdetails.model.UiPostDetails

internal interface PostDetailsView {

    fun showBookmarkStatus(isBookmarked: Boolean)
    fun showPostDetails(postDetails: UiPostDetails)
    fun close()

}
