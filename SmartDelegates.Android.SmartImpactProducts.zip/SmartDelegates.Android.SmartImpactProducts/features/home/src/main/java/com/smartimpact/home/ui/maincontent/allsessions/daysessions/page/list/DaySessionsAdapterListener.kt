package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.list

import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.home.session.itemlayout.SessionFullResponseItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout

internal interface DaySessionsAdapterListener :
        AdView.Listener,
        SessionFullResponseItemLayout.Listener,
        SessionSimpleItemLayout.Listener
