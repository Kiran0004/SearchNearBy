package com.smartimpact.home.ui.maincontent.notes.noteedit

import android.content.res.Resources
import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.data.notes.NotesRepository
import com.smartimpact.home.R
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class NoteEditPresenterImpl @Inject constructor(
        private val view: NoteEditView,
        private val notesRepository: NotesRepository,
        private val errorMessageManager: ErrorMessageManager,
        private val resources: Resources) : NoteEditPresenter {

    private var disposable: Disposable? = null

    private var noteId = NoteEditFragment.EMPTY_ID

    private var initialSubject: String? = null
    private var initialContent: String? = null

    override fun onViewCreated(noteId: String?) {
        if (noteId != null && noteId != NoteEditFragment.EMPTY_ID) {
            this.noteId = noteId
            fetchNoteData(noteId)
            view.showDeleteMenu(true)
        } else {
            this.noteId = NoteEditFragment.EMPTY_ID
            view.showDeleteMenu(false)
        }
        // else creating new post
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun onBackPressed(subject: String?, content: String?) {
        if (hasChanges(noteId, subject, content)) {
            view.showDiscardDialog()
        } else {
            view.finish()
        }
    }

    override fun onDeleteClicked() {
        view.showInfoMessage(R.string.notes_edit_info_deleting)
        disposable?.dispose()
        disposable = notesRepository.deleteNote(noteId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onComplete = {
                            view.finish()
                        },
                        onError = {
                            view.showErrorMessage(errorMessageManager.getErrorMessage(it), false)
                        }
                )
    }

    override fun onSaveClicked(subject: String, content: String?) {
        view.showInfoMessage(R.string.notes_edit_info_saving)

        val subjectData = if (subject.isEmpty()) {
            resources.getString(R.string.notes_edit_untitled)
        } else {
            subject
        }

        val saveCompletable = if (noteId != NoteEditFragment.EMPTY_ID) {
            notesRepository.updateNote(noteId, subjectData, content)
        } else {
            notesRepository.createNote(subjectData, content)
        }

        disposable?.dispose()
        disposable = saveCompletable
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onComplete = {
                            view.finish()
                        },
                        onError = {
                            view.showErrorMessage(errorMessageManager.getErrorMessage(it), false)
                        }
                )
    }

    override fun onSnackbarRetryClicked() {
        fetchNoteData(noteId)
    }

    private fun fetchNoteData(noteId: String) {
        disposable?.dispose()
        disposable = notesRepository.getNoteData(noteId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            initialSubject = it.subject
                            initialContent = it.content
                            view.showData(it.subject, it.content)
                        },
                        onError = {
                            view.showErrorMessage(errorMessageManager.getErrorMessage(it), true)
                        }
                )
    }

    override fun onDiscardClicked() {
        view.finish()
    }

    private fun hasChanges(noteId: String, subject: String?, content: String?): Boolean {
        return if (noteId == NoteEditFragment.EMPTY_ID) {
            true
        } else {
            initialSubject != subject || initialContent != content
        }
    }

}