package com.smartimpact.home.ui.maincontent.chat

import dagger.Binds
import dagger.Module

@Module
internal interface ChatModule {

    @Binds
    fun bindView(fragment: ChatFragment): ChatView

    @Binds
    fun bindPresenter(presenterImpl: ChatPresenterImpl): ChatPresenter

}
