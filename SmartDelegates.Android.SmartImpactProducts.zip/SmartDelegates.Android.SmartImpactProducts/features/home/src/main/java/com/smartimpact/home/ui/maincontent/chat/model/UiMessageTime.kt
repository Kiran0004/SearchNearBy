package com.smartimpact.home.ui.maincontent.chat.model

internal data class UiMessageTime(
        val timeText: String
) : BaseUiMessageModel
