package com.smartimpact.home.ui.maincontent.chat.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageReceived
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageSent
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageTime

internal class MessageDiffUtilCallback(
        private val oldList: List<BaseUiMessageModel>,
        private val newList: List<BaseUiMessageModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiMessageSent && newItem is UiMessageSent ->
                oldItem.id == newItem.id
            oldItem is UiMessageReceived && newItem is UiMessageReceived ->
                oldItem.id == newItem.id

            oldItem is UiMessageTime && newItem is UiMessageTime ->
                oldItem.timeText == newItem.timeText
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiMessageSent && newItem is UiMessageSent ->
                oldItem == newItem
            oldItem is UiMessageReceived && newItem is UiMessageReceived ->
                oldItem == newItem
            oldItem is UiMessageTime && newItem is UiMessageTime ->
                oldItem == newItem
            else -> false
        }
    }
}