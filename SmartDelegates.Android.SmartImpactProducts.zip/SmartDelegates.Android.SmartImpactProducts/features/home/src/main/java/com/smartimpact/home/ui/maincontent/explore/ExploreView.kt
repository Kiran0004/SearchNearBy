package com.smartimpact.home.ui.maincontent.explore

internal interface ExploreView {

    fun reloadCurrentPage()
    fun showTabLayout(show: Boolean)
    fun searchCurrentPage(query: String?)
    fun lockViewPagerSwipe(lockSwipe: Boolean)

}
