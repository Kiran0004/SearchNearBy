package com.smartimpact.home.ui.maincontent.sessiondetails.model

import android.net.Uri
import com.smartimpact.home.R

internal data class UiSessionDetailsAttachment(
        val attachmentName: String,
        val attachmentUri: Uri
) : BaseUiSessionDetailsTile(
        detailsText = attachmentName
) {

    override fun getLeadingImageResource(): Int {
        return R.drawable.ic_attachment
    }

    override fun getTextResource(): Int? {
        return R.string.session_details_attachment
    }

}
