package com.smartimpact.home.ui.maincontent.notes.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.notes.model.BaseUiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNoteShimmer

internal class NoteDiffUtilCallback(
        private val oldList: List<BaseUiNote>,
        private val newList: List<BaseUiNote>) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]

        return when {
            oldItem is UiNote && newItem is UiNote -> oldItem.noteId == newItem.noteId
            oldItem is UiNoteShimmer && newItem is UiNoteShimmer -> true
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]

        return when {
            oldItem is UiNote && newItem is UiNote -> oldItem == newItem
            oldItem is UiNoteShimmer && newItem is UiNoteShimmer -> true
            else -> false
        }
    }
}
