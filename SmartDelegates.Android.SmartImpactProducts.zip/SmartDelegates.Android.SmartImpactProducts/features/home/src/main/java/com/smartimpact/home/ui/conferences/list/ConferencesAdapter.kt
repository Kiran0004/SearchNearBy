package com.smartimpact.home.ui.conferences.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.ui.conferences.list.itemlayout.ConferenceItemLayout
import com.smartimpact.home.ui.conferences.model.BaseUiConferencesModel
import com.smartimpact.home.ui.conferences.model.UiConference
import com.smartimpact.home.ui.conferences.model.UiConferenceShimmer
import com.smartimpact.home.ui.conferences.model.UiConferencesHeader
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class ConferencesAdapter(
        context: Context,
        private val listener: ConferenceAdapterListener,
        private val imageLoader: ImageLoader
) : BaseItemsAdapter<BaseUiConferencesModel, ConferencesAdapter.BaseVH>(context) {

    private var isLoading: Boolean = false

    override fun setData(data: List<BaseUiConferencesModel>?) {
        isLoading = data?.find { it is UiConference && it.isSelected } != null
        super.setData(data)
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_CONFERENCE -> {
                val layout = view as ConferenceItemLayout
                layout.inject(listener, imageLoader)
                ConferenceVH(layout)
            }
            TYPE_CONFERENCE_SHIMMER_0, TYPE_CONFERENCE_SHIMMER_1, TYPE_CONFERENCES_HEADER -> {
                NonBindingVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiConferencesModel, position: Int) {
        holder.bind(item)
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_CONFERENCE -> R.layout.item_conferences_conference
            TYPE_CONFERENCE_SHIMMER_0 -> R.layout.item_conferences_conference_shimmer_0
            TYPE_CONFERENCE_SHIMMER_1 -> R.layout.item_conferences_conference_shimmer_1
            TYPE_CONFERENCES_HEADER -> R.layout.item_conferences_header
            else -> throw IllegalStateException()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (val item = getItem(position)) {
            is UiConference -> TYPE_CONFERENCE
            is UiConferenceShimmer -> calculateShimmerType(item)
            is UiConferencesHeader -> TYPE_CONFERENCES_HEADER
            else -> throw IllegalStateException()
        }
    }

    private fun calculateShimmerType(uiShimmer: UiConferenceShimmer): Int {
        return when (uiShimmer.shimmerVariance % 2) {
            0 -> TYPE_CONFERENCE_SHIMMER_0
            1 -> TYPE_CONFERENCE_SHIMMER_1
            else -> throw IllegalStateException()
        }
    }

    abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiConferencesModel)
    }

    private inner class ConferenceVH(
            override val containerView: ConferenceItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiConferencesModel) {
            containerView.isClickable = !isLoading
            containerView.bind(item as UiConference)
        }
    }

    private class NonBindingVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiConferencesModel) {}
    }

    companion object {
        private const val TYPE_CONFERENCE = 0
        private const val TYPE_CONFERENCE_SHIMMER_0 = 1
        private const val TYPE_CONFERENCE_SHIMMER_1 = 2
        private const val TYPE_CONFERENCES_HEADER = 3
    }

}
