package com.smartimpact.home.ui.maincontent.profile.model

internal interface BaseUiProfileSocialTile : BaseUiProfileTile {

    override fun titleText(): String? {
        return null
    }

    override fun text(): String? {
        return null
    }

    override fun detailsText(): String? {
        return null
    }
}
