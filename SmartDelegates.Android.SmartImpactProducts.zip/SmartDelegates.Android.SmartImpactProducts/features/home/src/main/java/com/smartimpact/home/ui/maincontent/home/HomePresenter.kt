package com.smartimpact.home.ui.maincontent.home

import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker

internal interface HomePresenter {

    fun onDestroy()
    fun onViewCreated()
    fun onDestroyView()

    fun onAllPostsClicked()

    fun onAllSessionsClicked()

    fun onNewPostClicked()

    fun onAdClicked(adUrl: String)
    fun onPostClicked(post: UiPostImage)
    fun onPostClicked(post: UiPostText)
    fun onPostAuthorClicked(postAuthor: UiPostAuthor)

    fun onSessionFullClicked(sessionFull: UiSessionFull)
    fun onSessionSimpleClicked(sessionSimple: UiSessionSimple)
    fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>)

}
