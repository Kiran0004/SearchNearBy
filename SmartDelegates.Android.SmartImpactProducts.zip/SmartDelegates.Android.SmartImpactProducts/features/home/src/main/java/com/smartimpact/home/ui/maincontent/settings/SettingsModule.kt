package com.smartimpact.home.ui.maincontent.settings

import dagger.Binds
import dagger.Module

@Module
internal interface SettingsModule {

    @Binds
    fun provideView(fragment: SettingsFragment): SettingsView

    @Binds
    fun providePresenter(presenterImpl: SettingsPresenterImpl): SettingsPresenter

}