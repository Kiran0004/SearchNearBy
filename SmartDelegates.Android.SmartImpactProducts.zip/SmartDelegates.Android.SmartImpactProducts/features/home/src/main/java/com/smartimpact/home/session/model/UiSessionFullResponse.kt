package com.smartimpact.home.session.model

internal data class UiSessionFullResponse(
        val sessionFull: UiSessionFull,
        val sessionResponse: Int
) : BaseUiSessionModel {

    companion object {
        const val RESPONSE_NONE = 0
        const val RESPONSE_GOING = 1
        const val RESPONSE_NOT_GOING = 3
    }

}
