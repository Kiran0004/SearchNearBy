package com.smartimpact.home.session.itemlayout

object SessionBase {
    const val PASSED_SESSION_ALPHA = 0.4f
}