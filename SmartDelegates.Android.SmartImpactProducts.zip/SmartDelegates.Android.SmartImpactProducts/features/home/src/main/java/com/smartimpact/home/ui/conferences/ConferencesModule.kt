package com.smartimpact.home.ui.conferences

import dagger.Binds
import dagger.Module

@Module
internal interface ConferencesModule {

    @Binds
    fun bindView(fragment: ConferencesFragment): ConferencesView

    @Binds
    fun bindPresenter(presenterImpl: ConferencesPresenterImpl): ConferencesPresenter
    
}
