package com.smartimpact.home.ui.maincontent.postdetails


import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.postdetails.model.UiPostDetails
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_post_details.*
import javax.inject.Inject


import android.widget.ImageView.ScaleType
import com.bumptech.glide.Glide


internal class PostDetailsFragment : BaseToolbarFragment(), PostDetailsView, Toolbar.OnMenuItemClickListener {

    @Inject internal lateinit var presenter: PostDetailsPresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    private lateinit var bookmarkMenuItem: MenuItem

    override fun toolbar(): MaterialToolbar {
        return postDetailsToolbar
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_post_details
    }

    override fun menuRes(): Int? {
        return R.menu.menu_post_details
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.SECONDARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viAvatar.inject(imageLoader)

        bookmarkMenuItem = toolbar().menu.findItem(R.id.menu_item_post_bookmark)

        val arguments = requireArguments()
        val postId = arguments.getString(ARG_KEY_POST_ID)
                ?: throw IllegalStateException("postId must be provided")

        presenter.onViewCreated(postId)
    }

    override fun onResume() {
        parentPresenter.updateStatusBar(StatusBarMode.SECONDARY)
        super.onResume()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_post_bookmark -> {
                presenter.onToggleBookmarkClicked()
                true
            }
            else -> false
        }
    }

    override fun showBookmarkStatus(isBookmarked: Boolean) {
        val iconRes = when (isBookmarked) {
            true -> R.drawable.ic_bookmark_filled
            false -> R.drawable.ic_bookmark
        }
        bookmarkMenuItem.setIcon(iconRes)
    }

    override fun showPostDetails(postDetails: UiPostDetails) {
        viAvatar.setData(postDetails.author.authorName, postDetails.author.authorImageUrl)
        tvPostDetailsAuthor.text = postDetails.author.authorName
        tvPostDetailsTime.text = postDetails.postTime
        tvPostDetailsBody.text = postDetails.postBody

        if (postDetails.postImageUrl.isNullOrEmpty()) {
            ivPostDetails.isVisible = false
        } else {
            ivPostDetails.isVisible = true

            Glide.with(this)
                    .asBitmap()
                    .load(postDetails.postImageUrl)
                    .override(600, 600)
                    .fitCenter()
                    .placeholder(R.drawable.empty_image_placeholder)
                    .into(ivPostDetails)


          //  imageLoader.loader(postDetails.postImageUrl, ivPostDetails, R.drawable.empty_image_placeholder)
        }

        btnAuthor.setOnClickListener {
            presenter.onPostAuthorClicked(postDetails.author)
        }
    }

    companion object {

        fun newInstance(postId: String): PostDetailsFragment {
            return PostDetailsFragment().apply {
                arguments = bundleOf(ARG_KEY_POST_ID to postId)
            }
        }

        private const val ARG_KEY_POST_ID = "com.smartimpact.home.ui.maincontent.postdetails.PostDetailsFragment.argPostId"
    }

}
