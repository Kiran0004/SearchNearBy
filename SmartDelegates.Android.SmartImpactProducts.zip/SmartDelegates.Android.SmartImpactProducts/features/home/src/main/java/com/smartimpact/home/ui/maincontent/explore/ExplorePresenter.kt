package com.smartimpact.home.ui.maincontent.explore

internal interface ExplorePresenter {

    fun onDestroy()
    fun onViewCreated()
    fun onDestroyView()
    fun onSearchChanged(query: String?)
    fun showErrorMessage(errorMessage: String, isSearch: Boolean)
    fun onSearchViewClosed()
    fun onSearchViewShown()
    fun onPersonClicked(id: String, showDialog: Boolean = true, isSponsor : Boolean = false)
    fun openChatViewForContact(contactId: String)

}
