package com.smartimpact.home.ui.maincontent.sessiondetails.list

import android.net.Uri

internal interface SessionDetailsItemListener {

    fun onSpeakerClicked(speakerId: String)

    fun onAttachmentClicked(attachmentUri: Uri)

    fun onSessionResponseClicked(response: Int)

}
