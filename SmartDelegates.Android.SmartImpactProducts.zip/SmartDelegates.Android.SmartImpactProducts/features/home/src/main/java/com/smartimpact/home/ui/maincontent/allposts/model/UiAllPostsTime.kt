package com.smartimpact.home.ui.maincontent.allposts.model

internal data class UiAllPostsTime(
        val timeText: String
) : BaseUiAllPostsModel
