package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap

internal interface ConferenceMapPresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onResume()
    fun onPause()

}
