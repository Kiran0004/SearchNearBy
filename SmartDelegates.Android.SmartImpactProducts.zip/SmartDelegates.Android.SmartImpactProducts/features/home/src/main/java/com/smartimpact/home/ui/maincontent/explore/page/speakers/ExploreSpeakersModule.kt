package com.smartimpact.home.ui.maincontent.explore.page.speakers

import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePageView
import dagger.Binds
import dagger.Module

@Module
internal interface ExploreSpeakersModule {

    @Binds
    fun bindView(fragment: ExploreSpeakersFragment): ExploreSpeakersView

    @Binds
    fun bindPresenter(presenterImpl: ExploreSpeakersPresenterImpl): ExploreSpeakersPresenter

    @Binds
    fun bindBaseView(view: ExploreSpeakersView): BaseExplorePageView

    @Binds
    fun bindBasePresenter(presenter: ExploreSpeakersPresenter): BaseExplorePagePresenter

}
