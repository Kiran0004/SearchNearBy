package com.smartimpact.home.ui.maincontent.bookmarks.page.people.model

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

internal data class UiBookmarkedPerson(
        override val id: String,
        override val imageUrl: String?,
        override val nameText: String?,
        override val bioText: String?,
        override val isSponsor: Boolean?
) : BaseUiPeopleListPerson()
