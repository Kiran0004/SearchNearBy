package com.smartimpact.home.session

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.session.mapper.SessionUiMapper
import dagger.Module
import dagger.Provides

@Module
internal class SessionModule {

    @Provides
    @FragmentScope(FragmentScope.CONTAINER)
    fun provideSessionUiMapper(dateTimeFormatHelper: DateTimeFormatHelper): SessionUiMapper {
        return SessionUiMapper(dateTimeFormatHelper)
    }

}
