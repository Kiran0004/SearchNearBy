package com.smartimpact.home.ui.maincontent.allposts.model

internal class UiAllPostsTimeShimmer : BaseUiAllPostsModel
