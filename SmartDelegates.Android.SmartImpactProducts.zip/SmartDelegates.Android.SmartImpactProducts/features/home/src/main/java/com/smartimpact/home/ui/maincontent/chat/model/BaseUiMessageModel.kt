package com.smartimpact.home.ui.maincontent.chat.model

internal interface BaseUiMessageModel
