package com.smartimpact.home.ui.maincontent.profileedit

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.photo.PhotoPickerManager
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module(includes = [ProfileEditBindModule::class])
internal object ProfileEditModule {

    @JvmStatic
    @Provides
    @FragmentScope(FragmentScope.FRAGMENT)
    fun providePhotoPickerManager(fragment: ProfileEditFragment): PhotoPickerManager {
        return PhotoPickerManager(fragment.requireContext(), "")
    }
}


@Module
internal interface ProfileEditBindModule {

    @Binds fun bindView(fragment: ProfileEditFragment): ProfileEditView

    @Binds fun bindPresenter(presenterImpl: ProfileEditPresenterImpl): ProfileEditPresenter



}
