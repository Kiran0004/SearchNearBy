package com.smartimpact.home.ui.maincontent.root

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.google.android.material.snackbar.Snackbar
import com.smartimpact.base.ui.snackbar.SnackbarUtils
import com.smartimpact.data.inbox.InboxRepository
import com.smartimpact.home.R
import com.smartimpact.base.messagemanager.data.ActionableMessage
import com.smartimpact.base.messagemanager.data.PlainMessage
import com.smartimpact.home.ui.conferences.ConferencesFragment
import com.smartimpact.home.ui.maincontent.allposts.AllPostsFragment
import com.smartimpact.home.ui.maincontent.allsessions.AllSessionsFragment
import com.smartimpact.home.ui.maincontent.bookmarks.BookmarksFragment
import com.smartimpact.home.ui.maincontent.chat.ChatFragment
import com.smartimpact.home.ui.maincontent.explore.ExploreFragment
import com.smartimpact.home.ui.maincontent.home.HomeFragment
import com.smartimpact.home.ui.maincontent.inbox.InboxFragment
import com.smartimpact.home.ui.maincontent.inbox.newconversation.NewConversationFragment
import com.smartimpact.home.ui.maincontent.info.EventInfoFragment
import com.smartimpact.home.ui.maincontent.maps.MapsFragment
import com.smartimpact.home.ui.maincontent.newpost.NewPostFragment
import com.smartimpact.home.ui.maincontent.notes.NotesFragment
import com.smartimpact.home.ui.maincontent.notes.noteedit.NoteEditFragment
import com.smartimpact.home.ui.maincontent.postdetails.PostDetailsFragment
import com.smartimpact.home.ui.maincontent.profile.ProfileFragment
import com.smartimpact.home.ui.maincontent.profiledialog.ProfileDialogFragment
import com.smartimpact.home.ui.maincontent.profileedit.ProfileEditFragment
import com.smartimpact.base.ui.navigation.model.UiProfileShort
import com.smartimpact.base.ui.navigation.NavigationMenuListener
import com.smartimpact.base.ui.navigation.NavigationPanelLayout
import com.smartimpact.base.ui.navigation.model.AdvancedNavigationMenuItem
import com.smartimpact.base.ui.navigation.model.BasicNavigationMenuItem
import com.smartimpact.base.ui.navigation.model.NavigationMenuItem
import com.smartimpact.home.ui.maincontent.sessiondetails.SessionDetailsFragment
import com.smartimpact.home.ui.maincontent.settings.SettingsFragment
import com.smartimpact.image.ImageLoader
import com.smartimpact.userprofile.manager.ProfileManager
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_main_content.*
import javax.inject.Inject

class MainContentFragment : DaggerFragment(), MainContentView, NavigationMenuListener {

    @Inject internal lateinit var presenter: MainContentPresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    @Inject internal lateinit var inboxRepository: InboxRepository
    @Inject internal lateinit var profileManager: ProfileManager

    private var snackbar: Snackbar? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_main_content, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val chatId = arguments?.getString(ARG_CHAT_ID)
        arguments?.clear()

        presenter.onViewCreated(chatId)
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        snackbar?.dismiss()
        presenter.onDestroy()
        super.onDestroy()
    }

    private fun getMenuItems(hasNewMessage: Boolean) = listOf(
            BasicNavigationMenuItem(MENU_ITEM_ID_HOME, R.drawable.ic_nav_home, R.string.nav_drawer_home),
            AdvancedNavigationMenuItem(MENU_ITEM_ID_INBOX, R.drawable.ic_nav_messenger, R.string.nav_drawer_inbox, R.string.nav_drawer_inbox_new, hasNewMessage),
            BasicNavigationMenuItem(MENU_ITEM_ID_MAPS, R.drawable.ic_nav_maps, R.string.nav_drawer_maps),
            BasicNavigationMenuItem(MENU_ITEM_ID_EXPLORE, R.drawable.ic_nav_explore, R.string.nav_drawer_explore),
            BasicNavigationMenuItem(MENU_ITEM_ID_BOOKMARKS, R.drawable.ic_nav_bookmarks, R.string.nav_drawer_bookmarks),
            BasicNavigationMenuItem(MENU_ITEM_ID_NOTES, R.drawable.ic_nav_notes, R.string.nav_drawer_notes),
            BasicNavigationMenuItem(MENU_ITEM_ID_INFO, R.drawable.ic_nav_info, R.string.nav_drawer_event_info),
            BasicNavigationMenuItem(MENU_ITEM_ID_SETTINGS, R.drawable.ic_nav_settings, R.string.nav_drawer_settings),
            BasicNavigationMenuItem(MENU_ITEM_ID_SWITCH_EVENTS, R.drawable.ic_switch_events, R.string.nav_drawer_switch)
    )

    override fun onNavigationMenuItemClicked(menuItem: NavigationMenuItem, hasChanged: Boolean) {
        if (hasChanged) {
            when (menuItem.itemId) {
                MENU_ITEM_ID_HOME -> showHomeView()
                MENU_ITEM_ID_INBOX -> showInboxView(null)
                MENU_ITEM_ID_EXPLORE -> showExploreView()
                MENU_ITEM_ID_MAPS -> showMapsView()
                MENU_ITEM_ID_BOOKMARKS -> showBookmarksView()
                MENU_ITEM_ID_NOTES -> showNotesView()
                MENU_ITEM_ID_INFO -> showInfoView()
                MENU_ITEM_ID_SETTINGS -> showSettingsView()
                MENU_ITEM_ID_SWITCH_EVENTS -> openSelectEventView()
            }
        }
        drawerLayout.closeDrawers()
    }

    override fun onNavigationProfileClicked() {
        presenter.onNavigationProfileClicked()
    }

    override fun onNavigationEditProfileClicked() {
        presenter.onNavigationEditProfileClicked()
    }

    override fun onBackToAppChoiceClicked() {
        presenter.backToAppChoiceView()
    }

    override fun lockDrawer(lock: Boolean) {
        val lockMode = if (lock) {
            DrawerLayout.LOCK_MODE_LOCKED_CLOSED
        } else {
            DrawerLayout.LOCK_MODE_UNLOCKED
        }
        drawerLayout.setDrawerLockMode(lockMode)
    }

    override fun closeDrawer() {
        drawerLayout.closeDrawers()
    }

    override fun showProfile(profile: UiProfileShort) {
        val panel = (eventsAppNavigationPanel as NavigationPanelLayout)
        panel.setProfile(profile, imageLoader, this)
    }
    override fun showProfileUri(profile: UiProfileShort, uri: Uri) {
        val panel = (eventsAppNavigationPanel as NavigationPanelLayout)
        panel.setProfile(profile, uri, this)
    }

    override fun showNavigationItems(hasNewMessage: Boolean) {
        val panel = (eventsAppNavigationPanel as NavigationPanelLayout)
        panel.setMenuItems(getMenuItems(hasNewMessage), panel.getCurrentMenuItem()
                ?: MENU_ITEM_ID_HOME, this)
    }

    override fun showHomeView() {
        val fragment = HomeFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showInboxView(chatId: String?) {
        val fragment = InboxFragment.newInstance(drawerLayout, chatId)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showExploreView() {
        val fragment = ExploreFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showMapsView() {
        val fragment = MapsFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showNotesView() {
        val fragment = NotesFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showBookmarksView() {
        val fragment = BookmarksFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showInfoView() {
        val fragment = EventInfoFragment.newInstance(drawerLayout)
        nextScreen(fragment, animate = false, isPrimaryNavigationFragment = false, addToBackStack = false)
    }

    override fun showSettingsView() {
        nextScreen(SettingsFragment.newInstance(drawerLayout), animate = false, isPrimaryNavigationFragment = true, addToBackStack = false)
    }

    override fun openChatViewForContact(contactId: String) {
        nextScreen(ChatFragment.newInstanceContact(contactId), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openAllPostsView() {
        nextScreen(AllPostsFragment.newInstance(), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openPostDetailsView(postId: String, tweetUrl: String?) {
        if(tweetUrl.isNullOrBlank()){
            val fragment = PostDetailsFragment.newInstance(postId)
            nextScreen(fragment, animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
        }else{
            presenter.openTweet(tweetUrl)
        }
    }

    override fun openNewPostView() {
        nextScreen(NewPostFragment.newInstance(), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openAllSessionsView() {
        nextScreen(AllSessionsFragment.newInstance(), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openProfileView(profileId: String, isSponsor : Boolean) {
        nextScreen(ProfileFragment.newInstance(profileId, isSponsor), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openProfileEditView() {
        nextScreen(ProfileEditFragment.newInstance(), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openNoteEditView(noteId: String) {
        nextScreen(NoteEditFragment.newInstance(noteId), animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openSessionDetailsView(sessionId: String) {
        val fragment = SessionDetailsFragment.newInstance(sessionId)
        nextScreen(fragment, animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    override fun openSelectEventView() {
        val panel = (eventsAppNavigationPanel as NavigationPanelLayout)
       nextScreen(ConferencesFragment.newInstance(), animate = false, isPrimaryNavigationFragment = true, addToBackStack = false)
        panel.setMenuItems(getMenuItems(false), 0?: MENU_ITEM_ID_HOME, this)
    }

    override fun openProfileDialog(profileId: String) {
        val dialog = ProfileDialogFragment.newInstance(profileId)
        dialog.show(childFragmentManager, null)
    }

    override fun openNewConversationView() {
        val fragment = NewConversationFragment()
        nextScreen(fragment, animate = true, isPrimaryNavigationFragment = false, addToBackStack = true)
    }

    private fun nextScreen(fragment: Fragment, addToBackStack: Boolean = true, isPrimaryNavigationFragment: Boolean = false, animate: Boolean = true, clearBackstack: Boolean = false) {
        if (clearBackstack) {
            childFragmentManager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }

        childFragmentManager.beginTransaction()
                .apply {
                    if (animate) {
                        setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right)
                    }

                    replace(R.id.main_fragment_host, fragment)

                    if (addToBackStack) {
                        addToBackStack(null)
                    }
                    if (isPrimaryNavigationFragment) {
                        setPrimaryNavigationFragment(fragment)
                    }
                }
                .commit()
    }

    override fun showPlainMessage(message: PlainMessage) {
        val text = when {
            message.text != null -> message.text
            message.textRes != null -> requireContext().getString(message.textRes!!)
            else -> throw IllegalStateException()
        }

        snackbar?.dismiss()
        snackbar = SnackbarUtils.createSnackbar(coordinator, text!!)
        snackbar?.show()

    }

    override fun showActionableMessage(message: ActionableMessage) {
        val text = when {
            message.text != null -> message.text
            message.textRes != null -> requireContext().getString(message.textRes!!)
            else -> throw IllegalStateException()
        }
        val onRetry = message.onAction

        snackbar?.dismiss()
        snackbar = SnackbarUtils.createErrorRetrySnackbar(requireContext(), coordinator, text!!, onRetry)
        snackbar?.show()
    }

    override fun dismissMessage() {
        snackbar?.dismiss()
    }

    override fun handleIntent(intent: Intent) {
        startActivity(intent)
    }

    companion object {
        private const val ARG_CHAT_ID = "com.smartimpact.home.ui.maincontent.root.MainContentFragment.chatId"

        const val MENU_ITEM_ID_HOME = 0
        const val MENU_ITEM_ID_INBOX = 1
        const val MENU_ITEM_ID_MAPS = 2
        const val MENU_ITEM_ID_EXPLORE = 3
        const val MENU_ITEM_ID_BOOKMARKS = 4
        const val MENU_ITEM_ID_NOTES = 5
        const val MENU_ITEM_ID_INFO = 6
        const val MENU_ITEM_ID_SETTINGS= 7
        const val MENU_ITEM_ID_SWITCH_EVENTS = 8

        fun newInstance(chatId: String?): MainContentFragment {
            return MainContentFragment().apply {
                arguments = bundleOf(ARG_CHAT_ID to chatId)
            }
        }
    }

}
