package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap

import com.smartimpact.api.ApiService
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.mod.ShowWhileResumedMessageManagerMod
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class ConferenceMapPresenterImpl @Inject constructor(
        private val view: ConferenceMapView,
        private val apiService: ApiService,
        private val messageManager: MessageManager,
        private val profileManager: ProfileManager
) : ConferenceMapPresenter {

    private var disposable: Disposable? = null

    private lateinit var messageManagerMod: ShowWhileResumedMessageManagerMod

    override fun onViewCreated() {
        messageManagerMod = ShowWhileResumedMessageManagerMod(
                messageManager = messageManager,
                onAction = {
                    loadData()
                }
        )

        loadData()
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun onResume() {
        messageManagerMod.onResume()
    }

    override fun onPause() {
        messageManagerMod.onPause()
    }

    private fun loadData() {
        disposable?.dispose()
        disposable = apiService.getEvent(profileManager.getEventProfileData().eventId)
                .map { it.eventMapUrls ?: "" }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            var eventMapUrls: ArrayList<String> = it as ArrayList<String>
                            view.showMap(eventMapUrls)
                        },
                        onError = {
                            messageManagerMod.handleActionableMessage(it)
                        }
                )
    }
}
