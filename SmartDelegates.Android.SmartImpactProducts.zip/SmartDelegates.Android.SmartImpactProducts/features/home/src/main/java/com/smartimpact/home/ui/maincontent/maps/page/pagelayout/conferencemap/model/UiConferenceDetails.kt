package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.model

internal data class UiConferenceDetails(
        val sessionTags: List<String>
) : ConferenceUiSessionDetails
