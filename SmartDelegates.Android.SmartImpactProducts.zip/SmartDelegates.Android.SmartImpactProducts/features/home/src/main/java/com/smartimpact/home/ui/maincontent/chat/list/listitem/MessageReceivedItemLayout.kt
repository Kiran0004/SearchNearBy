package com.smartimpact.home.ui.maincontent.chat.list.listitem

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageReceived
import kotlinx.android.synthetic.main.item_chat_message_received.view.*

internal class MessageReceivedItemLayout(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {

    fun bind(data: UiMessageReceived) {
        tvMessage.text = data.messageText
    }

}
