package com.smartimpact.home.session.model

internal data class UiSessionSimple(
        val sessionId: String,
        val sessionTitle: String,
        val sessionTime: String,
        val sessionLocation: String?,
        val sessionPassed: Boolean
) : BaseUiSessionModel
