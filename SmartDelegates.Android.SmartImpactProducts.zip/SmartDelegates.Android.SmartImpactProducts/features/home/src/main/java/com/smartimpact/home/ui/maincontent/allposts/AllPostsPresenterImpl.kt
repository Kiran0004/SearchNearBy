package com.smartimpact.home.ui.maincontent.allposts

import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.post.entity.PostEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.post.mapper.PostUiMapper
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.ui.maincontent.allposts.model.*
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.LocalDate
import javax.inject.Inject

internal class AllPostsPresenterImpl @Inject constructor(
        private val view: AllPostsView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val postRepository: PostRepository,
        private val postUiMapper: PostUiMapper,
        private val dateTimeFormatHelper: DateTimeFormatHelper,
        private val socialIntentManager: SocialIntentManager
) : AllPostsPresenter {

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    postRepository.initialize()
                }
        )

        postRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outAllPosts
                .map { mapToUi(it) }
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { view.showPosts(getShimmerItems()) }
                .subscribeBy { posts ->
                    view.showNoContent(posts.isEmpty())
                    view.showPosts(posts)
                }
                .addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()

        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onPostAdClicked(adUrl: String) {
        view.openWebsite(socialIntentManager.getWebsiteIntent(adUrl))
    }

    override fun onPostClicked(post: UiPostImage, tweetUrl: String?) {
        parentPresenter.openPostDetailsView(post.postId, tweetUrl)
    }

    override fun onPostClicked(post: UiPostText, tweetUrl: String?) {
        parentPresenter.openPostDetailsView(post.postId, tweetUrl)
    }

    override fun onPostAuthorClicked(postAuthor: UiPostAuthor) {
        parentPresenter.openProfileDialog(postAuthor.authorId)
    }

    private fun getShimmerItems(): List<BaseUiAllPostsModel> {
        val timeShimmer = UiAllPostsTimeShimmer()
        val postShimmer = UiAllPostsPostShimmer()
        return listOf(timeShimmer, postShimmer, postShimmer, postShimmer, postShimmer, postShimmer)
    }

    private fun mapToUi(entities: List<PostEntity>): List<BaseUiAllPostsModel> {
        val uiItems = mutableListOf<BaseUiAllPostsModel>()

        val groupedPosts = sortAndGroupPostsByDate(entities)
        val today = LocalDate.now()

        val dates = groupedPosts.keys
        dates.forEach { date ->
            val timeText = dateTimeFormatHelper.getRelativeToTodayDateString(today, date)
            uiItems.add(UiAllPostsTime(timeText))

            val postsOnDate = groupedPosts[date] ?: throw IllegalStateException()
            postsOnDate.forEach { postEntity ->
                val uiPost = when (val uiPostModel = postUiMapper.mapToUi(postEntity)) {
                    is UiPostImage -> UiAllPostsPostImage(uiPostModel)
                    is UiPostText -> UiAllPostsPostText(uiPostModel)
                    else -> throw IllegalStateException()
                }
                uiItems.add(uiPost)
            }
        }

        return uiItems
    }

    private fun sortAndGroupPostsByDate(posts: List<PostEntity>): Map<LocalDate, List<PostEntity>> {
        val sortedPosts = posts.sortedBy { it.createdOn }.reversed()

        val map = mutableMapOf<LocalDate, MutableList<PostEntity>>()

        sortedPosts.forEach { post ->
            val key = post.createdOn.toLocalDate()

            if (!map.containsKey(key)) {
                map[key] = mutableListOf()
            }
            map[key]!!.add(post)
        }

        return map
    }

}
