package com.smartimpact.home.ui.maincontent.allposts.model

import com.smartimpact.home.post.model.UiPostImage

internal data class UiAllPostsPostImage(
        val postImage: UiPostImage
) : BaseUiAllPostsModel
