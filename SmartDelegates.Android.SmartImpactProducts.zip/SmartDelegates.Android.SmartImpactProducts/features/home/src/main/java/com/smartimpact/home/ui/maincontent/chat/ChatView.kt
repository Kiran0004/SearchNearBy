package com.smartimpact.home.ui.maincontent.chat

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel

internal interface ChatView {

    fun updateToolBarTitle(toolBarTitle: String)
    fun setData(messages: List<BaseUiMessageModel>)
    fun setData(messages: List<BaseUiMessageModel>, diffResult: DiffUtil.DiffResult)
    fun clearNewMessageInput()
    fun scrollToLatestMessage(shouldScrollBeSmooth: Boolean)
    fun showSendLoading(show: Boolean)
    fun enableSend(enabled: Boolean)

}
