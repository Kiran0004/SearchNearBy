package com.smartimpact.home.ui.maincontent.explore.page.base

interface BaseExplorePagePresenter {
    fun onViewCreated()
    fun onDestroyView()
    fun reloadPage()
    fun searchFor(query: String?)
}