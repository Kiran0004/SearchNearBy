package com.smartimpact.home.post.model

internal interface BaseUiPostModel
