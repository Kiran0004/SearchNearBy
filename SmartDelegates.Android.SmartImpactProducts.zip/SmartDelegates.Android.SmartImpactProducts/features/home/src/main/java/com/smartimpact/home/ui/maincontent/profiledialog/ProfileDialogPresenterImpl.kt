package com.smartimpact.home.ui.maincontent.profiledialog

import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.contacts.entity.ContactDetailsEntity
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.home.ui.maincontent.profiledialog.model.UiProfileDialog
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.functions.BiFunction
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.flatMapIterable
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class ProfileDialogPresenterImpl @Inject constructor(
        private val view: ProfileDialogView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val contactDetailsRepository: ContactDetailsRepository,
        private val bookmarksRepository: BookmarksRepository,
        private val profileManager: ProfileManager
) : ProfileDialogPresenter {

    private lateinit var profileId: String

    private val compositeDisposable = CompositeDisposable()
    private var fetchDataDisposable: Disposable? = null

    override fun onActivityCreated(profileId: String) {
        this.profileId = profileId

        view.showBookmarAction(profileManager.getEventProfileData().eventProfileId != profileId)
        view.showChatAction(profileManager.getEventProfileData().eventProfileId != profileId)

        view.showShimmer(true)

        contactDetailsRepository
                .outObtainOfContactError
                .filter {
                    val contactId = it.first
                    contactId == profileId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val error = it.second
                    messageManager.handlePlainMessage(error)
                    view.closeDialog()
                }
                .addTo(compositeDisposable)


        bookmarksRepository.outInitializationError
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                    view.closeDialog()
                }
                .addTo(compositeDisposable)

        val contactDetailsObservable = contactDetailsRepository
                .outContactDetails
                .flatMapIterable()
                .filter { contactDetailsEntity ->
                    contactDetailsEntity.id == profileId
                }

        val isBookmarkedObservable = bookmarksRepository
                .outBookmarkedContactIds
                .map { it.contains(profileId) }

        Observable
                .combineLatest(
                        contactDetailsObservable,
                        isBookmarkedObservable,
                        BiFunction { contactDetails: ContactDetailsEntity, isBookmarked: Boolean ->
                            mapToUiModel(contactDetails, isBookmarked)
                        }
                )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    view.showShimmer(false)
                    view.showProfile(it)
                }
                .addTo(compositeDisposable)

        contactDetailsRepository.obtainOfContact(profileId)
    }

    override fun onDismissDialog() {
        compositeDisposable.dispose()
        fetchDataDisposable?.dispose()
    }

    override fun onToggleBookmarkClicked() {
        bookmarksRepository.toggleContactBookmark(profileId)
    }

    override fun onChatProfileClicked() {
        view.closeDialog()
        parentPresenter.openChatViewForContact(profileId)
    }

    override fun onViewProfileClicked() {
        view.closeDialog()
        parentPresenter.openProfileView(profileId)
    }

    private fun mapToUiModel(contact: ContactDetailsEntity, isProfileBookmarked: Boolean) =
            UiProfileDialog(contact.name, isProfileBookmarked, contact.biography, contact.imageUrl)

}
