package com.smartimpact.home.ui.maincontent.profile

import android.content.Intent
import com.smartimpact.home.ui.maincontent.profile.model.BaseUiProfileTile
import com.smartimpact.home.ui.maincontent.profile.model.UiProfileHeader

internal interface ProfileView {

    fun showPersonMenu()
    fun showSponsorMenu()
    fun showSelfMenu()  // When viewing your own account

    fun showBookmarkStatus(isBookmarked: Boolean)
    fun showProfileHeader(header: UiProfileHeader)
    fun updateLabels(isSponsor : Boolean)
    fun showProfileDetails(details: List<BaseUiProfileTile>)
    fun showLoading(show: Boolean)
    fun showDivider(show: Boolean)

    fun close()

    fun handleIntent(intent: Intent)
}
