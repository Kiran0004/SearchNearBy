package com.smartimpact.home.ui.maincontent.chat.list.listitem

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageTime

internal class MessageTimeItemLayout(context: Context?, attrs: AttributeSet?) : AppCompatTextView(context, attrs) {

    fun bind(data: UiMessageTime) {
        text = data.timeText
    }

}
