package com.smartimpact.home.ui.maincontent.profile.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.base.ui.widget.ListTile
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.profile.model.*
import si.kamino.adapter.BaseItemsAdapter

internal class ProfileAdapter(private val context: Context, private val itemListener: ProfileAdapterListener) :
        BaseItemsAdapter<BaseUiProfileTile, RecyclerView.ViewHolder>(context) {

    override fun getItemsLayout(viewType: Int): Int {
        return R.layout.item_profile_list_tile
    }

    override fun createViewHolderFromView(view: View, viewType: Int): RecyclerView.ViewHolder {
        return TileViewHolder(view as ListTile)
    }

    override fun doBind(holder: RecyclerView.ViewHolder, model: BaseUiProfileTile, position: Int) {
        (holder as TileViewHolder).bind(model)
    }

    inner class TileViewHolder(private val listTile: ListTile) : RecyclerView.ViewHolder(listTile) {

        fun bind(data: BaseUiProfileTile) {
            data.leadingImageRes()?.let {
                listTile.setLeadingImageResource(it)
            }
            val titleRes = data.titleTextRes()
            listTile.titleText = if (titleRes != null) {
                context.getString(titleRes)
            } else  {
                data.titleText()
            }
            listTile.text = data.text()
            listTile.detailsText = data.detailsText()
            try {
                if(data.trailingText()!=null){
                    var address = data.trailingText()!!.split("@")
                    listTile.trailingText = "*********@"+address[1]
                }else{
                    listTile.trailingText = data.trailingText()
                }
            } catch (e: Exception) {
                listTile.trailingText = data.trailingText()
            }

            listTile.setOnClickListener {
                when (data) {
                    is UiProfileSocialWebsite -> itemListener.onWebsiteClicked(data.website)
                    is UiProfileSocialEmail -> itemListener.onEmailClicked(data.email)
                    is UiProfileSocialTwitter -> itemListener.onTwitterClicked(data.twitter)
                    is UiProfileSocialFacebook -> itemListener.onFacebookClicked(data.facebook)
                    is UiProfileSocialLinkedIn -> itemListener.onLinkedInClicked(data.linkedIn)
                }
            }
        }

    }
}
