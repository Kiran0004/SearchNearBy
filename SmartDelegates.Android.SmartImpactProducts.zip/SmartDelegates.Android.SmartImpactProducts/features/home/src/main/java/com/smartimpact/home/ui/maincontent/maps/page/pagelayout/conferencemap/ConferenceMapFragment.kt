package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import com.smartimpact.home.R
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.model.ConferenceUiSessionDetails
import com.smartimpact.home.ui.maincontent.maps.page.pagelayout.conferencemap.model.UiConferenceDetails
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_conference_map.*
import javax.inject.Inject
import android.widget.ImageView
import android.widget.ZoomControls
import androidx.recyclerview.widget.RecyclerView
import android.webkit.WebViewClient





internal class ConferenceMapFragment : DaggerFragment(), ConferenceMapView {

    @Inject
    internal lateinit var presenter: ConferenceMapPresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    private lateinit var adapter: EventMapListAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_conference_map, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onResume() {
        presenter.onResume()
        super.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun showMap(eventMapUrls: ArrayList<String>) {
        val list = mutableListOf<ConferenceUiSessionDetails>()
        adapter = EventMapListAdapter(eventMapUrls,imageLoader)
        var data = UiConferenceDetails(eventMapUrls)
        list.add(data)
        conferenceRecyclerView.adapter = adapter
        //adapter.setData(list)
        adapter.notifyDataSetChanged()
    }

    companion object {
        fun newInstance(): ConferenceMapFragment {
            return ConferenceMapFragment()
        }
    }
    class EventMapViewHolder(inflater: LayoutInflater, parent: ViewGroup, private var imgloader:ImageLoader) :
            RecyclerView.ViewHolder(inflater.inflate(R.layout.layout_event_map_item_layout, parent, false)) {
        private var ivConferenceImg: WebView
        //private var simpleZoomControl: ZoomControls

        init {
            ivConferenceImg = itemView.findViewById(R.id.ivConferenceMap)
            //simpleZoomControl = itemView.findViewById(R.id.simpleZoomControl)
        }

        fun bind(movie: String) {
            //imgloader.loader(movie,ivConferenceImg,R.drawable.empty_image_placeholder)
            ivConferenceImg.settings.javaScriptEnabled = true
            ivConferenceImg.loadUrl(movie)
            ivConferenceImg.settings.setSupportZoom(true)
            ivConferenceImg.settings.builtInZoomControls = true
            ivConferenceImg.settings.displayZoomControls = true
            ivConferenceImg.settings.domStorageEnabled = true
            ivConferenceImg.settings.useWideViewPort = true
            ivConferenceImg.settings.loadWithOverviewMode = true
            ivConferenceImg.webViewClient = WebViewClient()




//            simpleZoomControl.hide() // initially hide ZoomControls from the screen
//            // perform setOnTouchListener event on ImageView
//            ivConferenceImg.setOnTouchListener(View.OnTouchListener { v, event ->
//                // show Zoom Controls on touch of image
//                simpleZoomControl.show()
//                false
//            })
//            // perform setOnZoomInClickListener event on ZoomControls
//            simpleZoomControl.setOnZoomInClickListener(View.OnClickListener {
//                // calculate current scale x and y value of ImageView
//                val x = ivConferenceImg.scaleX
//                val y = ivConferenceImg.scaleY
//                // set increased value of scale x and y to perform zoom in functionality
//                ivConferenceImg.scaleX = (x+1)
//                ivConferenceImg.scaleY = y+1
//                simpleZoomControl.hide()
//            })
//            // perform setOnZoomOutClickListener event on ZoomControls
//            simpleZoomControl.setOnZoomOutClickListener(View.OnClickListener {
//                // calculate current scale x and y value of ImageView
//                val x = ivConferenceImg.scaleX
//                val y = ivConferenceImg.scaleY
//                // set decreased value of scale x and y to perform zoom out functionality
//                ivConferenceImg.scaleX = x-1
//                ivConferenceImg.scaleY = y-1
//                simpleZoomControl.hide()
//            })
        }

    }
    class EventMapListAdapter(private val list: List<String>, private val imageLoader: ImageLoader)
        : RecyclerView.Adapter<EventMapViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventMapViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val loader = imageLoader
            return EventMapViewHolder(inflater, parent,loader)
        }

        override fun onBindViewHolder(holder: EventMapViewHolder, position: Int) {
            val movie: String = list[position]
            holder.bind(movie)
        }

        override fun getItemCount(): Int = list.size

    }



}
