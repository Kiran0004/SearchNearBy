package com.smartimpact.home.ui.maincontent.notes

internal interface NotesPresenter {
    fun onViewCreated()
    fun onNewNoteClicked()
    fun onDestroyView()
    fun onNoteClicked(noteId: String)
    fun onRetryClicked()
}