package com.smartimpact.home.ui.maincontent.home.sessions.list

import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.home.session.itemlayout.SessionFullItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout

internal interface HomeSessionsAdapterListener :
        AdView.Listener,
        SessionFullItemLayout.Listener,
        SessionSimpleItemLayout.Listener
