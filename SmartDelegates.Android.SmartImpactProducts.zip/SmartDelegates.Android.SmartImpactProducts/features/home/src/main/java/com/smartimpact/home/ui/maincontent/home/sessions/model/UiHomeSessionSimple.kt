package com.smartimpact.home.ui.maincontent.home.sessions.model

import com.smartimpact.home.session.model.UiSessionSimple

internal data class UiHomeSessionSimple(
        val sessionSimple: UiSessionSimple
) : BaseUiHomeSessionModel
