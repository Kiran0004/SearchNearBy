package com.smartimpact.home.session.itemlayout

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.card.MaterialCardView
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.widget.SessionFullView
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.item_session_full.view.*

internal class SessionFullItemLayout(context: Context, attrs: AttributeSet?) : MaterialCardView(context, attrs) {

    private lateinit var listener: Listener
    private lateinit var data: UiSessionFull

    override fun onFinishInflate() {
        super.onFinishInflate()

        setOnClickListener {
            listener.onSessionClicked(data)
        }
    }

    fun inject(listener: Listener, imageLoader: ImageLoader) {
        this.listener = listener

        viSessionFull.setListener(listener)
        viSessionFull.inject(imageLoader)
    }

    fun setData(session: UiSessionFull) {
        this.data = session

        viSessionFull.setData(data)
    }

    interface Listener : SessionFullView.Listener {
        fun onSessionClicked(session: UiSessionFull)
    }

}
