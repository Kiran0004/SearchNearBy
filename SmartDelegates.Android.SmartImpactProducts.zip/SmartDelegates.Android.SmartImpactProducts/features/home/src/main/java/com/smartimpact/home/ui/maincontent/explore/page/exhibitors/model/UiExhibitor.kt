package com.smartimpact.home.ui.maincontent.explore.page.exhibitors.model

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

data class UiExhibitor(
        override val id: String,
        override val imageUrl: String?,
        override val nameText: String?,
        val shortDescriptionText: String?,
        override val isSponsor: Boolean?
) : BaseUiPeopleListPerson() {

    override val bioText: String?
        get() = shortDescriptionText

}
