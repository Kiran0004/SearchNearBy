package com.smartimpact.home.ui.maincontent.allsessions

import android.os.Bundle
import android.view.View
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.AllSessionsPageAdapter
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_all_sessions.*
import javax.inject.Inject

internal class AllSessionsFragment
    : BaseToolbarFragment(), AllSessionsView {

    @Inject internal lateinit var presenter: AllSessionsPresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    @Inject internal lateinit var dateTimeFormatHelper: DateTimeFormatHelper

    private lateinit var pageAdapter: AllSessionsPageAdapter

    override fun layoutRes(): Int {
        return R.layout.fragment_all_sessions
    }

    override fun titleRes(): Int {
        return R.string.sessions_all_sessions
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun toolbar(): MaterialToolbar {
        return allSessionsToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pageAdapter = AllSessionsPageAdapter(dateTimeFormatHelper, childFragmentManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        allSessionsPager.adapter = pageAdapter
        allSessionsPager.offscreenPageLimit = PAGE_LIMIT
        allSessionsTabs.setupWithViewPager(allSessionsPager)
        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun showDays(data: List<UiConferenceDay>) {
        if (data.size > MAX_FIXED_TABS) {
            allSessionsTabs.tabMode = TabLayout.MODE_SCROLLABLE
        } else {
            allSessionsTabs.tabMode = TabLayout.MODE_FIXED
        }
        pageAdapter.setData(data)
    }

    override fun showErrorWithRetry(message: String) {
        showErrorRetrySnackbar(message)
    }

    override fun onSnackbarRetryClicked() {
        presenter.onRetryClicked()
    }

    companion object {
        fun newInstance(): AllSessionsFragment {
            return AllSessionsFragment()
        }

        private const val PAGE_LIMIT = 10
        private const val MAX_FIXED_TABS = 4
    }

}
