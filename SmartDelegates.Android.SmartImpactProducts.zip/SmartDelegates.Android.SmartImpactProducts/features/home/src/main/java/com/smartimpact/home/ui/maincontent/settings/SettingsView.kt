package com.smartimpact.home.ui.maincontent.settings

internal interface SettingsView {

}