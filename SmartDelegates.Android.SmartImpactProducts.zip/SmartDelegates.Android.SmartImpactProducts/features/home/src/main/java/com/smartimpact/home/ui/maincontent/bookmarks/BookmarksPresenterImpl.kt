package com.smartimpact.home.ui.maincontent.bookmarks

import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import javax.inject.Inject

internal class BookmarksPresenterImpl @Inject constructor(
        private val view: BookmarksView,
        private val parentPresenter: MainContentPresenter
) : BookmarksPresenter {

    override fun openPostDetailsView(postId: String) {
        parentPresenter.openPostDetailsView(postId)
    }

    override fun openSessionDetailsView(sessionId: String) {
        parentPresenter.openSessionDetailsView(sessionId)
    }

    override fun openProfileDialog(profileId: String) {
        parentPresenter.openProfileDialog(profileId)
    }

}
