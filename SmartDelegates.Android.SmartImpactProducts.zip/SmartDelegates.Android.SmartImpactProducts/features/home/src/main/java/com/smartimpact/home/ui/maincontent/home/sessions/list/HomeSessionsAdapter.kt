package com.smartimpact.home.ui.maincontent.home.sessions.list

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.session.itemlayout.SessionAdItemLayout
import com.smartimpact.home.session.itemlayout.SessionFullItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout
import com.smartimpact.home.ui.maincontent.home.sessions.model.*
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_session_day.view.*
import si.kamino.adapter.BaseItemsAdapter

internal class HomeSessionsAdapter(
        context: Context,
        private val listener: HomeSessionsAdapterListener,
        private val imageLoader: ImageLoader,
        private val analyticsManager: AnalyticsManager
) : BaseItemsAdapter<BaseUiHomeSessionModel, HomeSessionsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiHomeSessionAd -> TYPE_SESSION_AD
            is UiHomeSessionDay -> TYPE_SESSION_DAY
            is UiHomeSessionFull -> TYPE_SESSION_FULL
            is UiHomeSessionShimmer -> TYPE_SESSION_SHIMMER
            is UiHomeSessionSimple -> TYPE_SESSION_SIMPLE
            is UiHomeSessionTimeline -> TYPE_SESSION_TIMELINE
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_SESSION_AD -> R.layout.item_session_ad
            TYPE_SESSION_DAY -> R.layout.item_session_day
            TYPE_SESSION_FULL -> R.layout.item_session_full
            TYPE_SESSION_SHIMMER -> R.layout.item_session_shimmer
            TYPE_SESSION_SIMPLE -> R.layout.item_session_simple
            TYPE_SESSION_TIMELINE -> R.layout.item_session_timeline
            else -> throw IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_SESSION_AD -> {
                val layout = view as SessionAdItemLayout
                layout.inject(listener, imageLoader, analyticsManager)
                SessionAdVH(layout)
            }
            TYPE_SESSION_DAY -> {
                SessionDayVH(view)
            }
            TYPE_SESSION_FULL -> {
                val layout = view as SessionFullItemLayout
                view.inject(listener, imageLoader)
                SessionFullVH(layout)
            }
            TYPE_SESSION_SHIMMER -> {
                SessionShimmerVH(view)
            }
            TYPE_SESSION_SIMPLE -> {
                val layout = view as SessionSimpleItemLayout
                view.inject(listener)
                SessionSimpleVH(layout)
            }
            TYPE_SESSION_TIMELINE -> {
                NonBindingVH(view)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiHomeSessionModel, position: Int) {
        holder.bind(item)
    }

    fun setData(data: List<BaseUiHomeSessionModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(data)
    }

    fun getDayForPosition(position: Int): UiHomeSessionDay? {
        val before = data.subList(0, position + 1)
        return before.lastOrNull {
            it is UiHomeSessionDay
        } as UiHomeSessionDay?
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiHomeSessionModel)
    }

    private class SessionAdVH(
            override val containerView: SessionAdItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {
            containerView.setData(
                    (item as UiHomeSessionAd).sessionAd
            )
        }
    }

    private class SessionDayVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {
            containerView.tvSessionDay.text = (item as UiHomeSessionDay).dayName
        }
    }

    private class SessionFullVH(
            override val containerView: SessionFullItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {
            containerView.setData(
                    (item as UiHomeSessionFull).sessionFull
            )
        }
    }

    private class SessionShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {}
    }

    private class SessionSimpleVH(
            override val containerView: SessionSimpleItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {
            containerView.setData(
                    (item as UiHomeSessionSimple).sessionSimple
            )
        }
    }

    private class NonBindingVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiHomeSessionModel) {}
    }


    companion object {
        const val TYPE_SESSION_AD = 0
        const val TYPE_SESSION_DAY = 1
        const val TYPE_SESSION_FULL = 2
        const val TYPE_SESSION_SHIMMER = 3
        const val TYPE_SESSION_SIMPLE = 4
        const val TYPE_SESSION_TIMELINE = 5
    }
}
