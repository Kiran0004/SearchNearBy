package com.smartimpact.home.ui.maincontent.newpost

import android.content.Intent
import android.net.Uri
import com.smartimpact.data.contactdetails.ContactDetailsRepository
import com.smartimpact.data.post.PostRepository
import com.smartimpact.home.R
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.photo.PhotoPickerManager
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.flatMapIterable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import java.io.File
import javax.inject.Inject

internal class NewPostPresenterImpl @Inject constructor(
        private val view: NewPostView,
        private val profileManager: ProfileManager,
        private val photoPickerManager: PhotoPickerManager,
        private val messageManager: MessageManager,
        private val contactDetailsRepository: ContactDetailsRepository,
        private val postRepository: PostRepository
) : NewPostPresenter {

    private lateinit var contactId: String
    private var pickedImageUri: Uri? = null

    private val createPostCompositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        try {
            contactId = profileManager.getEventProfileData().eventProfileId
        } catch (e: Throwable) {
            view.close()
        }
    }

    override fun onPostClicked(body: String?) {
        if (body.isNullOrEmpty()) {
            view.enableCreatePost(false)
        } else {
            createPost(body, pickedImageUri)
        }
    }

    override fun onAddPhotoClicked() {
        view.checkStoragePermission()
    }

    override fun onStoragePermissionCheckResult(granted: Boolean) {
        if (granted) {
            view.requestPhotoPicker(photoPickerManager.getPickImageIntent())
        } else {
            view.requestStoragePermission()
        }
    }

    override fun onStoragePermissionGranted() {
        onStoragePermissionCheckResult(true)
    }

    override fun onStoragePermissionNotGranted() {
        messageManager.handlePlainMessage(R.string.post_new_permission)
    }

    override fun onPicturePicked(data: Intent?) {
        pickedImageUri = photoPickerManager.imageResult(data)

        if (pickedImageUri != null) {
            view.setPickedThumbnail(pickedImageUri)
            view.showRemoveImage(true)
        } else {
            messageManager.handlePlainMessage(R.string.post_new_can_not_pick_image)
        }
    }

    override fun onDestroyView() {
        createPostCompositeDisposable.clear()
    }

    override fun onDestroy() {
        createPostCompositeDisposable.dispose()
    }

    override fun onPostTextChanged(text: String?) {
        view.enableCreatePost(!text.isNullOrEmpty())
    }

    override fun onRemovePickedImage() {
        pickedImageUri = null
        view.setPickedThumbnail(pickedImageUri)
        view.showRemoveImage(false)
    }

    private fun createPost(post: String, imageUri: Uri?) {
        view.showLoading(true)

        val path = photoPickerManager.getPath(imageUri)?.path
        val file = if (!path.isNullOrEmpty()) {
            File(path)
        } else {
            null
        }

        createPostCompositeDisposable.clear()

        contactDetailsRepository
                .outObtainOfContactError
                .filter {
                    val id = it.first
                    id == contactId
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy {
                    val error = it.second
                    onCreatePostError(error)
                }
                .addTo(createPostCompositeDisposable)

        contactDetailsRepository.obtainOfContact(contactId)

        contactDetailsRepository
                .outContactDetails
                .observeOn(Schedulers.io())
                .flatMapIterable()
                .filter { contactDetails ->
                    contactDetails.id == contactId
                }
                .firstOrError()
                .flatMapCompletable { contactDetails ->
                    postRepository.createPost(contactDetails, post, file)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onComplete = {
                            onCreatePostSuccess()
                        },
                        onError = {
                            onCreatePostError(it)
                        }
                )
                .addTo(createPostCompositeDisposable)
    }

    private fun onCreatePostError(error: Throwable) {
        createPostCompositeDisposable.clear()
        view.showLoading(false)
        messageManager.handlePlainMessage(error)
    }

    private fun onCreatePostSuccess() {
        createPostCompositeDisposable.clear()
        view.close()
    }

}
