package com.smartimpact.home.ui.maincontent.allposts.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.allposts.model.*

internal class AllPostsDiffUtilCallback(
        private val oldList: List<BaseUiAllPostsModel>,
        private val newList: List<BaseUiAllPostsModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiAllPostsPostAd && newItem is UiAllPostsPostAd ->
                oldItem == newItem
            oldItem is UiAllPostsPostImage && newItem is UiAllPostsPostImage ->
                oldItem.postImage.postId == newItem.postImage.postId
            oldItem is UiAllPostsPostShimmer && newItem is UiAllPostsPostShimmer ->
                true
            oldItem is UiAllPostsPostText && newItem is UiAllPostsPostText ->
                oldItem.postText.postId == newItem.postText.postId
            oldItem is UiAllPostsTime && newItem is UiAllPostsTime ->
                oldItem == newItem
            oldItem is UiAllPostsTimeShimmer && newItem is UiAllPostsTimeShimmer ->
                true
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiAllPostsPostAd && newItem is UiAllPostsPostAd ->
                oldItem == newItem
            oldItem is UiAllPostsPostImage && newItem is UiAllPostsPostImage ->
                oldItem == newItem
            oldItem is UiAllPostsPostShimmer && newItem is UiAllPostsPostShimmer ->
                true
            oldItem is UiAllPostsPostText && newItem is UiAllPostsPostText ->
                oldItem == newItem
            oldItem is UiAllPostsTime && newItem is UiAllPostsTime ->
                oldItem == newItem
            oldItem is UiAllPostsTimeShimmer && newItem is UiAllPostsTimeShimmer ->
                true
            else -> false
        }
    }
}
