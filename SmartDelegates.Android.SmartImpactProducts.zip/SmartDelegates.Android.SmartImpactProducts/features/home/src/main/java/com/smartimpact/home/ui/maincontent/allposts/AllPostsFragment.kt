package com.smartimpact.home.ui.maincontent.allposts

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.core.view.isVisible
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.allposts.list.AllPostsAdapter
import com.smartimpact.home.ui.maincontent.allposts.list.AllPostsAdapterListener
import com.smartimpact.home.ui.maincontent.allposts.list.AllPostsSpaceDecoration
import com.smartimpact.home.ui.maincontent.allposts.model.BaseUiAllPostsModel
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_all_posts.*
import javax.inject.Inject

internal class AllPostsFragment : BaseToolbarFragment(), AllPostsView, AllPostsAdapterListener {

    @Inject internal lateinit var presenter: AllPostsPresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    @Inject internal lateinit var analyticsManager: AnalyticsManager

    private lateinit var postsAdapter: AllPostsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        postsAdapter = AllPostsAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        allPostsRecycler.adapter = postsAdapter
        allPostsRecycler.addItemDecoration(AllPostsSpaceDecoration())

        presenter.onViewCreated()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_all_posts
    }

    override fun titleRes(): Int? {
        return R.string.posts_all_posts
    }

    override fun menuRes(): Int? {
        return R.menu.menu_posts
    }

    override fun toolbar(): MaterialToolbar {
        return allPostsToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return if (item.itemId == R.id.menu_item_new_post) {
            parentPresenter.openNewPostView()
            true
        } else {
            super.onMenuItemClick(item)
        }
    }

    override fun showPosts(posts: List<BaseUiAllPostsModel>) {
        postsAdapter.setData(posts)
    }

    override fun showNoContent(show: Boolean) {
        tvNoContent.isVisible = show
    }

    override fun onAdClicked(adUrl: String) {
        presenter.onPostAdClicked(adUrl)
    }

    override fun onPostClicked(post: UiPostImage) {
        presenter.onPostClicked(post, post.tweetUrl)
    }

    override fun onPostClicked(post: UiPostText) {
        presenter.onPostClicked(post, post.tweetUrl)
    }

    override fun onPostAuthorClicked(postAuthor: UiPostAuthor) {
        presenter.onPostAuthorClicked(postAuthor)
    }

    override fun openWebsite(websiteIntent: Intent?) {
        startActivity(websiteIntent)
    }

    companion object {
        fun newInstance(): AllPostsFragment {
            return AllPostsFragment()
        }
    }

}
