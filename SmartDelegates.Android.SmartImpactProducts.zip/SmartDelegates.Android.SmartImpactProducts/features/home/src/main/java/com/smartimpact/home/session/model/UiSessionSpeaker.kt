package com.smartimpact.home.session.model

internal data class UiSessionSpeaker(
        val speakerId: String,
        val speakerName: String?,
        val speakerDescription: String?,
        val speakerPhotoUrl: String?
)
