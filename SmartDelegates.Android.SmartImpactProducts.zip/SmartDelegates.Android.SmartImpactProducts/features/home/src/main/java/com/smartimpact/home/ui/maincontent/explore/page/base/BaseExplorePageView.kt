package com.smartimpact.home.ui.maincontent.explore.page.base

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListModel

interface BaseExplorePageView {
    fun showContent(show: Boolean)
    fun showPeopleList(list: List<BaseUiPeopleListModel>)
    fun showPeopleList(list: List<BaseUiPeopleListModel>, diffResult: DiffUtil.DiffResult)
}