package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model

import com.smartimpact.home.session.model.UiSessionSimple

internal data class UiBookmarksSessionSimple(
        val sessionSimple: UiSessionSimple
) : BaseUiBookmarksSessionsModel
