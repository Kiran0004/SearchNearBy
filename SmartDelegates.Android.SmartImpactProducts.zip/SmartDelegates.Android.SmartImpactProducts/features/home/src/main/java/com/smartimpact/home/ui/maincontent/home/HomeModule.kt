package com.smartimpact.home.ui.maincontent.home

import dagger.Binds
import dagger.Module

@Module
internal interface HomeModule {

    @Binds
    fun bindView(fragment: HomeFragment): HomeView

    @Binds
    fun bindPresenter(presenterImpl: HomePresenterImpl): HomePresenter

}
