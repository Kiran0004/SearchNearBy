package com.smartimpact.home.ui.maincontent.inbox

import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation

internal interface InboxPresenter  {

    fun onViewCreated(chatId: String?)
    fun onDestroyView()
    fun onConversationClicked(conversation: UiConversation)
    fun onRefresh()
    fun onOpenNewConversation()
}
