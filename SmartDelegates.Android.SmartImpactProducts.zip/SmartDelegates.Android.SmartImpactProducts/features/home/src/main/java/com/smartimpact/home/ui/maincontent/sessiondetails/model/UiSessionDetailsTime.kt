package com.smartimpact.home.ui.maincontent.sessiondetails.model

import com.smartimpact.home.R

internal data class UiSessionDetailsTime(
        val dateText: String,
        val timeText: String
) : BaseUiSessionDetailsTile(
        text = dateText,
        detailsText = timeText
) {

    override fun getLeadingImageResource(): Int {
        return R.drawable.ic_calendar
    }

}
