package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page

import android.content.Intent
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model.BaseUiDaySessionsModel

internal interface DaySessionsPageView {

    fun setData(sessions: List<BaseUiDaySessionsModel>, diffResult: DiffUtil.DiffResult)
    fun openWebsite(websiteIntent: Intent?)

}
