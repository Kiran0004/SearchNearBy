package com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model

internal class UiBookmarksPostShimmer : BaseUiBookmarksPostModel
