package com.smartimpact.home.ui.maincontent.sessiondetails.model

import com.smartimpact.home.R

internal data class UiSessionDetailsLocation(
        val location: String
) : BaseUiSessionDetailsTile(
        text = location
) {

    override fun getLeadingImageResource(): Int {
        return R.drawable.ic_location
    }

}
