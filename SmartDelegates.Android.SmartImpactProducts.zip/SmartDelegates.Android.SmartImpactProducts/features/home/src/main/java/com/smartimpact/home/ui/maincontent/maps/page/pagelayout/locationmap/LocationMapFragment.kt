package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.smartimpact.home.R
import dagger.android.support.DaggerFragment
import javax.inject.Inject

internal class LocationMapFragment : DaggerFragment(), LocationMapView, OnMapReadyCallback {

    @Inject
    internal lateinit var presenter: LocationMapPresenter

    private lateinit var map: GoogleMap

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_location_map, container, false)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onResume() {
        presenter.onResume()
        super.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        presenter.onMapReady()
    }

    override fun showMarker(location: LatLng) {
        map.addMarker(MarkerOptions().position(location))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, ZOOM_LEVEL))
    }

    companion object {
        private const val ZOOM_LEVEL = 15f

        fun newInstance(): LocationMapFragment {
            return LocationMapFragment()
        }
    }
}
