package com.smartimpact.home.ui.maincontent.chat

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.data.inbox.InboxRepository
import com.smartimpact.data.inbox.entity.ChatEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.chat.list.MessageDiffUtilCallback
import com.smartimpact.home.ui.maincontent.chat.model.BaseUiMessageModel
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageReceived
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageSent
import com.smartimpact.home.ui.maincontent.chat.model.UiMessageTime
import com.smartimpact.home.ui.maincontent.chat.model.shimmer.UiMessageRecivedShimmer
import com.smartimpact.home.ui.maincontent.chat.model.shimmer.UiMessageSentShimmer
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import org.threeten.bp.LocalDateTime
import org.threeten.bp.ZoneId
import org.threeten.bp.ZonedDateTime
import javax.inject.Inject

internal class ChatPresenterImpl @Inject constructor(
        private val view: ChatView,
        private val messageManager: MessageManager,
        private val inboxRepository: InboxRepository,
        private val profileManager: ProfileManager,
        private val dateTimeFormatHelper: DateTimeFormatHelper
) : ChatPresenter {

    private var sendDisposable: Disposable? = null

    private val compositeDisposable = CompositeDisposable()

    private val eventId = profileManager.getEventProfileData().eventId
    private val profileId = profileManager.getProfileData().profileId

    private lateinit var contactId: String

    private lateinit var receiverContact: ContactEntity
    private lateinit var chatId: String

    private var data = emptyList<BaseUiMessageModel>()

    private var hasData: Boolean = false

    override fun onViewCreatedContact(contactId: String) {
        this.contactId = contactId

        findChatId(contactId)

        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    findChatId(contactId)
                }
        )

        inboxRepository
                .outInitializationError
                .subscribeBy {
                    messageManager.handleActionableMessage(it)
                }
                .addTo(compositeDisposable)

        inboxRepository
                .outError
                .subscribeBy {
                    messageManager.handlePlainMessage(it)
                }
                .addTo(compositeDisposable)
    }

    private fun listenForChatChanges() {
        inboxRepository.outInbox
                .map { it.find { it.first.id == chatId } }
                .map { it.second }
                .map { chats -> mapToUi(chats) }
                .map { calculateDiff(it, data) }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.setData(it.first, it.second)
                            view.enableSend(true)

                            if (data.size < it.first.size) {
                                view.scrollToLatestMessage(false)
                            }

                            hasData = true
                            data = it.first
                        },
                        onError = {
                            hasData = true
                        }

                ).addTo(compositeDisposable)
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()

        sendDisposable?.dispose()
    }

    override fun onSendClicked(newMessage: String) {
        sendChat(newMessage)
    }

    private fun findChatId(contactId: String) {
        showLoading()
        view.enableSend(false)
        inboxRepository.outInbox
                .map { it.find { it.first.receiver.id == contactId } }
                .firstOrError()
                .map { it.first }
                .onErrorResumeNext {
                    // chat missing create new
                    if (it is NullPointerException) {
                        inboxRepository.createChat(contactId)
                    } else {
                        Single.error(it)
                    }
                }
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = {
                            chatId = it.id
                            receiverContact = it.receiver

                            receiverContact.name?.let { view.updateToolBarTitle(it) }

                            listenForChatChanges()
                        },
                        onError = {
                            messageManager.handleActionableMessage(it)
                        }
                ).addTo(compositeDisposable)
    }

    private fun sendChat(message: String) {
        view.showSendLoading(true)
        sendDisposable?.dispose()
        sendDisposable = inboxRepository.sendMessage(chatId, receiverContact.authAccountId, message)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onComplete = {
                            view.clearNewMessageInput()
                            view.scrollToLatestMessage(true)
                            view.showSendLoading(false)
                        },
                        onError = {
                            view.showSendLoading(false)
                            messageManager.handlePlainMessage(it)
                        }
                )
    }

    private fun showLoading() {
        if (!hasData) {
            data = createShimmers()
            view.setData(data)
        }
    }

    private fun mapToUi(data: List<ChatEntity>): List<BaseUiMessageModel> {
        val list = mutableListOf<BaseUiMessageModel>()

        var lastMessageDateTime = ZonedDateTime.of(LocalDateTime.MIN, ZoneId.systemDefault())

        data.sortedBy { it.createdAt }.forEach {
            if (shouldShowTime(lastMessageDateTime, it.createdAt)) {
                list.add(UiMessageTime(dateTimeFormatHelper.getTimeString(it.createdAt)))
                lastMessageDateTime = it.createdAt
            }
            if (it.isReceiver) {
                list.add(UiMessageReceived(it.id, it.message))

            } else {
                list.add(UiMessageSent(it.id, it.message))
            }
        }

        return list
    }

    private fun calculateDiff(newData: List<BaseUiMessageModel>, oldData: List<BaseUiMessageModel>): Pair<List<BaseUiMessageModel>, DiffUtil.DiffResult> {
        val diffUtil = DiffUtil.calculateDiff(MessageDiffUtilCallback(oldData, newData))
        return Pair(newData, diffUtil)
    }

    private fun shouldShowTime(lastDateTime: ZonedDateTime, currentDateTime: ZonedDateTime): Boolean {
        val differ = currentDateTime.toEpochSecond() - lastDateTime.toEpochSecond()
        return differ > TIME_STAMP_DIFFER
    }

    private fun determineShimmerDelay(): Long {
        return when (hasData) {
            true -> 0L
            false -> SHIMMER_DELAY
        }
    }

    private fun createShimmers(): List<BaseUiMessageModel> {
        return listOf(
                UiMessageRecivedShimmer(),
                UiMessageSentShimmer(),
                UiMessageSentShimmer(),
                UiMessageRecivedShimmer(),
                UiMessageSentShimmer(),
                UiMessageRecivedShimmer(),
                UiMessageRecivedShimmer(),
                UiMessageRecivedShimmer())
    }

    companion object {
        private const val TIME_STAMP_DIFFER = 1000 * 60 * 60

        private const val SHIMMER_DELAY = 400L
    }
}
