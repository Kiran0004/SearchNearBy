package com.smartimpact.home.ui.maincontent.inbox.list

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.inbox.model.BaseUiConversationModel
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversation
import com.smartimpact.home.ui.maincontent.inbox.model.UiConversationShimmer

internal class InboxDiffUtilCallback(
        private val oldList: List<BaseUiConversationModel>,
        private val newList: List<BaseUiConversationModel>
) : DiffUtil.Callback() {

    override fun getOldListSize(): Int {
        return oldList.size
    }

    override fun getNewListSize(): Int {
        return newList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiConversation && newItem is UiConversation ->
                oldItem.conversationId == newItem.conversationId
            oldItem is UiConversationShimmer && newItem is UiConversationShimmer -> true
            else -> false
        }
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldItem = oldList[oldItemPosition]
        val newItem = newList[newItemPosition]
        return when {
            oldItem is UiConversation && newItem is UiConversation -> oldItem == newItem
            oldItem is UiConversationShimmer && newItem is UiConversationShimmer -> true
            else -> false
        }
    }
}