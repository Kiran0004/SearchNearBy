package com.smartimpact.home.ui.maincontent.chat.list

import android.content.Context
import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class MessagesDecoration(
        private val context: Context
) : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        val itemPosition = parent.getChildAdapterPosition(view)

        if (itemPosition == RecyclerView.NO_POSITION) {
            return
        }

        val isFirstItem = itemPosition == 0
        if (isFirstItem) {
            handleFirstItem(outRect)
        }

        if (!isFirstItem) {
            val previousItemType = parent.adapter!!.getItemViewType(itemPosition - 1)
            val thisItemType = parent.adapter!!.getItemViewType(itemPosition)

            when {
                thisItemType == previousItemType ->
                    handleThisItemTypeIsSameAsPreviousItemType(outRect)
                thisItemType != previousItemType ->
                    handleThisItemTypeIsDifferentThanPreviousItemType(outRect)
            }
        }

    }

    private fun handleFirstItem(outRect: Rect) {
        outRect.top = context.resources.getDimensionPixelSize(R.dimen.chat_messages_space_first_item_top)
    }

    private fun handleThisItemTypeIsSameAsPreviousItemType(outRect: Rect) {
        outRect.top = context.resources.getDimensionPixelSize(R.dimen.chat_messages_space_item_to_item_of_same_type)
    }

    private fun handleThisItemTypeIsDifferentThanPreviousItemType(outRect: Rect) {
        outRect.top = context.resources.getDimensionPixelSize(R.dimen.chat_messages_space_item_to_item_of_different_type)
    }

}
