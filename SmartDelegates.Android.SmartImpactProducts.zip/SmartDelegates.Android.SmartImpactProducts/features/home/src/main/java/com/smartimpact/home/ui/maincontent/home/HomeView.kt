package com.smartimpact.home.ui.maincontent.home

import android.content.Intent
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.home.posts.model.BaseUiHomePostModel
import com.smartimpact.home.ui.maincontent.home.sessions.model.BaseUiHomeSessionModel

internal interface HomeView {

    fun showPosts(posts: List<BaseUiHomePostModel>)
    fun showPosts(posts: List<BaseUiHomePostModel>, diffResult: DiffUtil.DiffResult)
    fun showSessions(sessions: List<BaseUiHomeSessionModel>)
    fun showSessions(sessions: List<BaseUiHomeSessionModel>, diffResult: DiffUtil.DiffResult)
    fun sessionScrollToPosition(position: Int)
    fun openWebsite(websiteIntent: Intent?)

}
