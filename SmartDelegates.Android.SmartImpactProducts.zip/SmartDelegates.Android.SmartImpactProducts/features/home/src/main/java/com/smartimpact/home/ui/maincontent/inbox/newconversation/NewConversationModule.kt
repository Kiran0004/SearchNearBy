package com.smartimpact.home.ui.maincontent.inbox.newconversation

import dagger.Binds
import dagger.Module

@Module
internal interface NewConversationModule {

    @Binds
    fun bindView(fragment: NewConversationFragment): NewConversationView

    @Binds
    fun bindPresenter(presenterImpl: NewConversationPresenterImpl): NewConversationPresenter

}


