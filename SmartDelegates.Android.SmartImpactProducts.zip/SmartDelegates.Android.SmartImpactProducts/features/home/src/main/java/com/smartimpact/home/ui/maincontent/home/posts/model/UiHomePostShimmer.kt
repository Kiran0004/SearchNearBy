package com.smartimpact.home.ui.maincontent.home.posts.model

internal class UiHomePostShimmer : BaseUiHomePostModel
