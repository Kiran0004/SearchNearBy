package com.smartimpact.home.ui.maincontent.inbox.model

internal interface BaseUiConversationModel
