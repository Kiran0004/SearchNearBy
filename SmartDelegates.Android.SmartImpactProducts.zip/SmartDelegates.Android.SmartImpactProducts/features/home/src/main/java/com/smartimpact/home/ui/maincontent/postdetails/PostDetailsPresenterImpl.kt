package com.smartimpact.home.ui.maincontent.postdetails

import com.smartimpact.data.bookmarks.BookmarksRepository
import com.smartimpact.data.post.PostRepository
import com.smartimpact.data.post.entity.PostEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.post.mapper.PostUiMapper
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.ui.maincontent.postdetails.model.UiPostDetails
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import javax.inject.Inject

internal class PostDetailsPresenterImpl @Inject constructor(
        private val view: PostDetailsView,
        private val parentPresenter: MainContentPresenter,
        private val messageManager: MessageManager,
        private val bookmarksRepository: BookmarksRepository,
        private val postRepository: PostRepository,
        private val dateTimeFormatHelper: DateTimeFormatHelper,
        private val postUiMapper: PostUiMapper
) : PostDetailsPresenter {

    private lateinit var postId: String

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated(postId: String) {
        this.postId = postId

        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    bookmarksRepository.initialize()
                    postRepository.initialize()
                }
        )

        bookmarksRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        bookmarksRepository
                .outBookmarkedPostIds
                .map { bookmarkedPostIds ->
                    bookmarkedPostIds.contains(postId)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy { isBookmarked ->
                    view.showBookmarkStatus(isBookmarked)
                }
                .addTo(compositeDisposable)

        postRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        postRepository
                .outTopAndAllPosts
                .map { extractPost(it) }
                .map { mapToUiModel(it) }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.showPostDetails(it)
                        },
                        onError = {
                            // post with correct postId could not be found
                            messageManager.handlePlainMessage(it)
                            view.close()
                        }
                )
                .addTo(compositeDisposable)

    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun onToggleBookmarkClicked() {
        bookmarksRepository.togglePostBookmark(postId)
    }

    override fun onPostAuthorClicked(author: UiPostAuthor) {
        parentPresenter.openProfileDialog(author.authorId)
    }

    private fun extractPost(posts: List<PostEntity>): PostEntity {
        return posts.first { post ->
            post.id == postId
        }
    }

    private fun mapToUiModel(postEntity: PostEntity): UiPostDetails {
        val author = postUiMapper.mapAuthor(postEntity.profileReferences)

        return UiPostDetails(
                postEntity.id,
                postEntity.content,
                dateTimeFormatHelper.getTimeString(postEntity.createdOn),
                author,
                postEntity.imageUrl
        )
    }

}
