package com.smartimpact.home.ui.maincontent.maps.page.pagelayout.locationmap

internal interface LocationMapPresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onResume()
    fun onPause()
    fun onMapReady()

}
