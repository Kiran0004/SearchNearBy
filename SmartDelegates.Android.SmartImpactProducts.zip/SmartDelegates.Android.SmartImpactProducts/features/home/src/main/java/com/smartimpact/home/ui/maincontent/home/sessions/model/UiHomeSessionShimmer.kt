package com.smartimpact.home.ui.maincontent.home.sessions.model

class UiHomeSessionShimmer : BaseUiHomeSessionModel
