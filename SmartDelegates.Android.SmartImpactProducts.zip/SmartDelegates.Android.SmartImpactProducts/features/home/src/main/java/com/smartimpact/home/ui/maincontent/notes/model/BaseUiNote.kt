package com.smartimpact.home.ui.maincontent.notes.model

internal interface BaseUiNote