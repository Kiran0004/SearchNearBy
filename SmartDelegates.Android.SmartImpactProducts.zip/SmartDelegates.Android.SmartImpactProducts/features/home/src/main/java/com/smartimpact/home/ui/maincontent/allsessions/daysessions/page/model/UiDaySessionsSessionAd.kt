package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model

import com.smartimpact.home.session.model.UiSessionAd

internal data class UiDaySessionsSessionAd(
        val sessionAd: UiSessionAd
) : BaseUiDaySessionsModel
