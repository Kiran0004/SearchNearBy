package com.smartimpact.home.ui.maincontent.newpost

import android.content.Intent
import android.net.Uri

internal interface NewPostView {

    fun requestPhotoPicker(pickImageIntent: Intent?)
    fun close()
    fun setPickedThumbnail(pickedImageUri: Uri?)
    fun showLoading(show: Boolean)
    fun enableCreatePost(enable: Boolean)
    fun showRemoveImage(show: Boolean)
    fun checkStoragePermission()
    fun requestStoragePermission()

    // TODO error, loading, ...

}
