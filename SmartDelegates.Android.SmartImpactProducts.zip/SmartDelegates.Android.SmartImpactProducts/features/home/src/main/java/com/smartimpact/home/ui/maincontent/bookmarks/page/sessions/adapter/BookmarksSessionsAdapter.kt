package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R
import com.smartimpact.home.session.itemlayout.SessionFullItemLayout
import com.smartimpact.home.session.itemlayout.SessionSimpleItemLayout
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.BaseUiBookmarksSessionsModel
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionFull
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionShimmer
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.UiBookmarksSessionSimple
import com.smartimpact.image.ImageLoader
import kotlinx.android.extensions.LayoutContainer
import si.kamino.adapter.BaseItemsAdapter

internal class BookmarksSessionsAdapter(
        context: Context,
        private val listener: BookmarksSessionsAdapterListener,
        private val imageLoader: ImageLoader
) : BaseItemsAdapter<BaseUiBookmarksSessionsModel, BookmarksSessionsAdapter.BaseVH>(context) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is UiBookmarksSessionFull -> TYPE_SESSION_FULL
            is UiBookmarksSessionShimmer -> TYPE_SESSION_SHIMMER
            is UiBookmarksSessionSimple -> TYPE_SESSION_SIMPLE
            else -> throw IllegalStateException()
        }
    }

    override fun getItemsLayout(viewType: Int): Int {
        return when (viewType) {
            TYPE_SESSION_FULL -> R.layout.item_session_full
            TYPE_SESSION_SHIMMER -> R.layout.item_session_shimmer
            TYPE_SESSION_SIMPLE -> R.layout.item_session_simple
            else -> throw  IllegalStateException()
        }
    }

    override fun createViewHolderFromView(view: View, viewType: Int): BaseVH {
        return when (viewType) {
            TYPE_SESSION_FULL -> {
                val layout = view as SessionFullItemLayout
                layout.inject(listener, imageLoader)
                SessionFullVH(layout)
            }
            TYPE_SESSION_SHIMMER -> {
                SessionShimmerVH(view)
            }
            TYPE_SESSION_SIMPLE -> {
                val layout = view as SessionSimpleItemLayout
                layout.inject(listener)
                SessionSimpleVH(layout)
            }
            else -> throw IllegalStateException()
        }
    }

    override fun doBind(holder: BaseVH, item: BaseUiBookmarksSessionsModel, position: Int) {
        holder.bind(item)
    }

    fun setData(data: List<BaseUiBookmarksSessionsModel>, diffResult: DiffUtil.DiffResult) {
        dispatchDiffUpdates(diffResult)
        setItemQuiet(data)
    }

    internal abstract class BaseVH(
            containerView: View
    ) : RecyclerView.ViewHolder(containerView), LayoutContainer {
        abstract fun bind(item: BaseUiBookmarksSessionsModel)
    }

    private class SessionFullVH(
            override val containerView: SessionFullItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksSessionsModel) {
            containerView.setData(
                    (item as UiBookmarksSessionFull).sessionFull
            )
        }
    }

    private class SessionShimmerVH(
            override val containerView: View
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksSessionsModel) {}
    }

    private class SessionSimpleVH(
            override val containerView: SessionSimpleItemLayout
    ) : BaseVH(containerView) {
        override fun bind(item: BaseUiBookmarksSessionsModel) {
            containerView.setData(
                    (item as UiBookmarksSessionSimple).sessionSimple
            )
        }
    }

    companion object {
        private const val TYPE_SESSION_FULL = 0
        private const val TYPE_SESSION_SHIMMER = 1
        private const val TYPE_SESSION_SIMPLE = 2
    }

}
