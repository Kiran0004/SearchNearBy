package com.smartimpact.home.ui.maincontent.explore.page.exhibitors

import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.contacts.ContactRepository
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.home.ui.maincontent.explore.ExplorePresenter
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenterImpl
import com.smartimpact.home.ui.maincontent.explore.page.exhibitors.model.UiExhibitor
import io.reactivex.Observable
import io.reactivex.Single
import javax.inject.Inject

internal class ExploreExhibitorsPresenterImpl @Inject constructor(
        private val view: ExploreExhibitorsView,
        private val adsRepository: AdsRepository,
        private val contactRepository: ContactRepository,
        private val parentPresenter: ExplorePresenter,
        errorMessageManager: ErrorMessageManager
) : BaseExplorePagePresenterImpl<UiExhibitor>(view, parentPresenter, errorMessageManager, adsRepository), ExploreExhibitorsPresenter {

    override fun onExhibitorClicked(basePerson: BaseUiPeopleListPerson) {
        if(basePerson.isSponsor != null){
            parentPresenter.onPersonClicked(basePerson.id, false, basePerson.isSponsor!!)
        }else{
            parentPresenter.onPersonClicked(basePerson.id, false)
        }
    }

    override fun mapToUi(data: List<ContactEntity>): List<UiExhibitor> {
        return data.map {
            UiExhibitor(it.id,
                    it.imageUrl,
                    it.name,
                    it.description,
                    it.isSponsor)
        }
    }

    override fun searchSingle(query: String?): Single<List<ContactEntity>> {
        return contactRepository.searchSponsors(query)
    }

    override fun dataObservable(): Observable<List<ContactEntity>> {
        return contactRepository.outSponsors
    }

}
