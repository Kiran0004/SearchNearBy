package com.smartimpact.home.ui.maincontent.bookmarks.page.people

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson

internal interface BookmarksPeoplePresenter {

    fun onViewCreated()
    fun onDestroyView()
    fun onDestroy()
    fun onResume()
    fun onPause()
    fun onPersonClicked(person: BaseUiPeopleListPerson)

}
