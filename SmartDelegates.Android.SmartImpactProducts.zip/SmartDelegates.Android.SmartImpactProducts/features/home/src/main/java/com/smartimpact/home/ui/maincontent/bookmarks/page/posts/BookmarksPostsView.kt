package com.smartimpact.home.ui.maincontent.bookmarks.page.posts

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.ui.maincontent.bookmarks.page.posts.model.BaseUiBookmarksPostModel

internal interface BookmarksPostsView {

    fun showBookmarkedPosts(bookmarkedPosts: List<BaseUiBookmarksPostModel>)
    fun showBookmarkedPosts(bookmarkedPosts: List<BaseUiBookmarksPostModel>, diffResult: DiffUtil.DiffResult)
    fun showNoContent(show: Boolean)

}
