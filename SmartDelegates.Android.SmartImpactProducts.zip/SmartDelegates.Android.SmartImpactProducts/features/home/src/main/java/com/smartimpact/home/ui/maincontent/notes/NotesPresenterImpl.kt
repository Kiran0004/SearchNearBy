package com.smartimpact.home.ui.maincontent.notes

import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.base.manager.error.ErrorMessageManager
import com.smartimpact.data.notes.NotesRepository
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.ui.maincontent.notes.list.NoteDiffUtilCallback
import com.smartimpact.home.ui.maincontent.notes.model.BaseUiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNote
import com.smartimpact.home.ui.maincontent.notes.model.UiNoteShimmer
import com.smartimpact.home.ui.maincontent.notes.noteedit.NoteEditFragment
import com.smartimpact.home.ui.maincontent.root.MainContentPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import org.threeten.bp.ZonedDateTime
import java.util.concurrent.TimeUnit
import javax.inject.Inject

internal class NotesPresenterImpl @Inject constructor(
        private val view: NotesView,
        private val parentPresenter: MainContentPresenter,
        private val notesRepository: NotesRepository,
        private val errorMessageManager: ErrorMessageManager,
        private val dateTimeFormatHelper: DateTimeFormatHelper) : NotesPresenter {

    private var disposable: Disposable? = null

    private var previousData: List<BaseUiNote> = listOf()

    private var dataLoaded = false

    override fun onViewCreated() {
        if (!dataLoaded) {
            val shimmerData = getShimmerNotes()
            previousData = shimmerData
            view.setData(shimmerData)
        }

        loadNotes()
    }

    override fun onDestroyView() {
        disposable?.dispose()
    }

    override fun onNewNoteClicked() {
        parentPresenter.openNoteEditView(NoteEditFragment.EMPTY_ID)
    }

    override fun onNoteClicked(noteId: String) {
        parentPresenter.openNoteEditView(noteId)
    }

    override fun onRetryClicked() {
        loadNotes()
    }

    private fun loadNotes() {
        disposable?.dispose()
        disposable = notesRepository.getNotesData()
                .delay(
                        if (dataLoaded) {
                            0L
                        } else {
                            SHIMMER_DELAY
                        }
                        , TimeUnit.MILLISECONDS)
                .map { notes ->
                    notes.map {
                        UiNote(
                                it.noteUuid,
                                it.subject,
                                it.content,
                                dateTimeFormatHelper.getDateTimeDisplayDurationString(it.createdAt, ZonedDateTime.now()))
                    }
                }
                .map {
                    val previousData = previousData
                    val newData = it
                    val diffResult = DiffUtil.calculateDiff(NoteDiffUtilCallback(previousData, newData))
                    Pair(newData, diffResult)
                }
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onNext = {
                            view.setData(it.first, it.second)
                            previousData = it.first
                            dataLoaded = true
                            view.showContent(it.first.isNotEmpty())
                        },
                        onError = {
                            view.showErrorWithRetry(errorMessageManager.getErrorMessage(it))
                        }
                )
    }

    private fun getShimmerNotes(): List<UiNoteShimmer> {
        return (0 until 6).map { UiNoteShimmer() }
    }

    companion object {
        private const val SHIMMER_DELAY = 400L
    }

}
