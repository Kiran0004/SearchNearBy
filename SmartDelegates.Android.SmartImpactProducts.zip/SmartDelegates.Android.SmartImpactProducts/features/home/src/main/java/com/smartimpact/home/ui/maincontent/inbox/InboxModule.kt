package com.smartimpact.home.ui.maincontent.inbox

import dagger.Binds
import dagger.Module

@Module
internal interface InboxModule {

    @Binds
    fun bindView(fragment: InboxFragment): InboxView

    @Binds
    fun bindPresenter(presenterImpl: InboxPresenterImpl): InboxPresenter

}
