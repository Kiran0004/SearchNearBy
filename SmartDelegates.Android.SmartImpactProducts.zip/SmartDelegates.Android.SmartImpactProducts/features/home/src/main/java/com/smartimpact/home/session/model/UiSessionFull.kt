package com.smartimpact.home.session.model

internal data class UiSessionFull(
        val sessionId: String,
        val sessionTitle: String,
        val sessionTime: String,
        val sessionLocation: String?,
        val sessionTags: List<String> = emptyList(),
        val sessionSpeakers: List<UiSessionSpeaker>?,
        val sessionPassed: Boolean
) : BaseUiSessionModel
