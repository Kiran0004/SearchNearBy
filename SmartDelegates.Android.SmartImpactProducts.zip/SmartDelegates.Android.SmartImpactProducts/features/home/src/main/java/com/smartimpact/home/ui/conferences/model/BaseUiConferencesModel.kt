package com.smartimpact.home.ui.conferences.model

internal interface BaseUiConferencesModel
