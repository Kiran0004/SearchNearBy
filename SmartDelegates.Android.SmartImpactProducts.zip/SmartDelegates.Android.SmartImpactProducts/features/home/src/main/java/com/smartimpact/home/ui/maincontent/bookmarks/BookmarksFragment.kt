package com.smartimpact.home.ui.maincontent.bookmarks

import android.os.Bundle
import android.view.View
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.bookmarks.page.BookmarksPageAdapter
import kotlinx.android.synthetic.main.fragment_bookmarks.*
import javax.inject.Inject

internal class BookmarksFragment : BaseDrawerFragment(), BookmarksView {

    @Inject internal lateinit var presenter: BookmarksPresenter

    private lateinit var adapter: BookmarksPageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BookmarksPageAdapter(requireContext(), childFragmentManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewPager.adapter = adapter
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_bookmarks
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_bookmarks
    }

    override fun toolbar(): MaterialToolbar {
        return bookmarksToolbar
    }

    companion object {
        fun newInstance(drawerLayout: DrawerLayout): BookmarksFragment {
            return BookmarksFragment().apply {
                setDrawer(drawerLayout)
            }
        }
    }

}
