package com.smartimpact.home.ui.maincontent.notes.noteedit

import androidx.annotation.StringRes

internal interface NoteEditView {
    fun showData(subject: String, content: String?)
    fun finish()
    fun showErrorMessage(errorMessage: String, retry: Boolean)
    fun showDeleteMenu(show: Boolean)
    fun showDiscardDialog()
    fun showInfoMessage(@StringRes infoRes: Int)

}