package com.smartimpact.home.post

import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.post.mapper.PostUiMapper
import dagger.Module
import dagger.Provides

@Module
internal class PostModule {

    @Provides
    @FragmentScope(FragmentScope.CONTAINER)
    fun providePostUiMapper(dateTimeFormatHelper: DateTimeFormatHelper): PostUiMapper {
        return PostUiMapper(dateTimeFormatHelper)
    }

}
