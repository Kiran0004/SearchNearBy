package com.smartimpact.home.ui.maincontent.home.posts.list

import android.graphics.Rect
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class HomePostsItemDecoration : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        outRect.left = parent.context.resources.getDimensionPixelSize(R.dimen.home_post_margin_left)
        outRect.right = parent.context.resources.getDimensionPixelSize(R.dimen.home_post_margin_right)
    }

}
