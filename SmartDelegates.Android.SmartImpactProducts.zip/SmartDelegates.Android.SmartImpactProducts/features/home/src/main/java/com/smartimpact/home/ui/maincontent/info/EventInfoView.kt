package com.smartimpact.home.ui.maincontent.info

import androidx.annotation.StringRes

interface EventInfoView {
    fun openWebSite(@StringRes urlRes: Int)
    fun sendEmail(@StringRes emailRes: Int)
    fun openAboutEventDialog(eventDescription: String?)

}
