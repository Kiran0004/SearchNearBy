package com.smartimpact.home.ui.maincontent.allposts.list

import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout

internal interface AllPostsAdapterListener :
        AdView.Listener,
        PostImageItemLayout.Listener,
        PostTextItemLayout.Listener
