package com.smartimpact.home.ui.maincontent.allsessions

import com.smartimpact.data.ads.AdsRepository
import com.smartimpact.data.session.SessionRepository
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.messagemanager.lock.ActionableMessagesLock
import com.smartimpact.home.ui.maincontent.allsessions.model.UiConferenceDay
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import org.threeten.bp.Duration
import javax.inject.Inject

internal class AllSessionsPresenterImpl @Inject constructor(
        private val view: AllSessionsView,
        private val messageManager: MessageManager,
        private val profileManager: ProfileManager,
        private val adsRepository: AdsRepository,
        private val sessionRepository: SessionRepository
) : AllSessionsPresenter {

    private var daysDisposable: Disposable? = null

    private val compositeDisposable = CompositeDisposable()

    override fun onViewCreated() {
        messageManager.setActionableMessagesLock(
                ActionableMessagesLock {
                    adsRepository.initialize()
                    sessionRepository.initialize()
                }
        )

        adsRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        adsRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        sessionRepository
                .outInitializationError
                .subscribeBy { messageManager.handleActionableMessage(it) }
                .addTo(compositeDisposable)

        sessionRepository
                .outError
                .subscribeBy { messageManager.handlePlainMessage(it) }
                .addTo(compositeDisposable)

        fetchDays()
    }

    override fun onDestroyView() {
        messageManager.releaseActionableMessagesLock()
        daysDisposable?.dispose()
        compositeDisposable.clear()

    }

    override fun onRetryClicked() {
        daysDisposable?.dispose()
        fetchDays()
    }

    private fun fetchDays() {
        daysDisposable = Single.just(mapDates())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                        onSuccess = { days ->
                            view.showDays(days)
                        },
                        onError = {
                            messageManager.handlePlainMessage(it)
                            view.close()
                        }
                )
    }

    private fun mapDates(): List<UiConferenceDay> {
        val start = profileManager.getEventProfileData().startDate
        val end = profileManager.getEventProfileData().endDate

        val days = Duration.between(start, end).toDays() + 1 // include also end date

        return (0 until days).map {
            val date = start.plusDays(it)
            UiConferenceDay(date)
        }
    }

}
