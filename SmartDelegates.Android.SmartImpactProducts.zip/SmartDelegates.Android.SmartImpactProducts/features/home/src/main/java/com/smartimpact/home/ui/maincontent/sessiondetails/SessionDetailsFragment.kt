package com.smartimpact.home.ui.maincontent.sessiondetails

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.DividerItemDecoration
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import com.smartimpact.home.ui.maincontent.sessiondetails.list.SessionDetailsAdapter
import com.smartimpact.home.ui.maincontent.sessiondetails.list.SessionDetailsItemListener
import com.smartimpact.home.ui.maincontent.sessiondetails.model.BaseUiSessionDetails
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_session_details.*
import javax.inject.Inject

internal class SessionDetailsFragment : BaseToolbarFragment(), SessionDetailsView,
        SessionDetailsItemListener {

    @Inject internal lateinit var presenter: SessionDetailsPresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    private lateinit var adapter: SessionDetailsAdapter

    private lateinit var bookmarkMenuItem: MenuItem

    override fun layoutRes(): Int {
        return R.layout.fragment_session_details
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun menuRes(): Int? {
        return R.menu.menu_session_details
    }

    override fun toolbar(): MaterialToolbar {
        return sessionDetailsToolbar
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.PRIMARY
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = SessionDetailsAdapter(requireContext(), imageLoader, this)

        val sessionId = requireArguments().getString(ARG_SESSION_ID)
                ?: throw IllegalStateException("Session ID cannot be null!")

        presenter.onCreate(sessionId)
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sessionDetailsBackground.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            // Background image and recycler are partially overlaid!
            val overlaySize = requireContext().resources.getDimensionPixelSize(R.dimen.session_details_overlay_size)
            sessionDetailsRecycler.updatePadding(top = (bottom - top - overlaySize))
        }

        bookmarkMenuItem = toolbar().menu.findItem(R.id.menu_item_session_bookmark)

        sessionDetailsRecycler.adapter = adapter
        sessionDetailsRecycler.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_item_session_bookmark -> {
                presenter.onToggleBookmarkClicked()
                true
            }
            else -> false
        }
    }

    override fun showBookmarkStatus(isBookmarked: Boolean) {
        bookmarkMenuItem.isChecked = isBookmarked
        bookmarkMenuItem.setIcon(
                when (isBookmarked) {
                    true -> R.drawable.ic_bookmark_filled
                    false -> R.drawable.ic_bookmark
                }
        )
    }

    override fun showSessionDetails(details: List<BaseUiSessionDetails>) {
        adapter.setData(details)
    }

    override fun onSpeakerClicked(speakerId: String) {
        presenter.onSpeakerClicked(speakerId)
    }

    override fun onAttachmentClicked(attachmentUri: Uri) {
        presenter.onAttachmentClicked(attachmentUri)
    }

    override fun onSessionResponseClicked(response: Int) {
        presenter.onSessionResponseClicked(response)
    }

    override fun checkStoragePermission() {
        val hasPermission = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        presenter.onStoragePermissionCheckResult(hasPermission)
    }

    override fun requestStoragePermission() {
        requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_PERMISSION_STORAGE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_PERMISSION_STORAGE -> {
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    presenter.onStoragePermissionNotGranted()
                } else {
                    presenter.onStoragePermissionGranted()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    companion object {
        private const val ARG_SESSION_ID = "com.smartimpact.home.ui.maincontent.sessiondetails.SessionDetailsFragment.arg_session_id"
        private const val REQUEST_PERMISSION_STORAGE = 1

        fun newInstance(sessionId: String): SessionDetailsFragment {
            return SessionDetailsFragment().apply {
                arguments = bundleOf(ARG_SESSION_ID to sessionId)
            }
        }
    }

}
