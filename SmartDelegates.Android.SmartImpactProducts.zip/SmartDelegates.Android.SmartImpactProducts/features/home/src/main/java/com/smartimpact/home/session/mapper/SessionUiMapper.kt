package com.smartimpact.home.session.mapper

import com.smartimpact.data.ads.entity.AdEntity
import com.smartimpact.data.contacts.entity.ContactEntity
import com.smartimpact.data.session.entity.SessionEntity
import com.smartimpact.datetime.DateTimeFormatHelper
import com.smartimpact.home.session.model.*
import org.threeten.bp.ZonedDateTime

internal class SessionUiMapper(
        private val dateTimeFormatHelper: DateTimeFormatHelper
) {

    fun mapToUi(adEntities: List<AdEntity>): UiSessionAd {
        return UiSessionAd(adEntities)
    }

    fun mapToUi(entity: SessionEntity, currentTime: ZonedDateTime): BaseUiSessionModel {
        return when (entity.sessionType) {
            SessionEntity.SESSION_TYPE_FULL -> mapToUiSessionFull(entity, currentTime)
            SessionEntity.SESSION_TYPE_SIMPLE -> mapToUiSessionSimple(entity, currentTime)
            else -> throw IllegalStateException()
        }
    }

    fun mapToUiModelWith(entity: SessionEntity, currentTime: ZonedDateTime): BaseUiSessionModel {
        return when (entity.sessionType) {
            SessionEntity.SESSION_TYPE_FULL -> mapToUiSessionFullResponse(entity, currentTime)
            SessionEntity.SESSION_TYPE_SIMPLE -> mapToUiSessionSimple(entity, currentTime)
            else -> throw IllegalStateException()
        }
    }

    private fun mapToUiSessionFull(entity: SessionEntity, currentTime: ZonedDateTime): UiSessionFull {
        return UiSessionFull(
                entity.sessionId,
                entity.title,
                dateTimeFormatHelper.getTwoTimeStrings(entity.startAt, entity.endAt),
                entity.location,
                entity.tags,
                mapSpeakers(entity.speakerReferences),
                entity.startAt < currentTime
        )
    }

    private fun mapToUiSessionFullResponse(entity: SessionEntity, currentTime: ZonedDateTime): UiSessionFullResponse {
        val response = when (entity.going) {
            true -> UiSessionFullResponse.RESPONSE_GOING
            false -> UiSessionFullResponse.RESPONSE_NOT_GOING
            else -> UiSessionFullResponse.RESPONSE_NONE
        }
        return UiSessionFullResponse(
                mapToUiSessionFull(entity, currentTime),
                response
        )
    }

    private fun mapToUiSessionSimple(entity: SessionEntity, currentTime: ZonedDateTime): UiSessionSimple {
        return UiSessionSimple(
                entity.sessionId,
                entity.title,
                dateTimeFormatHelper.getTwoTimeStrings(entity.startAt, entity.endAt),
                entity.location,
                entity.startAt < currentTime
        )
    }

    private fun mapSpeakers(speakerReferences: List<ContactEntity>?): List<UiSessionSpeaker> {
        return when (speakerReferences) {
            null -> emptyList()
            else -> speakerReferences.map { mapToUiSessionSpeaker(it) }
        }
    }

    private fun mapToUiSessionSpeaker(entity: ContactEntity): UiSessionSpeaker {
        return UiSessionSpeaker(
                entity.id,
                entity.name,
                entity.description,
                entity.imageUrl
        )
    }

}
