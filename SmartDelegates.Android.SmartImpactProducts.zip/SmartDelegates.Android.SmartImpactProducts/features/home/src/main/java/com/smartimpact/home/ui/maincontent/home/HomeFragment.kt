package com.smartimpact.home.ui.maincontent.home

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.PagerSnapHelper
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.analytics.AnalyticsManager
import com.smartimpact.home.R
import com.smartimpact.home.post.model.UiPostAuthor
import com.smartimpact.home.post.model.UiPostImage
import com.smartimpact.home.post.model.UiPostText
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.home.posts.list.HomePostsAdapter
import com.smartimpact.home.ui.maincontent.home.posts.list.HomePostsAdapterListener
import com.smartimpact.home.ui.maincontent.home.posts.list.HomePostsItemDecoration
import com.smartimpact.home.ui.maincontent.home.posts.model.BaseUiHomePostModel
import com.smartimpact.home.ui.maincontent.home.sessions.list.HomeSessionsAdapter
import com.smartimpact.home.ui.maincontent.home.sessions.list.HomeSessionsAdapterListener
import com.smartimpact.home.ui.maincontent.home.sessions.list.HomeSessionsItemDecoration
import com.smartimpact.home.ui.maincontent.home.sessions.model.BaseUiHomeSessionModel
import com.smartimpact.image.ImageLoader
import kotlinx.android.synthetic.main.fragment_home.*
import javax.inject.Inject

internal class HomeFragment
    : BaseDrawerFragment(),
        HomeView,
        HomePostsAdapterListener,
        HomeSessionsAdapterListener {

    @Inject internal lateinit var presenter: HomePresenter

    @Inject internal lateinit var imageLoader: ImageLoader

    @Inject internal lateinit var analyticsManager: AnalyticsManager

    private lateinit var postsAdapter: HomePostsAdapter
    private lateinit var sessionsAdapter: HomeSessionsAdapter

    private var motionLayoutCurrent: Int = R.id.scene_home_collapsed

    override fun layoutRes(): Int {
        return R.layout.fragment_home
    }

    override fun menuRes(): Int? {
        return R.menu.menu_home
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun toolbar(): MaterialToolbar {
        return toolbar
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        postsAdapter = HomePostsAdapter(requireContext(), this, imageLoader, analyticsManager)
        sessionsAdapter = HomeSessionsAdapter(requireContext(), this, imageLoader, analyticsManager)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        motionLayout.setViewSelection(listOf(homeSessionBackdrop, homeSessionRecycler))
        when (motionLayoutCurrent) {
            R.id.scene_home_expanded -> {
                motionLayout.transitionToEnd()
            }
        }

        setupPostsRecycler()
        setupSessionsRecycler()

        btnHomePostsSeeAll.setOnClickListener {
            presenter.onAllPostsClicked()
        }
        btnHomeSessionsAll.setOnClickListener {
            presenter.onAllSessionsClicked()
        }

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        motionLayoutCurrent = if (motionLayout.progress > BACKDROP_EXPANDED) {
            R.id.scene_home_expanded
        } else {
            R.id.scene_home_collapsed
        }

        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    private fun setupPostsRecycler() {
        homePostsRecycler.adapter = postsAdapter
        homePostsRecycler.addItemDecoration(HomePostsItemDecoration())
        PagerSnapHelper().attachToRecyclerView(homePostsRecycler)
    }

    private fun setupSessionsRecycler() {
        homeSessionRecycler.adapter = sessionsAdapter
        homeSessionRecycler.addItemDecoration(HomeSessionsItemDecoration(requireContext()))
        homeSessionRecycler.itemAnimator = null
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return if (item.itemId == R.id.menu_item_new_post) {
            parentPresenter.openNewPostView()
            true
        } else {
            super.onMenuItemClick(item)
        }
    }

    override fun showPosts(posts: List<BaseUiHomePostModel>) {
        postsAdapter.setData(posts)
    }

    override fun showPosts(posts: List<BaseUiHomePostModel>, diffResult: DiffUtil.DiffResult) {
        postsAdapter.setData(posts, diffResult)
    }

    override fun showSessions(sessions: List<BaseUiHomeSessionModel>) {
        sessionsAdapter.setData(sessions)
    }

    override fun showSessions(sessions: List<BaseUiHomeSessionModel>, diffResult: DiffUtil.DiffResult) {
        sessionsAdapter.setData(sessions, diffResult)
    }

    override fun sessionScrollToPosition(position: Int) {
        homeSessionRecycler.scrollToPosition(position)
    }

    override fun onAdClicked(adUrl: String) {
        presenter.onAdClicked(adUrl)
    }

    override fun onPostClicked(post: UiPostImage) {
        presenter.onPostClicked(post)
    }

    override fun onPostClicked(post: UiPostText) {
        presenter.onPostClicked(post)
    }

    override fun onPostAuthorClicked(postAuthor: UiPostAuthor) {
        presenter.onPostAuthorClicked(postAuthor)
    }

    override fun onSessionClicked(session: UiSessionFull) {
        presenter.onSessionFullClicked(session)
    }

    override fun onSessionClicked(session: UiSessionSimple) {
        presenter.onSessionSimpleClicked(session)
    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        presenter.onSessionSpeakersClicked(sessionId, speakers)
    }

    override fun openWebsite(websiteIntent: Intent?) {
        startActivity(websiteIntent)
    }

    companion object {
        private const val BACKDROP_EXPANDED = 0.8f

        fun newInstance(drawerLayout: DrawerLayout): HomeFragment {
            return HomeFragment().apply {
                setDrawer(drawerLayout)
            }
        }
    }
}
