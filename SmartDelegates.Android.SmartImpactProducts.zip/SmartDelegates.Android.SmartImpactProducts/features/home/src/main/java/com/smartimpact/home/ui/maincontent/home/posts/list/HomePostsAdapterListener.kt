package com.smartimpact.home.ui.maincontent.home.posts.list

import com.smartimpact.base.ui.widget.ads.AdView
import com.smartimpact.home.post.itemlayout.PostImageItemLayout
import com.smartimpact.home.post.itemlayout.PostTextItemLayout

internal interface HomePostsAdapterListener :
        AdView.Listener,
        PostImageItemLayout.Listener,
        PostTextItemLayout.Listener
