package com.smartimpact.home.ui.maincontent.info

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartimpact.home.R
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import kotlinx.android.synthetic.main.fragment_event_info.*
import javax.inject.Inject

internal class EventInfoFragment : BaseDrawerFragment(), EventInfoView {

    @Inject internal lateinit var presenter: EventInfoPresenter

    @Inject internal lateinit var socialIntentManager: SocialIntentManager

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnAboutEvent.setOnClickListener {
            presenter.onAboutEventClicked()
        }
        btnContactOrganizers.setOnClickListener {
            presenter.onContactOrganizersClicked()
        }
        btnHelp.setOnClickListener {
            presenter.onHelpClicked()
        }
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_event_info
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_event_info
    }

    override fun toolbar(): MaterialToolbar {
        return eventInfoToolbar
    }

    override fun openWebSite(@StringRes urlRes: Int) {
        val intent = socialIntentManager.getWebsiteIntent(resources.getString(urlRes))
        startActivity(intent)
    }

    override fun sendEmail(@StringRes emailRes: Int) {
        val intent = socialIntentManager.getEmailIntent(resources.getString(emailRes))
        startActivity(intent)
    }

    override fun openAboutEventDialog(eventDescription: String?) {
        MaterialAlertDialogBuilder(context, R.style.SmartImpact_Dialog).apply {
            setTitle(R.string.event_info_about_event)
            setMessage(eventDescription)
            setNegativeButton(R.string.event_info_close) { dialogInterface, _ ->
                dialogInterface.dismiss()
            }
        }.show()
    }

    companion object {
        fun newInstance(drawerLayout: DrawerLayout): EventInfoFragment {
            return EventInfoFragment().apply {
                setDrawer(drawerLayout)
            }
        }
    }

}
