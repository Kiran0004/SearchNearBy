package com.smartimpact.home.ui.maincontent.profile.model

import com.smartimpact.home.R

internal data class UiProfileSocialWebsite(val website: String) : BaseUiProfileSocialTile {

    override fun leadingImageRes(): Int? {
        return R.drawable.ic_url
    }

    override fun titleTextRes(): Int? {
        return R.string.social_website
    }

    override fun trailingText(): String? {
        return website
    }
}
