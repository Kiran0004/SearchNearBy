package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions

import dagger.Binds
import dagger.Module

@Module
internal interface BookmarksSessionsModule {

    @Binds
    fun bindView(fragment: BookmarksSessionsFragment): BookmarksSessionsView

    @Binds
    fun bindPresenter(presenterImpl: BookmarksSessionsPresenterImpl): BookmarksSessionsPresenter

}
