package com.smartimpact.home.session.model

internal interface BaseUiSessionModel
