package com.smartimpact.home.ui.maincontent.profile.model

import com.smartimpact.home.R

internal data class UiProfileSocialEmail(val email: String) : BaseUiProfileSocialTile {

    override fun leadingImageRes(): Int? {
        return R.drawable.ic_email
    }

    override fun titleTextRes(): Int? {
        return R.string.social_email
    }

    override fun trailingText(): String? {
        return email
    }
}
