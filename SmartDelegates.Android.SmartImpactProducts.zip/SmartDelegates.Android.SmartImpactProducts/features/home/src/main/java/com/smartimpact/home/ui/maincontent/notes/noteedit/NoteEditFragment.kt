package com.smartimpact.home.ui.maincontent.notes.noteedit

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.core.os.bundleOf
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartimpact.home.R
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.home.ui.base.fragment.BaseToolbarFragment
import kotlinx.android.synthetic.main.fragment_note_edit.*
import javax.inject.Inject

internal class NoteEditFragment : BaseToolbarFragment(), NoteEditView {

    @Inject internal lateinit var presenter: NoteEditPresenter

    private var discardDialog: AlertDialog? = null

    override fun toolbar(): MaterialToolbar {
        return noteEditToolbar
    }

    override fun menuRes(): Int? {
        return R.menu.menu_note_edit
    }

    override fun titleRes(): Int? {
        return null
    }

    override fun layoutRes(): Int {
        return R.layout.fragment_note_edit
    }

    override fun statusBarMode(): StatusBarMode {
        return StatusBarMode.SECONDARY
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val noteId = arguments?.getString(ARG_NOTE_ID)

        presenter.onViewCreated(noteId)
    }

    override fun onDestroyView() {
        discardDialog?.dismiss()
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onBackPressed() {
        presenter.onBackPressed(etSubject.text.toString(), etNote.text.toString())
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_note_delete -> presenter.onDeleteClicked()
            R.id.item_note_save -> presenter.onSaveClicked(etSubject.text.toString(), etNote.text.toString())
        }

        return true
    }

    override fun showData(subject: String, content: String?) {
        etSubject.setText(subject)
        etNote.setText(content)
    }

    override fun showErrorMessage(errorMessage: String, retry: Boolean) {
        if (retry) {
            showErrorRetrySnackbar(errorMessage)
        } else {
            showSnackbar(errorMessage)
        }
    }

    override fun onSnackbarRetryClicked() {
        presenter.onSnackbarRetryClicked()
    }

    override fun showDeleteMenu(show: Boolean) {
        noteEditToolbar.menu.findItem(R.id.item_note_delete).isVisible = show
    }

    override fun finish() {
        close()
    }

    override fun showDiscardDialog() {
        discardDialog = MaterialAlertDialogBuilder(context, R.style.SmartImpact_Dialog)
                .setTitle(R.string.notes_edit_discard_title)
                .setMessage(R.string.notes_edit_discard_message)
                .setPositiveButton(R.string.notes_edit_discard_discard) { _, _ ->
                    presenter.onDiscardClicked()
                }
                .setNegativeButton(R.string.notes_edit_discard_save) { _, _ ->
                    presenter.onSaveClicked(etSubject.text.toString(), etNote.text.toString())
                }
                .setNeutralButton(R.string.notes_edit_discard_cancel, null)
                .show()
    }

    override fun showInfoMessage(@StringRes infoRes: Int) {
        showSnackbar(infoRes)
    }

    companion object {
        private const val ARG_NOTE_ID = "com.smartimpact.home.ui.maincontent.notes.noteeditNoteEditFragment.noteId"

        const val EMPTY_ID = "none"

        fun newInstance(noteId: String = EMPTY_ID): NoteEditFragment {
            return NoteEditFragment()
                    .apply {
                        arguments = bundleOf(ARG_NOTE_ID to noteId)
                    }
        }
    }

}