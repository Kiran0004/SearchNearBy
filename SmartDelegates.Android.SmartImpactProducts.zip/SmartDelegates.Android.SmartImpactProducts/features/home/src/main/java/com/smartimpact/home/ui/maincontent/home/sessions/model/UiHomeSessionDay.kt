package com.smartimpact.home.ui.maincontent.home.sessions.model

internal data class UiHomeSessionDay(
        val id: Int,
        val dayName: String,
        val shortDayName: String,
        val dayNumber: String
) : BaseUiHomeSessionModel
