package com.smartimpact.home.ui.maincontent.bookmarks.page.sessions

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import com.smartimpact.home.R
import com.smartimpact.home.session.model.UiSessionFull
import com.smartimpact.home.session.model.UiSessionSimple
import com.smartimpact.home.session.model.UiSessionSpeaker
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter.BookmarksSessionsAdapter
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter.BookmarksSessionsAdapterListener
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.adapter.BookmarksSessionsItemDecoration
import com.smartimpact.home.ui.maincontent.bookmarks.page.sessions.model.BaseUiBookmarksSessionsModel
import com.smartimpact.image.ImageLoader
import dagger.android.support.DaggerFragment
import kotlinx.android.synthetic.main.fragment_bookmarks_sessions.*
import javax.inject.Inject


internal class BookmarksSessionsFragment : DaggerFragment(), BookmarksSessionsView, BookmarksSessionsAdapterListener {

    private lateinit var adapter: BookmarksSessionsAdapter

    @Inject
    internal lateinit var presenter: BookmarksSessionsPresenter

    @Inject
    internal lateinit var imageLoader: ImageLoader

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_bookmarks_sessions, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapter = BookmarksSessionsAdapter(requireContext(), this, imageLoader)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.adapter = adapter
        recycler.addItemDecoration(BookmarksSessionsItemDecoration())

        presenter.onViewCreated()
    }

    override fun onDestroyView() {
        presenter.onDestroyView()
        super.onDestroyView()
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    override fun onResume() {
        presenter.onResume()
        super.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun showBookmarkedSessions(bookmarkedSessions: List<BaseUiBookmarksSessionsModel>) {
        adapter.setData(bookmarkedSessions)
    }

    override fun showBookmarkedSessions(bookmarkedSessions: List<BaseUiBookmarksSessionsModel>, diffResult: DiffUtil.DiffResult) {
        adapter.setData(bookmarkedSessions, diffResult)
    }

    override fun showNoContent(show: Boolean) {
        tvNoContent.isVisible = show
    }

    override fun onSessionClicked(session: UiSessionFull) {
        presenter.onSessionFullClicked(session)
    }

    override fun onSessionClicked(session: UiSessionSimple) {
        presenter.onSessionSimpleClicked(session)
    }

    override fun onSessionSpeakersClicked(sessionId: String, speakers: List<UiSessionSpeaker>) {
        presenter.onSessionSpeakersClicked(sessionId, speakers)
    }

    companion object {
        fun newInstance(): BookmarksSessionsFragment {
            return BookmarksSessionsFragment()
        }
    }

}
