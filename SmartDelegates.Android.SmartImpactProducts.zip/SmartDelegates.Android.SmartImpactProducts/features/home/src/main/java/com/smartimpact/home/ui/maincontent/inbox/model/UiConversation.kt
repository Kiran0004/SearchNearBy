package com.smartimpact.home.ui.maincontent.inbox.model

internal data class UiConversation(
        val conversationId: String,
        val conversationPartnerImageUrl: String?,
        val lastMessageTimeText: String,
        val areAllMessagesRead: Boolean,
        val conversationPartnerNameText: String?,
        val lastMessagePreviewText: String?,
        val partnerId: String
) : BaseUiConversationModel
