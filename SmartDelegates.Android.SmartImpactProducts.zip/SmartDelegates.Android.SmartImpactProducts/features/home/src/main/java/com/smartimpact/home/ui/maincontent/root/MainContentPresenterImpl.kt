package com.smartimpact.home.ui.maincontent.root

import android.net.Uri
import com.smartimpact.api.ApiService
import com.smartimpact.base.manager.pushnotification.InAppPushNotificationManager
import com.smartimpact.data.inbox.InboxRepository
import com.smartimpact.home.eventmanager.EventManager
import com.smartimpact.base.intent.SocialIntentManager
import com.smartimpact.base.messagemanager.MessageManager
import com.smartimpact.base.ui.StatusBarMode
import com.smartimpact.base.ui.MainContentParentPresenter
import com.smartimpact.base.ui.navigation.model.UiProfileShort
import com.smartimpact.userprofile.manager.ProfileManager
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class MainContentPresenterImpl @Inject constructor(
        private val view: MainContentView,
        private val parentPresenter: MainContentParentPresenter,
        private val profileManager: ProfileManager,
        private val eventManager: EventManager,
        private val messageManager: MessageManager,
        private val inboxRepository: InboxRepository,
        private val inAppPushNotificationManager: InAppPushNotificationManager,
        private val apiService: ApiService,
        private val intentManager: SocialIntentManager
) : MainContentPresenter, InAppPushNotificationManager.InAppPushNotificationListener {

    private val compositeDisposable = CompositeDisposable()

    private var inboxDisposable: Disposable? = null

    override fun onViewCreated(chatId: String?) {
        messageManager.apply {
            outShowPlainMessage
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeBy {
                        view.showPlainMessage(it)
                    }
                    .addTo(compositeDisposable)

            outShowActionableMessage
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeBy {
                        view.showActionableMessage(it)
                    }
                    .addTo(compositeDisposable)

            outDismissMessage
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeBy {
                        view.dismissMessage()
                    }
                    .addTo(compositeDisposable)
        }

        if (profileManager.hasSelectedEvent()) {
            loadProfile()
            if (chatId != null) {
                view.showInboxView(chatId)
            } else {
                view.showHomeView()
            }
        } else {
            view.openSelectEventView()
        }

        inAppPushNotificationManager.registerInAppPushNotificationListener(this)

    }

    override fun onDestroyView() {
        inAppPushNotificationManager.unregisterInAppPushNotificationListener(this)

        eventManager.dispose()

        inboxDisposable?.dispose()
        compositeDisposable.clear()
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

    override fun openOnboardingView() {
        parentPresenter.openOnboardingView()
    }

    override fun openChatViewForContact(contactId: String) {
        view.openChatViewForContact(contactId)
    }

    override fun openProfileView(profileId: String, isSponsor : Boolean) {
        view.openProfileView(profileId, isSponsor)
    }

    override fun openAllPostsView() {
        view.openAllPostsView()
    }

    override fun openAllSessionsView() {
        view.openAllSessionsView()
    }

    override fun openNoteEditView(noteId: String) {
        view.openNoteEditView(noteId)
    }

    override fun showHomeView() {
        view.showHomeView()
    }

    override fun showInboxView() {
        view.showInboxView(null)
    }

    override fun showExploreView() {
        view.showExploreView()
    }

    override fun showNotesView() {
        view.showNotesView()
    }

    override fun showMapsView() {
        view.showMapsView()
    }

    override fun openProfileDialog(profileId: String) {
        view.openProfileDialog(profileId)
    }

    override fun openProfileEditView() {
        view.openProfileEditView()
    }

    override fun openPostDetailsView(postId: String, tweetUrl: String?) {
        view.openPostDetailsView(postId, tweetUrl)
    }

    override fun openNewPostView() {
        view.openNewPostView()
    }

    override fun openSessionDetailsView(sessionId: String) {
        view.openSessionDetailsView(sessionId)
    }

    override fun openNewConversationView() {
        view.openNewConversationView()
    }

    override fun updateStatusBar(mode: StatusBarMode) {
        parentPresenter.updateStatusBar(mode)
    }

    override fun lockDrawer(lock: Boolean) {
        view.lockDrawer(lock)
    }

    override fun backToAppChoiceView() {
        parentPresenter.openAppChoiceView()
    }

    override fun onNewEventSelected() {
        loadProfile()
        eventManager.refresh()
        view.showHomeView()
    }

    override fun onNavigationProfileClicked() {
        view.closeDrawer()
        view.openProfileView(profileManager.getEventProfileData().eventProfileId, false)
    }

    override fun onNavigationEditProfileClicked() {
        view.closeDrawer()
        view.openProfileEditView()
    }

    override fun onDrawerOpened() {
        val eventId = profileManager.getEventProfileData().eventId
        val profileId = profileManager.getProfileData().profileId

        inboxDisposable?.dispose()
//        inboxDisposable = Observable.interval(0, REFRESH_NEW_MESSAGE, TimeUnit.MILLISECONDS)
//                .flatMap {
//                    inboxRepository.allMessagesRead(eventId, profileId)
//                            .toObservable()
//                }
//                .distinctUntilChanged()
//                .retryWhen { it.delay(REFRESH_NEW_MESSAGE, TimeUnit.MILLISECONDS) }
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribeBy(
//                        onNext = {
//                            view.showNavigationItems(!it)
//                        },
//                        onError = {
//                            // ignore
//                        }
//                )
    }

    override fun onDrawerClosed() {
        inboxDisposable?.dispose()
    }


    override fun onPushReceived(chatId: String) {
        inboxRepository.newMessageReceived(chatId)
    }

    override fun reloadProfileData(uri: Uri?) {
        loadProfile(uri)
    }

    private fun loadProfile(uri: Uri?) {
        val data = profileManager.getProfileData()
        if(uri!=null){
            view.showProfileUri(UiProfileShort(data.name, data.imageUrl),uri)
        }else{
            view.showProfile(UiProfileShort(data.name, data.imageUrl))
        }

        view.showNavigationItems(false)
    }



    private fun loadProfile() {
        val data = profileManager.getProfileData()
        view.showProfile(UiProfileShort(data.name, data.imageUrl))
        view.showNavigationItems(false)

        // refresh event data
        if (profileManager.hasSelectedEvent()) {
            // todo add to repository
            apiService.getEvent(profileManager.getEventProfileData().eventId)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeBy(
                            onSuccess = {
                                profileManager.updateEventData(it.startDate, it.endDate, it.latitude, it.longitude, it.description)
                            },
                            onError = {
                                // ignore don't update cached data
                            }
                    ).addTo(compositeDisposable)
        }
    }

    override fun openTweet(tweetUrl: String?) {
        val intent = intentManager.getTweetUrlIntent(tweetUrl)
        if (intent == null) {
            // TODO
        } else {
            view.handleIntent(intent)
        }
    }

    companion object {
        private const val REFRESH_NEW_MESSAGE = 4000L
    }

}
