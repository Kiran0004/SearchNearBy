package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page

import dagger.Binds
import dagger.Module

@Module
internal interface DaySessionsPageModule {

    @Binds fun bindView(fragment: DaySessionsPageFragment): DaySessionsPageView

    @Binds fun bindPresenter(presenterImpl: DaySessionsPagePresenterImpl): DaySessionsPagePresenter

}
