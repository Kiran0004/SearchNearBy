package com.smartimpact.home.ui.maincontent.sessiondetails.model

internal data class UiSessionDetailsHeader(
        val sessionTitle: String,
        val sessionTags: List<String>
) : BaseUiSessionDetails
