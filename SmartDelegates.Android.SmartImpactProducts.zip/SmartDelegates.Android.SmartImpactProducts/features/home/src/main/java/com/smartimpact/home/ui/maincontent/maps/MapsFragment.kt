package com.smartimpact.home.ui.maincontent.maps

import android.os.Bundle
import android.view.View
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.MaterialToolbar
import com.smartimpact.home.R
import com.smartimpact.home.ui.base.fragment.BaseDrawerFragment
import com.smartimpact.home.ui.maincontent.maps.page.MapsPageAdapter
import kotlinx.android.synthetic.main.fragment_maps.*
import javax.inject.Inject

internal class MapsFragment : BaseDrawerFragment(), MapsView {

    @Inject internal lateinit var presenter: MapsPresenter

    private lateinit var adapter: MapsPageAdapter

    override fun layoutRes(): Int {
        return R.layout.fragment_maps
    }

    override fun toolbar(): MaterialToolbar {
        return mapsToolbar
    }

    override fun menuRes(): Int? {
        return null
    }

    override fun titleRes(): Int? {
        return R.string.nav_drawer_maps
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        this.adapter = MapsPageAdapter(requireContext(), childFragmentManager)
        viewPager.adapter = adapter
        tabs.setupWithViewPager(viewPager)
    }

    companion object {
        fun newInstance(drawerLayout: DrawerLayout): MapsFragment {
            return MapsFragment().apply {
                setDrawer(drawerLayout)
            }
        }
    }
}
