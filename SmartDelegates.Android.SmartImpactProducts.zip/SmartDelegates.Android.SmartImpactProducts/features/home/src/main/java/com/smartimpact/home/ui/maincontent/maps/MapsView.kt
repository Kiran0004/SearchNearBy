package com.smartimpact.home.ui.maincontent.maps

internal interface MapsView {

}