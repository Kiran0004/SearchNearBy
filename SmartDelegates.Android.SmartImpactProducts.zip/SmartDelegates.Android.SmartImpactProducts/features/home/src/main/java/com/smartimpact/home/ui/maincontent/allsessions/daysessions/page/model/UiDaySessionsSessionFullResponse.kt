package com.smartimpact.home.ui.maincontent.allsessions.daysessions.page.model

import com.smartimpact.home.session.model.UiSessionFullResponse

internal data class UiDaySessionsSessionFullResponse(
        val sessionFullResponse: UiSessionFullResponse
) : BaseUiDaySessionsModel
