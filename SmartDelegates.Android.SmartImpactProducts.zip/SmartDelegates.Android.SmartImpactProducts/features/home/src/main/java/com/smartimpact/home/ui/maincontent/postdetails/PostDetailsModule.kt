package com.smartimpact.home.ui.maincontent.postdetails

import dagger.Binds
import dagger.Module

@Module
internal interface PostDetailsModule {

    @Binds fun bindView(fragment: PostDetailsFragment): PostDetailsView

    @Binds fun bindPresenter(presenterImpl: PostDetailsPresenterImpl): PostDetailsPresenter

}
