package com.smartimpact.home.ui.maincontent.allposts.list

import android.graphics.Rect
import androidx.recyclerview.widget.RecyclerView
import com.smartimpact.home.R

internal class AllPostsSpaceDecoration : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, itemPosition: Int, parent: RecyclerView) {
        when (parent.adapter?.getItemViewType(itemPosition)) {
            AllPostsAdapter.TYPE_POST_AD,
            AllPostsAdapter.TYPE_POST_TEXT,
            AllPostsAdapter.TYPE_POST_IMAGE,
            AllPostsAdapter.TYPE_POST_SHIMMER ->
                handlePostOffsets(outRect, parent)
            AllPostsAdapter.TYPE_TIME, AllPostsAdapter.TYPE_TIME_SHIMMER ->
                handleTimeOffsets(outRect, parent)
        }
    }

    private fun handlePostOffsets(outRect: Rect, parent: RecyclerView) {
        outRect.top = parent.context.resources.getDimensionPixelSize(R.dimen.post_margin_top)
        outRect.bottom = parent.context.resources.getDimensionPixelSize(R.dimen.post_margin_bottom)
        outRect.left = parent.context.resources.getDimensionPixelSize(R.dimen.post_margin_left)
        outRect.right = parent.context.resources.getDimensionPixelSize(R.dimen.post_margin_right)
    }

    private fun handleTimeOffsets(outRect: Rect, parent: RecyclerView) {
        outRect.top = parent.context.resources.getDimensionPixelSize(R.dimen.post_time_margin_top)
        outRect.bottom = parent.context.resources.getDimensionPixelSize(R.dimen.post_time_margin_bottom)
        outRect.left = parent.context.resources.getDimensionPixelSize(R.dimen.post_time_margin_left)
        outRect.right = parent.context.resources.getDimensionPixelSize(R.dimen.post_time_margin_right)
    }
}
