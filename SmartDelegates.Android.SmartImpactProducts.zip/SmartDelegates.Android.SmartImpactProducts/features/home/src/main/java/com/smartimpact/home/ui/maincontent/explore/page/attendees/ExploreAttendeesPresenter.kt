package com.smartimpact.home.ui.maincontent.explore.page.attendees

import com.smartimpact.base.ui.list.peoplelist.model.BaseUiPeopleListPerson
import com.smartimpact.home.ui.maincontent.explore.page.base.BaseExplorePagePresenter


internal interface ExploreAttendeesPresenter : BaseExplorePagePresenter {
    fun onPersonClicked(person: BaseUiPeopleListPerson)
}
