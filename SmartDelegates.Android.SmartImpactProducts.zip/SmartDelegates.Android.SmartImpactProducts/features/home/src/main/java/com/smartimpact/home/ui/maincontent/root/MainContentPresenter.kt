package com.smartimpact.home.ui.maincontent.root

import android.net.Uri
import com.smartimpact.base.ui.StatusBarMode

interface MainContentPresenter {
    fun onViewCreated(chatId: String?)
    fun onDestroyView()
    fun onDestroy()

    fun openOnboardingView()
    fun openChatViewForContact(contactId: String)
    fun openProfileView(profileId: String, isSponsor: Boolean = false)
    fun openAllPostsView()
    fun openAllSessionsView()
    fun openNoteEditView(noteId: String)

    fun showHomeView()
    fun showInboxView()
    fun showExploreView()
    fun showNotesView()
    fun showMapsView()
    fun openProfileDialog(profileId: String)
    fun openProfileEditView()
    fun openPostDetailsView(postId: String, tweetUrl: String? = null)
    fun openNewPostView()
    fun openSessionDetailsView(sessionId: String)
    fun backToAppChoiceView()

    fun updateStatusBar(mode: StatusBarMode)
    fun lockDrawer(lock: Boolean)
    fun onNewEventSelected()

    fun onNavigationProfileClicked()
    fun onNavigationEditProfileClicked()

    fun onDrawerOpened()
    fun onDrawerClosed()

    fun reloadProfileData(uri: Uri?)

    fun openNewConversationView()
    fun openTweet(tweetUrl: String?)
}
