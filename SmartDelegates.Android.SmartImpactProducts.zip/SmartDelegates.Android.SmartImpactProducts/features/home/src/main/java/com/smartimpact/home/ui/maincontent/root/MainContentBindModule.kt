package com.smartimpact.home.ui.maincontent.root

import androidx.fragment.app.Fragment
import com.smartimpact.base.ui.FragmentScope
import com.smartimpact.base.ui.image.GlideFragmentModule
import com.smartimpact.home.ui.conferences.ConferencesFragment
import com.smartimpact.home.ui.conferences.ConferencesModule
import com.smartimpact.home.ui.maincontent.allposts.AllPostsFragment
import com.smartimpact.home.ui.maincontent.allposts.AllPostsModule
import com.smartimpact.home.ui.maincontent.allsessions.AllSessionsFragment
import com.smartimpact.home.ui.maincontent.allsessions.AllSessionsModule
import com.smartimpact.home.ui.maincontent.bookmarks.BookmarksFragment
import com.smartimpact.home.ui.maincontent.bookmarks.BookmarksModule
import com.smartimpact.home.ui.maincontent.chat.ChatFragment
import com.smartimpact.home.ui.maincontent.chat.ChatModule
import com.smartimpact.home.ui.maincontent.explore.ExploreFragment
import com.smartimpact.home.ui.maincontent.explore.ExploreModule
import com.smartimpact.home.ui.maincontent.home.HomeFragment
import com.smartimpact.home.ui.maincontent.home.HomeModule
import com.smartimpact.home.ui.maincontent.inbox.InboxFragment
import com.smartimpact.home.ui.maincontent.inbox.InboxModule
import com.smartimpact.home.ui.maincontent.inbox.newconversation.NewConversationFragment
import com.smartimpact.home.ui.maincontent.inbox.newconversation.NewConversationModule
import com.smartimpact.home.ui.maincontent.info.EventInfoFragment
import com.smartimpact.home.ui.maincontent.info.EventInfoModule
import com.smartimpact.home.ui.maincontent.maps.MapsFragment
import com.smartimpact.home.ui.maincontent.maps.MapsModule
import com.smartimpact.home.ui.maincontent.newpost.NewPostFragment
import com.smartimpact.home.ui.maincontent.newpost.NewPostModule
import com.smartimpact.home.ui.maincontent.notes.NotesFragment
import com.smartimpact.home.ui.maincontent.notes.NotesModule
import com.smartimpact.home.ui.maincontent.notes.noteedit.NoteEditFragment
import com.smartimpact.home.ui.maincontent.notes.noteedit.NoteEditModule
import com.smartimpact.home.ui.maincontent.postdetails.PostDetailsFragment
import com.smartimpact.home.ui.maincontent.postdetails.PostDetailsModule
import com.smartimpact.home.ui.maincontent.profile.ProfileFragment
import com.smartimpact.home.ui.maincontent.profile.ProfileModule
import com.smartimpact.home.ui.maincontent.profiledialog.ProfileDialogFragment
import com.smartimpact.home.ui.maincontent.profiledialog.ProfileDialogModule
import com.smartimpact.home.ui.maincontent.profileedit.ProfileEditFragment
import com.smartimpact.home.ui.maincontent.profileedit.ProfileEditModule
import com.smartimpact.home.ui.maincontent.sessiondetails.SessionDetailsFragment
import com.smartimpact.home.ui.maincontent.sessiondetails.SessionDetailsModule
import com.smartimpact.home.ui.maincontent.settings.SettingsFragment
import com.smartimpact.home.ui.maincontent.settings.SettingsModule
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module(includes = [GlideFragmentModule::class])
internal interface MainContentBindModule {

    @Binds fun bindFragment(fragment: MainContentFragment): Fragment

    @Binds fun bindView(fragment: MainContentFragment): MainContentView

    @Binds fun bindPresenter(presenterImpl: MainContentPresenterImpl): MainContentPresenter

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ChatModule::class])
    fun contributeChatFragmentInjector(): ChatFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [HomeModule::class])
    fun contributeHomeFragmentInjector(): HomeFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [InboxModule::class])
    fun contributeInboxFragmentInjector(): InboxFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ExploreModule::class])
    fun contributeExploreFragmentInjector(): ExploreFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [AllPostsModule::class])
    fun contributeAllPostsFragmentInjector(): AllPostsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [PostDetailsModule::class])
    fun contributePostDetailsFragmentInjector(): PostDetailsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [NewPostModule::class])
    fun contributeNewPostFragmentInjector(): NewPostFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [AllSessionsModule::class])
    fun contributeAllSessionsFragmentInjector(): AllSessionsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [NotesModule::class])
    fun contributeNotesFragmentInjector(): NotesFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [NoteEditModule::class])
    fun contributeNoteEditFragmentInjector(): NoteEditFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [MapsModule::class])
    fun contributeMapsFragmentInjector(): MapsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [EventInfoModule::class])
    fun contributeEventInfoFragmentInjector(): EventInfoFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [BookmarksModule::class])
    fun contributeBookmarksFragmentInjector(): BookmarksFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [SessionDetailsModule::class])
    fun contributeSessionDetailsFragmentInjector(): SessionDetailsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [SettingsModule::class])
    fun contributeSettingsFragmentInjector(): SettingsFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ConferencesModule::class])
    fun contributeConferencesFragmentInjector(): ConferencesFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ProfileDialogModule::class])
    fun contributeProfileDialogFragmentInjector(): ProfileDialogFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ProfileModule::class])
    fun contributeProfileFragmentInjector(): ProfileFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [ProfileEditModule::class])
    fun contributeProfileEditFragmentInjector(): ProfileEditFragment

    @FragmentScope(FragmentScope.FRAGMENT)
    @ContributesAndroidInjector(modules = [NewConversationModule::class])
    fun contributeNewConversationFragmentInjector(): NewConversationFragment

}
