import Version.daggerVersion
import Version.glideVersion
import Version.kotlinVersion
import Version.retrofitVersion
import Version.roomVersion
import Version.sharedPrefsVersion

object Android {
    val compileSdk = 29
    val targetSdk = 29
    val minSdk = 22
}

object Version {
    val kotlinVersion = "1.3.50"
    val androidPluginVersion = "3.5.0"
    val daggerVersion = "2.24"
    val glideVersion = "4.10.0"
    val sharedPrefsVersion = "3.1.2"
    val retrofitVersion = "2.6.1"
    val roomVersion = "2.2.0-rc01"
    val googleServicesVersion = "4.0.1" // 4.3.2 not working because of AppCenter dependency
    val fabricToolsVersion = "1.29.0"
    val kaminoVersion = "1.7.0"
}

object Lib {
    // Kotlin
    val kotlinStdLib = "org.jetbrains.kotlin:kotlin-stdlib-jdk7:$kotlinVersion"

    // Dagger
    val dagger = "com.google.dagger:dagger:$daggerVersion"
    val daggerAndroid = "com.google.dagger:dagger-android:$daggerVersion"
    val daggerAndroidSupport = "com.google.dagger:dagger-android-support:$daggerVersion"
    val daggerCompiler = "com.google.dagger:dagger-compiler:$daggerVersion"
    val daggerAndroidProcessor = "com.google.dagger:dagger-android-processor:$daggerVersion"

    // AndroidX
    val xAppCompat = "androidx.appcompat:appcompat:1.1.0-rc01"
    val xConstraintLayout = "androidx.constraintlayout:constraintlayout:2.0.0-beta2"
    val xMultidex = "androidx.multidex:multidex:2.0.1"
    val xCore = "androidx.core:core:1.2.0-alpha03"
    val xKtx = "androidx.core:core-ktx:1.2.0-alpha03"
    val xLifecycle = "androidx.lifecycle:lifecycle-extensions:2.0.0"
    val xAnnotations = "androidx.annotation:annotation:1.1.0"
    val xRecyclerView = "androidx.recyclerview:recyclerview:1.1.0-beta03"
    val xFragment = "androidx.fragment:fragment:1.2.0-alpha02"
    val xCoordinatorLayout = "androidx.coordinatorlayout:coordinatorlayout:1.1.0-beta01"
    val xDrawerLayout = "androidx.drawerlayout:drawerlayout:1.1.0-alpha03"
    val xActivity = "androidx.activity:activity-ktx:1.1.0-alpha03"
    val xExifInterface = "androidx.exifinterface:exifinterface:1.1.0-beta01"

    // DateTime
    val dateTime = "com.jakewharton.threetenabp:threetenabp:1.2.1"

    // RxJava
    val rxJava = "io.reactivex.rxjava2:rxjava:2.2.12"
    val rxAndroid = "io.reactivex.rxjava2:rxandroid:2.1.1"
    val rxKotlin = "io.reactivex.rxjava2:rxkotlin:2.4.0"

    // Material
    val xMaterialComponents = "com.google.android.material:material:1.1.0-alpha10"

    // Glide
    val glide = "com.github.bumptech.glide:glide:$glideVersion"
    val glideCompiler = "com.github.bumptech.glide:compiler:$glideVersion"
    val glideOkHttp = "com.github.bumptech.glide:okhttp3-integration:$glideVersion"

    // Shimmer
    val shimmer = "com.facebook.shimmer:shimmer:0.4.0"

    // Kamino
    val recyclerAdapter = "si.kamino:adapter:1.0.0@aar"
    val recyclerClick = "si.kamino:click:1.0.0@aar"
    val sharedPrefsBase = "si.kamino.preferences:base:$sharedPrefsVersion@aar"
    val sharedPrefsShared = "si.kamino.preferences:shared:$sharedPrefsVersion@aar"
    val viewPager = "si.kamino:pager:1.0.0@aar"

    // Retrofit
    val retrofit = "com.squareup.retrofit2:retrofit:$retrofitVersion"
    val retrofitGson = "com.squareup.retrofit2:converter-gson:$retrofitVersion"
    val retrofitScalar = "com.squareup.retrofit2:converter-scalars:$retrofitVersion"

    // Gson
    val gson = "com.google.code.gson:gson:2.8.5"

    // OkHttp
    val okHttp = "com.squareup.okhttp3:okhttp:4.1.1"

    // App center
    val appCenterAuth = "com.microsoft.appcenter:appcenter-auth:2.3.0"
    val appCenterAnalytics = "com.microsoft.appcenter:appcenter-analytics:2.3.0"
    val appCenterCrashes = "com.microsoft.appcenter:appcenter-crashes:2.3.0"
    val appCenterPushes = "com.microsoft.appcenter:appcenter-push:2.3.0"


    // Room database
    val roomRuntime = "androidx.room:room-runtime:$roomVersion"
    val roomAnnotationProcessor = "androidx.room:room-compiler:$roomVersion"
    val roomRxJava = "androidx.room:room-rxjava2:$roomVersion"

    // SimpleSearchView
    val simpleSearchView = "com.github.Ferfalk:SimpleSearchView:androidx-SNAPSHOT"

    // Crashlytics
    val crashlytics = "com.crashlytics.sdk.android:crashlytics:2.10.1@aar"

    // Google maps
    val googleMaps = "com.google.android.gms:play-services-maps:16.1.0"

    // PhotoView
    val photoView = "com.github.chrisbanes:PhotoView:2.3.0"

    //Flexbox
    val flexbox = "com.google.android:flexbox:2.0.0"


}
